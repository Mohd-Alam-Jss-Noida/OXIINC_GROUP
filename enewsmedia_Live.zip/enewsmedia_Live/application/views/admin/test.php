
	            <!-- center part  -->
	            <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="fa fa-question-circle" aria-hidden="true"></i>
                                    </div>
                                    <div>
                                        Test
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">



                                    <div class="card-body">
                                        <div class="card-title">Basic Examples</div>
                                        <button type="button" class="btn mr-2 mb-2 btn-primary" data-toggle="modal" data-target="#exampleModal_1">Basic Modal</button>
                                        <button type="button" class="btn mr-2 mb-2 btn-primary" data-toggle="modal" data-target="#exampleModal_2">Long Content</button>
                                        <button type="button" class="btn mr-2 mb-2 btn-primary" data-toggle="modal" data-target="#exampleModal_3">Large Modal</button>
                                        <button type="button" class="btn mr-2 mb-2 btn-primary" data-toggle="modal" data-target="#exampleModal_4">Small Modal</button>
                                    </div>









                                </div>
                            </div>
                        </div>






                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
	            <!-- center part  -->