
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-user"></i>
                                    </div>
                                    <div>
                                        Profile
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <?php //echo "<pre>"; print_r($this->session); echo "</pre>"; ?>
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="col-md-12" style="text-align: center;">
                                                <div class="position-relative form-group">
                                                    <img width="200" class="rounded-circle" src="./assets/admin/images/avatars/admin.png">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Name</label> <br>
                                                    <?php echo $this->session->userdata('name'); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Email</label> <br>
                                                    <?php echo $this->session->userdata('email'); ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Status</label> <br>
                                                    <?php echo ($this->session->userdata('status') == '1') ? 'Active' : 'Block'; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part -->

                <script src="./assets/js/jquery.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("PROFILE PAGE");
                    });
                </script>