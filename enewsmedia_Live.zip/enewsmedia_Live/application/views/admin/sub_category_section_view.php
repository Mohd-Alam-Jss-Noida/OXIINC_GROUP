
	            <!-- center part  -->
	            <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-circle-o"></i>
                                    </div>
                                    <div>
                                        Sub Category Section Details
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="page-title-actions">
                                    <a href="<?php echo base_url('sub_category_section_list'); ?>">
                                        <button type="button" data-toggle="tooltip" title="Back" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                                            <i class="fa fa-reply" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <?php //echo "<pre> --- SUB CATEGORY SECTION DETAILS --- "; print_r($sub_category_section_details); echo "</pre>"; ?>
                                        <div class="form-row">
                                            <div class="col-md-12" style="text-align: center;">
                                                <div class="position-relative form-group">
                                                    <?php
                                                        $extension = end(explode(".", $sub_category_section_details['image']));
                                                        $image_path = "./assets/sub_category_section/".''.$sub_category_section_details['image'];
                                                        $no_image_path = "./assets/sub_category_section/".''."no_image.png";
                                                        $show_image = file_exists("./assets/sub_category_section/".''.$sub_category_section_details['image']) ? $image_path : $no_image_path;
                                                        

                                                        $video_image = "./assets/sub_category_section/".''."video.png";
                                                        $db_video = "./assets/sub_category_section/".''.$sub_category_section_details['image'];
                                                        
                                                        if($extension == 'mp4')
                                                        {
                                                            ?>
                                                            <!-- POP UP CSS -->
                                                            <link rel="stylesheet" href="./assets/css/colorbox.css">
                                                            <!-- POP UP CSS -->
                                                            
                                                            <a class="popup cboxElement" href="<?php echo $db_video; ?>">
                                                                <div class="video-icon">
                                                                    <img src="<?php echo $video_image; ?>" style="height: 200px; width: 200px;">
                                                                </div>
                                                            </a>
                                                            
                                                            <!-- POP UP JS -->
                                                            <script src="./assets/js/jquery.js"></script>
                                                            <script src="./assets/js/owl.carousel.min.js"></script>
                                                            <script src="./assets/js/jquery.colorbox.js"></script>
                                                            <script src="./assets/js/custom.js"></script>
                                                            <!-- POP UP JS -->
                                                            <?php
                                                        }
                                                        else
                                                        {
                                                            ?>
                                                            <img src="<?php echo $show_image; ?>" style="height: 400px; width: 400px;">
                                                            <?php
                                                        }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Category</b></label> <br> 
                                                    <?php echo $sub_category_section_details['category_name']; ?> (<?php echo $sub_category_section_details['category_hindi_name']; ?>)
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Sub Category</b></label> <br> 
                                                    <?php echo $sub_category_section_details['sub_category_name']; ?> (<?php echo $sub_category_section_details['sub_category_hindi_name']; ?>)
                                                </div>
                                            </div>                                            
                                            <div class="col-md-3">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Name</b></label> <br> 
                                                    <?php echo $sub_category_section_details['name']; ?> (<?php echo $sub_category_section_details['hindi_name']; ?>)
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Status</b></label> <br> 
                                                    <?php echo ($sub_category_section_details['status'] == '1') ? 'Avtive' : 'Block'; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-12" style="text-align: justify;">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Details</b></label> <br> 
                                                    <?php echo $sub_category_section_details['details']; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-12" style="text-align: justify;">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class=""><b>Hindi Details</b></label> <br> 
                                                    <?php echo $sub_category_section_details['hindi_details']; ?>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
	            <!-- center part  -->

                <script src="./assets/js/jquery.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("VIEW SUB CATEGORY SECTION PAGE");
                    });
                </script>