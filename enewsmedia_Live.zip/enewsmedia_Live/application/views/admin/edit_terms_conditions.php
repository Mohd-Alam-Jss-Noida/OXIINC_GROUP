
                <!-- center part  -->
                <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-tumblr"></i>
                                    </div>
                                    <div>
                                        Edit Terms & Conditions
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="page-title-actions">
                                    <a href="<?php echo base_url('terms_conditions_list'); ?>">
                                        <button type="button" data-toggle="tooltip" title="Back" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                                            <i class="fa fa-reply" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <?php //echo "<pre> --- TERMS CONDITIONS DATA --- "; print_r($terms_conditions_data); echo "</pre>"; ?>
                                        <center>
                                            <label id="terms_conditions_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                            <label id="terms_conditions_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                        </center>
                                        <div class="form-row">
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Details *</label> 
                                                    <div id="summernote"><?php echo $terms_conditions_data['details']; ?></div>
                                                </div>
                                            </div>                                            
                                            <div class="col-md-12">
                                                <br>
                                                <label for="exampleCity" class="">Hindi Details *</label>
                                                <textarea name="hindi_details" rows="4" id="hindi_details" class="form-control" data-id="about_us"><?php echo $terms_conditions_data['hindi_details']; ?></textarea>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Status</label>
                                                    <select class="form-control" name="status" id="status">
                                                        <option value="0" <?php if($terms_conditions_data['status'] == '0') { ?> selected="selected" <?php } ?>>Block</option>
                                                        <option value="1" <?php if($terms_conditions_data['status'] == '1') { ?> selected="selected" <?php } ?>>Active</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="hid_id" id="hid_id" value="<?php echo $terms_conditions_data['id']; ?>">
                                        <button class="mt-2 btn btn-primary" onclick="edit_terms_conditions()">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
                <!-- center part -->

                <!-- English To Hindi -->
                <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script> -->
                <script src="./assets/js/english_to_hindi.js"></script>
                <script type="text/javascript">
                    google.load("elements", "1", {packages: "transliteration"});
                </script> 
                <script>
                    function OnLoad()
                    {
                        var options = {
                            sourceLanguage:
                            google.elements.transliteration.LanguageCode.ENGLISH,
                            destinationLanguage:
                            [google.elements.transliteration.LanguageCode.HINDI],
                            shortcutKey: 'ctrl+g',
                            transliterationEnabled: true
                        };

                        var control = new google.elements.transliteration.TransliterationControl(options);
                        control.makeTransliteratable(['hindi_details']);
                    }
                    google.setOnLoadCallback(OnLoad);
                </script>
                <!-- English To Hindi -->

                <script src="./assets/js/jquery.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        $('#summernote').summernote();
                    });
                </script>


                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("EDIT TERMS & CONDITIONS PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'terms_conditions')
                                { edit_terms_conditions(); }
                            }
                        });
                    });

                    function edit_terms_conditions()
                    {
                        var chk=0;
                        var id = $('#hid_id').val();
                        var summernote = $('#summernote').summernote('code');
                        var hindi_details = $('#hindi_details').val();
                        var status = $('#status').val();
                        var table = 'terms_and_conditions';

                        if(summernote=='<p><br></p>')
                        {
                            document.getElementById('terms_conditions_msg').innerHTML="";
                            document.getElementById('terms_conditions_error').innerHTML="Please enter details";
                            document.getElementById("summernote").focus();
                            chk=1;
                        }
                        else if(hindi_details=='')
                        {
                            document.getElementById('terms_conditions_msg').innerHTML="";
                            document.getElementById('terms_conditions_error').innerHTML="Please enter hindi details";
                            document.getElementById("hindi_details").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {
                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url('enms/edit_terms_conditions_details'); ?>',
                                data:{id: id, details: summernote, hindi_details: hindi_details, status: status, table: table},
                                success:function(data){
                                    //alert(data)
                                    var obj = JSON.parse(data);
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('terms_conditions_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('terms_conditions_error').innerHTML="";
                                        document.getElementById('terms_conditions_msg').innerHTML="Privacy policy details updated successfully";
                                        setTimeout(function(){
                                            var jump_terms_conditions_list_page = "<?php echo base_url('terms_conditions_list'); ?>";
                                            window.location = jump_terms_conditions_list_page;
                                        }, 1000);
                                    }
                                }
                            });
                            



                        }
                    }

                </script>