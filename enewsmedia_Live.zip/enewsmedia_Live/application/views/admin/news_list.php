
	            <!-- center part  -->
	            <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-circle-o"></i>
                                    </div>
                                    <div>
                                        View News
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>                                   
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <div>
                                            <?php //echo "<pre>"; print_r($this->session); echo "</pre>"; ?>
                                            <?php //echo "<pre>"; print_r($category_data); echo "</pre>"; ?>
                                            <?php //echo "<pre>"; print_r($sub_category_data); echo "</pre>"; ?>
                                            <?php //echo "<pre>"; print_r($news_section_data); echo "</pre>"; ?>
                                            <table style="width: 100%;" id="example" class="table table-hover table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No.</th>
                                                        <th>Category</th>
                                                        <th>Sub Category</th>
                                                        <th>Title</th>
                                                        <th>हिंदी</th>
                                                        <th>Priority</th>
                                                        <th>Status</th>
                                                        <th>View</th>
                                                        <th>Edit</th>
                                                        <th>Delete</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $serial_number = 1;
                                                        foreach($news_section_data as $key => $value)
                                                        {
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $news_section_data[$key]['id']; ?></td>
                                                                <td><?php echo $news_section_data[$key]['category_name']; ?></td>
                                                                <td><?php echo $news_section_data[$key]['sub_category_name']; ?></td>
                                                                <td><?php echo $news_section_data[$key]['name']; ?></td>
                                                                <td><?php echo $news_section_data[$key]['hindi_name']; ?></td>
                                                                <td><?php echo $news_section_data[$key]['news_priority']; ?></td>
                                                                <td><?php echo ($news_section_data[$key]['status'] == '1') ? 'Active' : 'Block'; ?></td>
                                                                <td>
                                                                    <i class="fa fa-eye" aria-hidden="true" style="cursor: pointer;" onclick="edit_news('<?php echo $news_section_data[$key]['id']; ?>', 'news_view')"></i>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-pencil" aria-hidden="true" style="cursor: pointer;" onclick="edit_news('<?php echo $news_section_data[$key]['id']; ?>', 'edit_news')"></i>
                                                                </td>
                                                                <td>
                                                                    <i class="fa fa-trash" aria-hidden="true" onclick="change_status('news', <?php echo $news_section_data[$key]['id']; ?>, '2')" style="cursor: pointer;"></i>
                                                                </td>
                                                            </tr>
                                                            <?php
                                                            $serial_number++;
                                                        }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <div class="divider"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
	            <!-- center part  -->

                <!-- <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <script src="<?php echo ASSET_URL; ?>/assets/admin/scripts/main.87c0748b313a1dda75f5.js"></script> -->
                
                <script type="text/javascript" src="<?php echo ASSET_URL; ?>/assets/admin/scripts/main.87c0748b313a1dda75f5.js"></script>
                <script src="<?php echo ASSET_URL; ?>/assets/js/jquery.js"></script>
                <script src="<?php echo ASSET_URL; ?>/assets/admin/scripts/main.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("LIST SUB CATEGORY SECTION PAGE");
                    });

                    function edit_news(id, page)
                    {
                        //alert(id);
                        window.location = "<?php echo base_url('temp_session'); ?>/" + id + "/" + page;
                    }

                    function change_status(table, id, status)
                    {
                        /*alert(table);
                        alert(id);
                        alert(status);*/
                        var x = confirm("Are you sure you want to delete?");
                        if(x)
                        {
                            //return true;
                            $.ajax({
                                url: "<?php echo base_url('enms/change_status'); ?>",
                                type: "POST",
                                data:{table: table, id: id, status: status},
                                dataType:"text",
                                success: function(data){
                                    var jump_news_list_page = "<?php echo base_url('news_list'); ?>";
                                    window.location = jump_news_list_page;
                                }
                            });
                        }
                        else
                        {
                            return false;
                        }
                    }
                </script>