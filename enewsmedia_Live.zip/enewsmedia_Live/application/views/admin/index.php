<!doctype html>
<html lang="en">
	<head>
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta http-equiv="Content-Language" content="en">
	    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	    <title>Enewsmedia - Admin Dashboard</title>
	    <link rel="icon" href="./assets/images/favicon.png" type="image/x-icon">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"/>
	    <!-- Disable tap highlight on IE -->
	    <meta name="msapplication-tap-highlight" content="no">
	    <link href="./assets/admin/css/main.css" rel="stylesheet">
	    <link href="./assets/admin/css/main.87c0748b313a1dda75f5.css" rel="stylesheet">
	    <script type="text/javascript">
	    	function avoid_space(event)
	    	{
	    		var k = event ? event.which : window.event.keyCode;
	    		if (k == 32) return false;
	    	}
	    </script>
	    <style>
	    	.slick-next
	       	{
	       		display: none !important;
	       	}
	       	.slider-light .slick-prev
	        {
	        	display: none !important;;
	        }
	        .app-logo
	        {
	        	height: 106px;
	            width: 100%;
	            background-repeat: no-repeat;
	            background-image: url(./assets/admin/images/logo-inverse.png);
	        }
	        .app-login-box .app-logo
	        {
	        	margin-bottom: 0rem;
	        }
	    </style>
	</head>
	<body>
		<div class="app-container app-theme-white body-tabs-shadow">
			<div class="app-container">
			    <div class="h-100">
			        <div class="h-100 no-gutters row">
			            <div class="d-none d-lg-block col-lg-4">
			                <div class="slider-light">
			                    <div class="slick-slider">
	                                <div>
	                                    <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-premium-dark" tabindex="-1">
	                                        <div class="slide-img-bg" style="background-image: url('./assets/admin/images/citynights.jpg');"></div>
	                                        <div class="slider-content"><h3>Scalable, Modular, Consistent</h3>
	                                            <p>Easily exclude the components you don't require. Lightweight, consistent Bootstrap based styles across all elements and components</p></div>
	                                    </div>
	                                </div>
	                                <div>
	                                    <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-sunny-morning" tabindex="-1">
	                                        <div class="slide-img-bg" style="background-image: url('./assets/admin/images/citydark.jpg');"></div>
	                                        <div class="slider-content"><h3>Complex, but lightweight</h3>
	                                            <p>We've included a lot of components that cover almost all use cases for any type of application.</p></div>
	                                    </div>
	                                </div> 
	                            </div>
			                </div>
			            </div>
			            <div class="h-100 d-flex bg-white justify-content-center align-items-center col-md-12 col-lg-8">
			                <div class="mx-auto app-login-box col-sm-12 col-md-10 col-lg-9">
			                    <div class="app-logo"></div>
			                    <!-- <h4 class="mb-0">
			                        <span class="d-block">Welcome back,</span>
			                        <span>Please sign in to your account.</span></h4>
			                    <h6 class="mt-3">No account? <a href="#" class="text-primary">Sign up now</a></h6>
			                    <div class="divider row"></div> -->

			                    <h4 class="mb-0">
			                        <span class="d-block">Welcome eNEWSMEDIA,</span>
			                        <span>Please sign in to your account.</span>
			                    </h4>
			                    <div>
			                    	<center>
				                    	<label id="login_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
										<label id="login_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
									</center> <br>
		                            <div class="form-row">
		                                <div class="col-md-6">
		                                    <div class="position-relative form-group">
		                                    	<!-- <label for="exampleEmail" class="">Email</label> -->
		                                    	<input name="email" id="email" placeholder="Email" type="text" class="form-control" onKeyPress="return avoid_space(event)" data-id="login">
		                                    </div>
		                                </div>
		                                <div class="col-md-6">
		                                    <div class="position-relative form-group">
		                                    	<!-- <label for="examplePassword" class="">Password</label> -->
		                                    	<input name="password" id="password" placeholder="Password" type="password" class="form-control" onKeyPress="return avoid_space(event)" data-id="login">
		                                    </div>
		                                </div>
		                            </div>
		                            <!-- <div class="position-relative form-check">
		                            	<input name="check" id="exampleCheck" type="checkbox" class="form-check-input"><label for="exampleCheck" class="form-check-label">Keep me logged in</label>
		                            </div>
		                            <div class="divider row"></div> -->
		                            <div class="d-flex align-items-center">
		                                <div class="ml-auto">
		                                	<!-- <a href="#" class="btn-lg btn btn-link">Recover Password</a> -->
		                                	<button class="btn btn-primary btn-lg" onclick="login()">Login</button>
		                                </div>
		                            </div>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
			</div>
		</div>
		<script type="text/javascript" src="./assets/admin/scripts/main.js"></script>
		<script type="text/javascript" src="./assets/admin/scripts/main.87c0748b313a1dda75f5.js"></script>
	</body>
</html>

<script src="./assets/js/jquery.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		//alert("ADMIN LOGIN PAGE");
		$("input").keypress(function(event) {
			if(event.which == 13)
	      	{
	        	if($(this).data("id") == 'login')
	        	{ login(); }
	      	}
	    });
	});

	function makeid(length)
	{
		var length = 9;
		var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
		var result = '';
	    for(var i = length; i > 0; --i)
	    {
	    	result += chars[Math.floor(Math.random() * chars.length)];
	    }
	    //alert(result);
		return result;
    }

	function login()
	{
		var chk=0;
	    var email = $('#email').val();
    	var password = $('#password').val();

    	/*var txt_password = btoa($('#password').val());
      	var rand_str = makeid(9);
      	var password=rand_str+txt_password;*/

    	if(document.getElementById('email').value=='')
    	{
    		document.getElementById('login_msg').innerHTML="";
    		document.getElementById('login_error').innerHTML="Please enter Email";
    		document.getElementById("email").focus();
    		chk=1;
    	}
	    else if(document.getElementById('password').value=='')
	    {
	      document.getElementById('login_msg').innerHTML="";
	      document.getElementById('login_error').innerHTML="Please enter Password";
	      document.getElementById("password").focus();
	      chk=1;
	    }

	    if(chk==1)
	    {
	    	return false;
	    }
	    else
	    {
	    	$.ajax({
	    		type:'POST',
	        	url:'<?php echo base_url('enms/check_login'); ?>',
	        	data:{email: email, password: password},
	        	success:function(data){
	        		//alert(data)
		          	var obj = JSON.parse(data);
		          	//alert(obj.status);
		          	//alert(obj.message);
		          	if(obj.status == 'error')
		          	{
		          		document.getElementById('login_error').innerHTML=obj.message;
		          	}
		          	if(obj.status == 'success')
		          	{
		          		document.getElementById('login_error').innerHTML="";
	                    document.getElementById('login_msg').innerHTML="<p>Please wait for admin dashboard ... </p>";
	                    setTimeout(function(){	                        
	                        var jump_home_page = "<?php echo base_url('dashboard'); ?>";
                        	window.location = jump_home_page;
	                    }, 1000);
		          	}
		        }
		    });
		}
	}
</script>