
	            <!-- center part  -->
	            <div class="app-main__outer">
                    <div class="app-main__inner">
                        <div class="app-page-title">
                            <div class="page-title-wrapper">
                                <div class="page-title-heading">
                                    <div class="page-title-icon">
                                        <i class="metismenu-icon fa fa-circle-o"></i>
                                    </div>
                                    <div>
                                        Edit Sub Category Section
                                        <div class="page-title-subheading">&nbsp;</div>
                                    </div>
                                </div>
                                <div class="page-title-actions">
                                    <a href="<?php echo base_url('sub_category_section_list'); ?>">
                                        <button type="button" data-toggle="tooltip" title="Back" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                                            <i class="fa fa-reply" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </div>    
                        <div class="tab-content">
                            <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                                <div class="main-card mb-3 card">
                                    <div class="card-body">
                                        <?php 
                                            //echo "<pre> --- CATEGORY --- "; print_r($category_data); echo "</pre>";
                                            //echo "<pre> --- SUB CATEGORY --- "; print_r($sub_category_data); echo "</pre>";
                                            //echo "<pre> --- SUB CATEGORY SECTION --- "; print_r($sub_category_section_data); echo "</pre>";
                                        ?>
                                        <center>
                                            <label id="sub_category_section_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                            <label id="sub_category_section_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                        </center>
                                        <div class="form-row">
                                            <div class="col-md-6">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class="">Category</label>
                                                    <select class="form-control" name="category" id="category" data-id="sub_category_section" onchange="display_sub_category(this.value)">
                                                        <?php
                                                            foreach ($category_data as $key => $value)
                                                            {
                                                                ?>
                                                                <option value="<?php echo $category_data[$key]['id']; ?>" <?php if($category_data[$key]['id'] == $sub_category_section_data['category_id']) { ?> selected="selected" <?php } ?>><?php echo $category_data[$key]['name']; ?></option>
                                                                <?php
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class="">Sub Category *</label>
                                                    <select class="form-control" name="sub_category" id="sub_category" data-id="sub_category_section">
                                                        <?php
                                                            foreach ($sub_category_data as $key => $value)
                                                            {
                                                                ?>
                                                                <option value="<?php echo $sub_category_data[$key]['id']; ?>" <?php if($sub_category_data[$key]['id'] == $sub_category_section_data['sub_category_id']) { ?> selected="selected" <?php } ?>><?php echo $sub_category_data[$key]['name']; ?></option>
                                                                <?php
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class="">Name *</label>
                                                    <input name="name" id="name" placeholder="Name" type="text" class="form-control" onKeyPress="return space_capital_small_alphabets(event)" data-id="sub_category_section" value="<?php echo $sub_category_section_data['name']; ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="position-relative form-group">
                                                    <label for="exampleEmail11" class="">Hindi Name *</label>
                                                    <input name="hindi_name" id="hindi_name" placeholder="Name" type="text" class="form-control" onKeyPress="return space_capital_small_alphabets(event)" data-id="sub_category_section" value="<?php echo $sub_category_section_data['hindi_name']; ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="" class="">Photo</label>
                                                    <input name="image[]" id="image" type="file" class="form-control" data-id="sub_category_section">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Sequence</label>
                                                    <input name="sequence" id="sequence" placeholder="Sequence" type="text" class="form-control" onKeyPress="return numbers_only(event)" data-id="sub_category_section" value="<?php echo $sub_category_section_data['sequence']; ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Status</label>
                                                    <select class="form-control" name="status" id="status">
                                                        <option value="0" <?php if($sub_category_section_data['status'] == '0') { ?> selected="selected" <?php } ?>>Block</option>
                                                        <option value="1" <?php if($sub_category_section_data['status'] == '1') { ?> selected="selected" <?php } ?>>Active</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <label for="exampleCity" class="">Details *</label> 
                                                    <div id="details"><?php echo $sub_category_section_data['details']; ?></div>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <label for="exampleCity" class="">Hindi Details *</label>
                                                <textarea name="hindi_details" rows="4" id="hindi_details" class="form-control" data-id="sub_category_section"><?php echo $sub_category_section_data['hindi_details']; ?></textarea>
                                            </div>
                                        </div>
                                        <input type="hidden" name="hid_id" id="hid_id" value="<?php echo $sub_category_section_data['id']; ?>">
                                        <button class="mt-2 btn btn-primary" onclick="edit_sub_category_section()">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php include('center_footer.php'); ?>
                </div>
	            <!-- center part  -->

                <!-- English To Hindi -->
                <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script> -->
                <script src="./assets/js/english_to_hindi.js"></script>
                <script type="text/javascript">
                    google.load("elements", "1", {packages: "transliteration"});
                </script> 
                <script>
                    function OnLoad()
                    {
                        var options = {
                            sourceLanguage:
                            google.elements.transliteration.LanguageCode.ENGLISH,
                            destinationLanguage:
                            [google.elements.transliteration.LanguageCode.HINDI],
                            shortcutKey: 'ctrl+g',
                            transliterationEnabled: true
                        };

                        var control = new google.elements.transliteration.TransliterationControl(options);
                        control.makeTransliteratable(["hindi_name"]);
                        control.makeTransliteratable(['hindi_details']);
                    }
                    google.setOnLoadCallback(OnLoad);
                </script>
                <!-- English To Hindi -->

                <!-- SUMMERNOTE -->
                <script src="./assets/js/jquery.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.css" rel="stylesheet">
                <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote.min.js"></script>
                <script type="text/javascript">
                    $(document).ready(function() {
                        $('#details').summernote();
                    });
                </script>
                <!-- SUMMERNOTE -->

                <script type="text/javascript">
                    $(document).ready(function() {
                        //alert("EDIT SUB CATEGORY PAGE");
                        $("input").keypress(function(event) {
                            if(event.which == 13)
                            {
                                if($(this).data("id") == 'sub_category_section')
                                { edit_sub_category_section(); }
                            }
                        });
                    });

                    function display_sub_category(id)
                    {
                        //alert(id);
                        document.getElementById("sub_category").disabled = false;
                        $.ajax({
                          url:'<?php echo base_url('enms/display_sub_category'); ?>',
                          type: 'post',
                          data:{id: id},
                          dataType: 'json',
                          success:function(response){
                            //alert(response);
                            var len = response.length;
                            $("#sub_category").empty();
                            $("#sub_category").append("<option value='0'>Select</option>");
                            for(var i = 0; i<len; i++)
                            {
                              var id = response[i]['id'];
                              var name = response[i]['name'];
                              $("#sub_category").append("<option value='"+id+"'>"+name+"</option>");
                            }
                          }
                        });
                    }

                    function text_box_empty(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        return false //disable key press
                    }
                
                    function space_capital_small_alphabets(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        if (unicode!=8) //if the key isn't the backspace key (which we should allow)
                        { 
                            if ((unicode<65||unicode>90) && (unicode<97||unicode>122) && (unicode!=32)) //if not a number
                                return false //disable key press
                        }
                    }

                    function numbers_only(e)
                    {
                        var unicode=e.charCode? e.charCode : e.keyCode
                        if (unicode!=8) //if the key isn't the backspace key (which we should allow)
                        { 
                            if (unicode<48||unicode>57) //if not a number
                                return false //disable key press
                        }
                    }

                    function edit_sub_category_section()
                    {
                        var chk=0;
                        var SubCategorySectionData = new FormData();
                        var id = $('#hid_id').val();
                        var category = $('#category').val();
                        var sub_category = $('#sub_category').val();
                        var name = $('#name').val();
                        var hindi_name = $('#hindi_name').val();
                        var image = $('#image').val();
                        var sequence = $('#sequence').val();
                        var status = $('#status').val();
                        var details = $('#details').summernote('code');
                        var hindi_details = $('#hindi_details').val();
                        var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif|\.bmp|\.mp4)$/i;
                        var table = 'sub_category_section';

                        /// IMAGES
                        var image_selection_extension = true;
                        var image_document_selection = document.getElementById('image');
                        for(var i=0; i<image_document_selection.files.length; i++)
                        {
                          var fname = image_document_selection.files.item(i).name;
                          var ext = image_document_selection.files[i].name.split('.').pop();
                          if($.inArray(ext, ['gif','png','jpg','jpeg','bmp','pdf']) == -1)
                          {
                            //alert('not accepted file extension ' + fname);
                            image_selection_extension = false;
                          }
                        }

                        if(document.getElementById('sub_category').value=='0')
                        {
                            document.getElementById('sub_category_section_msg').innerHTML="";
                            document.getElementById('sub_category_section_error').innerHTML="Please select sub category";
                            document.getElementById("sub_category").focus();
                            chk=1;
                        }
                        else if(document.getElementById('name').value=='')
                        {
                            document.getElementById('sub_category_section_msg').innerHTML="";
                            document.getElementById('sub_category_section_error').innerHTML="Please enter name";
                            document.getElementById("name").focus();
                            chk=1;
                        }
                        else if(document.getElementById('hindi_name').value=='')
                        {
                            document.getElementById('sub_category_section_msg').innerHTML="";
                            document.getElementById('sub_category_section_error').innerHTML="Please enter hindi name";
                            document.getElementById("hindi_name").focus();
                            chk=1;
                        }
                        else if(document.getElementById('image').value!='' && !allowedExtensions.exec(image))
                        {
                            document.getElementById('sub_category_section_msg').innerHTML="";
                            document.getElementById('sub_category_section_error').innerHTML="Photo extension must be .jpg/.jpeg/.png/.gif/.bmp/.mp4 only";
                            document.getElementById("image").focus();
                            chk=1;
                        }
                        else if(details=='<p><br></p>')
                        {
                            document.getElementById('sub_category_section_msg').innerHTML="";
                            document.getElementById('sub_category_section_error').innerHTML="Please enter details";
                            document.getElementById("details").focus();
                            chk=1;
                        }
                        else if(hindi_details=='')
                        {
                            document.getElementById('sub_category_section_msg').innerHTML="";
                            document.getElementById('sub_category_section_error').innerHTML="Please enter hindi details";
                            document.getElementById("hindi_details").focus();
                            chk=1;
                        }

                        if(chk==1)
                        {
                            return false;
                        }
                        else
                        {
                            if(document.getElementById('image').value!='')
                            {
                                var image_extension = image.split('.').pop();
                                var image_name = id + '.' + image_extension;
                                SubCategorySectionData.append("image_name", image_name);
                                for(var i=0; i<image_document_selection.files.length; i++)
                                {
                                    SubCategorySectionData.append("image", document.getElementById('image').files[i]);
                                }
                            }
                            SubCategorySectionData.append("id", id);
                            SubCategorySectionData.append("category", category);
                            SubCategorySectionData.append("sub_category", sub_category);
                            SubCategorySectionData.append("name", name);
                            SubCategorySectionData.append("hindi_name", hindi_name);
                            SubCategorySectionData.append("sequence", sequence);
                            SubCategorySectionData.append("status", status);
                            SubCategorySectionData.append("details", details);
                            SubCategorySectionData.append("hindi_details", hindi_details);
                            SubCategorySectionData.append("table", table);
                            $.ajax({
                                type:'POST',
                                url:'<?php echo base_url('enms/edit_sub_category_section_details'); ?>',
                                data: SubCategorySectionData,
                                contentType: false,
                                cache: false,
                                processData: false,
                                success:function(data){
                                    //alert(data)
                                    var obj = JSON.parse(data);
                                    //alert(obj.status);
                                    //alert(obj.message);
                                    if(obj.status == 'error')
                                    {
                                        document.getElementById('sub_category_section_error').innerHTML=obj.message;
                                    }
                                    if(obj.status == 'success')
                                    {
                                        document.getElementById('sub_category_section_error').innerHTML="";
                                        document.getElementById('sub_category_section_msg').innerHTML="<p>Sub Category Section updated successfully </p>";
                                        setTimeout(function(){                          
                                            var jump_sub_category_section_list_page = "<?php echo base_url('sub_category_section_list'); ?>";
                                            window.location = jump_sub_category_section_list_page;
                                        }, 1000);
                                    }
                                }
                            });
                        }
                    }

                </script>