	<style>
    	/*.address_color
    	{
    		background: linear-gradient(20deg, #f84270 0%, #fe803b 100%)!important;padding: 19px;color:white;
        }*/

        .address_color
        {
        	background: #171616 !important;
    		padding: 19px;
    		color: white;
		}
    </style>
	<div class="gap-30"></div>

	<?php
		//echo "<pre> --- RECENT --- "; print_r($recent_data); echo "</pre>";
		//echo "<pre> --- POPULAR --- "; print_r($popular_data); echo "</pre>";
		//echo "<pre> --- COMMENT ---"; print_r($comment_data); echo "</pre>";
	?>

	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a></li>
						<li><i class="fa fa-angle-right"></i><?php if($website_language == '0') { echo "संपर्क करें"; } else { echo "Contact Us"; } ?></li>
					</ol>		
				</div>
			</div>
		</div>
	</div>

	<section class="main-content category-layout-1 pt-0">
		<br>
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-12">
					<div class="row">
						<div class="col-lg-4">
	                    	<div class="contact-info-box">
								<div class="contact-info-box-content address_color text-center">
									<p><img src="./assets/images/address.jpg" width="50"></p>
									<h4 style="color:white"><?php if($website_language == '0') { echo "पता"; } else { echo "ADDRESS"; } ?></h4>
									<p style="color:white">
										S6-2, Pinnacle Business Park,
		                        		Mahakali Caves Road,
		                        		Shanti Nagar, Andheri (East),
		                        		Mumbai, Maharashtra - 400093.
		                        	</p>
								</div>
							</div>
	                    </div>  
	                    <div class="col-lg-4">
	                    	<div class="contact-info-box">
								<div class="contact-info-box-content address_color text-center">
									<p><img src="./assets/images/phone.jpg" width="50"></p>
									<h4 style="color:white"><?php if($website_language == '0') { echo "हमें कॉल करें"; } else { echo "CALL US"; } ?></h4>
									<p style="color:white">(+91) 8650307358</p><br><br>
								</div>
							</div>	                        
	                    </div>
	                    <div class="col-lg-4">
	                    	<div class="contact-info-box">
								<div class="contact-info-box-content address_color text-center">
									<p><img src="./assets/images/email.jpg" width="50"></p>
									<h4 style="color:white"><?php if($website_language == '0') { echo "ईमेल"; } else { echo "E-MAIL"; } ?></h4>
									<p style="color:white">
	                    				contact@enewsmedia.in<br>
	                    				info@enewsmedia.in<br>
	                        		</p><br>
								</div>
							</div>
	                    </div>
                	</div>
				</div>
				<div class="col-lg-12">
					<div class="row">
						<div class="col-lg-8">
							<h3><?php if($website_language == '0') { echo "पूछताछ फार्म"; } else { echo "Enquiry Form"; } ?></h3>
							<div class="error-container">
								<center>
                                    <label id="enquiry_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
                                  	<label id="enquiry_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
                                </center>
							</div>
							<div class="row">
								<div class="col-md-4">
									<div class="form-group">
										<label><?php if($website_language == '0') { echo "नाम"; } else { echo "Name"; } ?> *</label>
										<input class="form-control form-control-name" name="name" id="name" placeholder="" type="text" data-id="enquiry" onKeyPress="return space_capital_small_alphabets(event)">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label><?php if($website_language == '0') { echo "ईमेल"; } else { echo "Email"; } ?> *</label>
										<input class="form-control form-control-email" name="email" id="email" 
										placeholder="" type="email" data-id="enquiry" onKeyPress="return avoid_space(event)">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group">
										<label><?php if($website_language == '0') { echo "विषय"; } else { echo "Subject"; } ?> *</label>
										<input class="form-control form-control-subject" name="subject" id="subject" 
										placeholder="" data-id="enquiry" onKeyPress="return space_capital_small_alphabets(event)">
									</div>
								</div>
							</div>
							<div class="form-group">
								<label><?php if($website_language == '0') { echo "संदेश"; } else { echo "Message"; } ?> *</label>
								<textarea class="form-control form-control-message" name="message" id="message" placeholder="" rows="10" data-id="enquiry"></textarea>
							</div>
							<div><button class="btn btn-submit" type="submit" onclick="enquiry()"><?php if($website_language == '0') { echo "मेसेज भेजें"; } else { echo "Send Message"; } ?></button></div>
							<input type="hidden" name="hid_website_language" id="hid_website_language" value="<?php echo $website_language; ?>">
						</div>
						<div class="col-lg-4">
							<div class="sidebar">
								<div class="sidebar-widget featured-tab post-tab mb-20">
								<ul class="nav nav-tabs">
									<li class="nav-item">
										<a class="nav-link animated active fadeIn" href="#post_tab_a" data-toggle="tab">
											<span class="tab-head">
												<span class="tab-text-title"><?php if($website_language == '0') { echo "हाल"; } else { echo "Recent"; } ?></span>
											</span>
										</a>
									</li>
									<li class="nav-item">
										<a class="nav-link animated fadeIn" href="#post_tab_b" data-toggle="tab">
											<span class="tab-head">
												<span class="tab-text-title"><?php if($website_language == '0') { echo "लोकप्रिय"; } else { echo "Popular"; } ?></span>
											</span>
										</a>
									</li>
									<li class="nav-item">
										<a class="nav-link animated fadeIn" href="#post_tab_c" data-toggle="tab">
											<span class="tab-head">
												<span class="tab-text-title"><?php if($website_language == '0') { echo "टिप्पणियाँ"; } else { echo "Comments"; } ?></span>
											</span>
										</a>
									</li>
								</ul>
								<div class="gap-50 d-none d-md-block"></div>
								<div class="row">
									<div class="col-12">
										<div class="tab-content">
											<div class="tab-pane active animated fadeInRight" id="post_tab_a">
												<div class="list-post-block">
													<ul class="list-post">
														<?php
															foreach ($recent_data as $key => $value)
															{
																$image_path = ASSET_URL."/assets/news/".''.$recent_data[$key]['image'];
	                                $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
	                                $show_image = isset($recent_data[$key]['image']) ? $image_path : $no_image_path;
																	$video_thumb_img = isset($recent_data[$key]['video_thumb_img']) ? ASSET_URL."assets/news/".''.$recent_data[$key]['video_thumb_img'] : $no_image_path;
                               ?>															
																<li>
																	<div class="post-block-style media">
																		<div class="post-thumb">
																			<?php if(isset($recent_data[$key]['media_type']) && $recent_data[$key]['media_type'] == 'video') {
																			 			?>
																					<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="">
																					<a class="popup cboxElement" href="<?php echo $show_image; ?>">
																						<div class="video-icon">
																							<i class="fa fa-play"></i>
																						</div>
																					</a>
																			<?php } else { ?>							
																				<a style="cursor: pointer;" onclick="view_details('<?php echo $recent_data[$key]['id']; ?>', 'news')">
																					<img class="img-fluid" src="<?php echo $show_image; ?>" alt="">
																				</a>
																				<!-- <span class="tab-post-count">1</span> -->
																			<?php } ?>
																		</div>
																		<div class="post-content media-body">
																			<div class="grid-category">
																				<a class="post-cat tech-color" style="cursor: pointer;" onclick="view_details('<?php echo $recent_data[$key]['id']; ?>', 'news')"><?php if($website_language == '0') { echo $recent_data[$key]['category_hindi_name']; } else { echo $recent_data[$key]['category_name']; } ?></a>
																			</div>
																			<h2 class="post-title">
																				<a style="cursor: pointer;" onclick="view_details('<?php echo $recent_data[$key]['id']; ?>', 'news')">
																					<?php if($website_language == '0') { echo (strlen($recent_data[$key]['hindi_name']) > 50) ? substr($recent_data[$key]['hindi_name'], 0, 35).' '."..." : $recent_data[$key]['hindi_name']; } else { echo (strlen($recent_data[$key]['name']) > 50) ? substr($recent_data[$key]['name'], 0, 35).' '."..." : $recent_data[$key]['name']; } ?>
																				</a>
																			</h2>
																			<div class="post-meta mb-7">
																				<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($recent_data[$key]['created']) && !empty($recent_data[$key]['created']) ? date('d F, Y', strtotime($recent_data[$key]['created'])) : ''; ?></span>
																			</div>
																		</div>
																	</div>
																</li>
																<?php
															}
														?>
													</ul>
												</div>
											</div>
											<div class="tab-pane animated fadeInRight" id="post_tab_b">
												<div class="list-post-block">
													<ul class="list-post">
														<?php
															foreach ($popular_data as $key => $value)
															{
																$image_path = ASSET_URL."/assets/news/".''.$popular_data[$key]['image'];
	                                $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
	                                $show_image = isset($popular_data[$key]['image']) ? $image_path : $no_image_path;
																	$video_thumb_img = isset($popular_data[$key]['video_thumb_img']) ? ASSET_URL."assets/news/".''.$popular_data[$key]['video_thumb_img'] : $no_image_path;

                  								?>															
																<li>
																	<div class="post-block-style media">
																		<div class="post-thumb">
																			<?php if(isset($popular_data[$key]['media_type']) && $popular_data[$key]['media_type'] == 'video') {
																			 			?>
																					<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="">
																					<a class="popup cboxElement" href="<?php echo $show_image; ?>">
																						<div class="video-icon">
																							<i class="fa fa-play"></i>
																						</div>
																					</a>
																			<?php } else { ?>	
																				<a style="cursor: pointer;" onclick="view_details('<?php echo $popular_data[$key]['id']; ?>', 'news')">
																					<img class="img-fluid" src="<?php echo $show_image; ?>" alt="">
																				</a>
																				<!-- <span class="tab-post-count">1</span> -->
																			<?php } ?>
																		</div>
																		<div class="post-content media-body">
																			<div class="grid-category">
																				<a class="post-cat tech-color" style="cursor: pointer;" onclick="view_details('<?php echo $popular_data[$key]['id']; ?>', 'news')"><?php if($website_language == '0') { echo $popular_data[$key]['category_hindi_name']; } else { echo $popular_data[$key]['category_name']; } ?></a>
																			</div>
																			<h2 class="post-title">
																				<a style="cursor: pointer;" onclick="view_details('<?php echo $popular_data[$key]['id']; ?>', 'news')">
																					<?php if($website_language == '0') { echo (strlen($popular_data[$key]['hindi_name']) > 50) ? substr($popular_data[$key]['hindi_name'], 0, 35).' '."..." : $popular_data[$key]['hindi_name']; } else { echo (strlen($popular_data[$key]['name']) > 50) ? substr($popular_data[$key]['name'], 0, 35).' '."..." : $popular_data[$key]['name']; } ?>
																				</a>
																			</h2>
																			<div class="post-meta mb-7">
																				<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($popular_data[$key]['created']) && !empty($popular_data[$key]['created']) ? date('d F, Y', strtotime($popular_data[$key]['created'])) : ''; ?></span>
																			</div>
																		</div>
																	</div>
																</li>
																<?php
															}
														?>
													</ul>
												</div>
											</div>
											<div class="tab-pane animated fadeInRight" id="post_tab_c">
												<div class="list-post-block">
													<ul class="list-post">
														<?php
															foreach ($comment_data as $key => $value)
															{
																	$image_path = ASSET_URL."/assets/news/".''.$comment_data[$key]['image'];
	                                $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
	                                $show_image = isset($comment_data[$key]['image']) ? $image_path : $no_image_path;
																?>															
																<li>
																	<div class="post-block-style media">
																		<div class="post-thumb">
																			<?php
																				if($comment_data[$key]['sub_category_id'] == '0')
																				{
																					?>
																					<a style="cursor: pointer;" onclick="view_details('<?php echo $comment_data[$key]['category_id']; ?>', 'news')"><img class="img-fluid" src="<?php echo $show_image; ?>" alt=""></a>
																					<?php
																				}
																				else
																				{
																					?>
																					<a style="cursor: pointer;" onclick="view_details('<?php echo $comment_data[$key]['sub_category_id']; ?>', 'news')"><img class="img-fluid" src="<?php echo $show_image; ?>" alt=""></a>
																					<?php
																				}
																			?>
																			<!-- <span class="tab-post-count">1</span> -->
																		</div>
																		<div class="post-content media-body">
																			<div class="grid-category">
																				<?php
																					if($comment_data[$key]['sub_category_id'] == '0')
																					{
																						?>
																						<a class="post-cat tech-color" style="cursor: pointer;" onclick="view_details('<?php echo $comment_data[$key]['category_id']; ?>', 'category')"><?php if($website_language == '0') { echo $comment_data[$key]['category_hindi_name']; } else { echo $comment_data[$key]['category_name']; } ?></a>
																						<?php
																					}
																					else
																					{
																						?>
																						<a class="post-cat tech-color" style="cursor: pointer;" onclick="view_details('<?php echo $comment_data[$key]['sub_category_id']; ?>', 'news')"><?php if($website_language == '0') { echo $comment_data[$key]['sub_category_hindi_name']; } else { echo $comment_data[$key]['sub_category_name']; } ?></a>
																						<?php
																					}
																				?>
																			</div>
																			<h2 class="post-title">
																				<?php
																					if($comment_data[$key]['sub_category_id'] == '0')
																					{
																						?>
																						<a class="post-cat tech-color" style="cursor: pointer;" onclick="view_details('<?php echo $comment_data[$key]['category_id']; ?>', 'news')"><?php echo $comment_data[$key]['comment']; ?></a>
																						<?php
																					}
																					else
																					{
																						?>
																						<a class="post-cat tech-color" style="cursor: pointer;" onclick="view_details('<?php echo $comment_data[$key]['sub_category_id']; ?>', 'news')"><?php echo $comment_data[$key]['comment']; ?></a>
																						<?php
																					}
																				?>
																			</h2>
																			<div class="post-meta mb-7">
																				<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($comment_data[$key]['created']) && !empty($comment_data[$key]['created']) ? date('d F, Y', strtotime($comment_data[$key]['created'])) : ''; ?></span>
																			</div>
																		</div>
																	</div>
																</li>
																<?php
															}
														?>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.js"></script>
	<script type="text/javascript">
	    $(document).ready(function() {
	       	//alert("ENQUIRY PAGE");
	        $("input").keypress(function(event) {
	            if(event.which == 13)
	            {
	                if($(this).data("id") == 'enquiry')
	                { enquiry(); }
	            }
	        });
	    });

	    function space_capital_small_alphabets(e)
        {
            var unicode=e.charCode? e.charCode : e.keyCode
            if (unicode!=8) //if the key isn't the backspace key (which we should allow)
            { 
                if ((unicode<65||unicode>90) && (unicode<97||unicode>122) && (unicode!=32)) //if not a number
                    return false //disable key press
            }
        }

        function avoid_space(event)
        {
            var k = event ? event.which : window.event.keyCode;
            if (k == 32) return false;
        }

	    function enquiry()
        {
        	var chk=0;
            var website_language = $('#hid_website_language').val();
            var name = $('#name').val();
            var email = $('#email').val();
            var subject = $('#subject').val();
            var message = $('#message').val();
            var email_check = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            
            if(document.getElementById('name').value=='')
            {
                document.getElementById('enquiry_msg').innerHTML="";
                if(website_language == '0')
                {
                	document.getElementById('enquiry_error').innerHTML="कृपया नाम दर्ज करें";
                }
                else
                {
                	document.getElementById('enquiry_error').innerHTML="Please enter name";
                }
                document.getElementById("name").focus();
                chk=1;
            }
            else if(document.getElementById('email').value=='')
            {
                document.getElementById('enquiry_msg').innerHTML="";
                if(website_language == '0')
                {
                	document.getElementById('enquiry_error').innerHTML="कृपया ईमेल दर्ज करें";
                }
                else
                {
                	document.getElementById('enquiry_error').innerHTML="Please enter email";
                }
                document.getElementById("email").focus();
                chk=1;
            }
            else if(email_check.test(email) === false)
	        {
	        	document.getElementById('enquiry_msg').innerHTML="";
	        	if(website_language == '0')
                {
                	document.getElementById('enquiry_error').innerHTML="अवैध ईमेल";
                }
                else
                {
                	document.getElementById('enquiry_error').innerHTML="Invaild Email ID";
                }
	          	document.getElementById("email").focus();
	          	chk=1;
	        }
            else if(document.getElementById('subject').value=='')
            {
                document.getElementById('enquiry_msg').innerHTML="";
                if(website_language == '0')
                {
                	document.getElementById('enquiry_error').innerHTML="कृपया विषय दर्ज करें";
                }
                else
                {
                	document.getElementById('enquiry_error').innerHTML="Please enter subject";
                }
                document.getElementById("subject").focus();
                chk=1;
            }
            else if(document.getElementById('message').value=='')
            {
                document.getElementById('enquiry_msg').innerHTML="";
                document.getElementById('enquiry_error').innerHTML="Please enter message";
                if(website_language == '0')
                {
                	document.getElementById('enquiry_error').innerHTML="कृपया संदेश दर्ज करें";
                }
                else
                {
                	document.getElementById('enquiry_error').innerHTML="Please enter message";
                }
                document.getElementById("message").focus();
                chk=1;
            }

            if(chk==1)
            {
                return false;
            }
            else
            {
            	var status = 1;
	            $.ajax({
	                type:'POST',
	                url:'<?php echo base_url('home/insert_enquiry'); ?>',
	                data:{name: name, email: email, subject: subject, message: message, status: status},
	                success:function(data){
	                  var obj = JSON.parse(data);
	                  //alert(obj.status);
	                  //alert(obj.last_id);
	                  if(obj.status == 'error')
	                  {
	                  	document.getElementById('enquiry_error').innerHTML=obj.status;
	                  }
	                  if(obj.status == 'success')
	                  {
	                  	document.getElementById('enquiry_error').innerHTML="";
	                    if(website_language == '0')
		                {
		                	document.getElementById('enquiry_error').innerHTML="आपकी जांच सफलतापूर्वक सबमिट कर दी गई है";
		                }
		                else
		                {
		                	document.getElementById('enquiry_msg').innerHTML="Your enquiry has been submitted successfully";
		                }

	                    var jump_contact_page = "<?php echo base_url('contact'); ?>";
	                    setTimeout(function () {
	                        window.location = jump_contact_page;
	                    }, 2000);
	                  }
	                }
	            });
            }
        }
	</script>