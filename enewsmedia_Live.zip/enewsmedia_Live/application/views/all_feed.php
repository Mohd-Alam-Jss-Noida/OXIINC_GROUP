<?php //echo "<pre>"; print_r($feed_data); exit();
?>
<div class="gap-30"></div>
	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li>
							<i class="fa fa-home"></i>
								<a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a>
							<i class="fa fa-angle-right"></i>
						</li>
						<li><?php echo ucfirst(str_replace('_', ' ', $this->session->userdata('cat_name'))); ?></li>
					</ol>		
				</div>
			</div>
		</div>
	</div>
<section class="main-content category-layout-1 pt-0">
	<br>
	<div class="container">
		<div class="row ts-gutter-30">
		<?php
		if(count($feed_data['item']) > 1) {
			$i=1;
			foreach ($feed_data['item'] as $k => $v)
			{	
				$no_image_feed_path = ASSET_URL. "/assets/news/".''."no_image.png";
				//$headers = @get_headers($this->_value);
				/*$file = $v['@attributes']['image'];
				$file_headers = @get_headers($file);
				if(strpos($file_headers[0],'200')===false)
				    $feed_image = $no_image_feed_path;
				else
				*/    $feed_image = $v['@attributes']['image'];

				?>
				<div class="col-md-6 col-lg-4">
					<a href="#" id="<?php echo $i.'_'.$i;?>" onclick="feed_details('<?php echo $i.'_'.$i; ?>')" data-name="<?php echo ucfirst(str_replace('_', ' ', $this->session->userdata('cat_name'))); ?>" data-image="<?php echo $feed_image; ?>" data-title="<?php echo $v['@attributes']['title']; ?>" data-desciption="<?php echo $v['@attributes']['description']; ?>" data-created="<?php echo $v['@attributes']['pubDate']; ?>">			
						<div class="post-block-style clearfix">
							<div class="post-thumb">
									<img class="img-fluid" src="<?php echo $feed_image; ?>" alt="" />
									<div class="grid-cat">
										<a class="post-cat" href="#"><?php echo $this->session->userdata('cat_name'); ?></a>
									</div>
							</div>		
							<div class="post-content">
								<h2 class="post-title title-md">
									<a href="#"><?php echo (strlen($v['@attributes']['title']) > 150) ? substr($v['@attributes']['title'], 0, 150).' '."..." : $v['@attributes']['title'];  ?></a>
								</h2>
								<div class="post-meta mb-7">
									<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($v['@attributes']['pubDate']) && !empty($v['@attributes']['pubDate']) ? date('d F, Y', strtotime($v['@attributes']['pubDate'])) : ''; ?>
								</div>
								<!-- <p>The market won’t stop actress and singer....</p> -->
							</div>
						</div>
					</a>
				</div>
				<?php $i++;
			}
		}
		?>
		</div>
	</div>
</section>