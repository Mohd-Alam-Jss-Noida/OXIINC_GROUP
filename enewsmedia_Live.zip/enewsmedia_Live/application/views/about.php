	<div class="gap-30"></div>

	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a></li>
						<li><i class="fa fa-angle-right"></i><?php if($website_language == '0') { echo "हमारे बारे में"; } else { echo "About Us"; } ?></li>
					</ol>		
				</div>
			</div>
		</div>
	</div>

	<section class="main-content category-layout-2 pt-0">
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-8">
					<div class="row">
						<div class="col-12">
							<?php //echo "<pre>"; print_r($about_us); echo "</pre>"; ?>
							<div class="author-box d-flex mt-0">
								<div class="author-img flex-grow-1">
									<img src="images/news/author.png" alt="">
								</div>
								<div class="author-info" style="text-align: justify;">
									<?php
										foreach ($about_us as $key => $value)
										{
											?>
											<h2 class="block-title"><span><?php if($website_language == '0') { echo $about_us[$key]['hindi_title']; } else { echo $about_us[$key]['title']; } ?></span></h2>
											<p><?php if($website_language == '0') { echo $about_us[$key]['hindi_details']; } else { echo $about_us[$key]['details']; } ?></p>
											<?php
										}
									?>
								</div>
							</div>
						</div>
					</div>
					<div class="gap-50"></div>
				</div>
				<div class="col-lg-4">
					<div class="sidebar">
						<br>
						<div class="sidebar-widget social-widget">
							<h2 class="block-title">
								<span class="title-angle-shap"> <?php if($website_language == '0') { echo "सामाजिक"; } else { echo "Social"; } ?></span>
							</h2>
							<div class="sidebar-social">
								<ul class="ts-social-list style2">
									<li class="ts-facebook">
										<a href="#">
											<i class="tsicon fa fa-facebook"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "फेसबुक"; } else { echo "Facebook"; } ?></b>
												<span><?php if($website_language == '0') { echo "पसंद"; } else { echo "Likes"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-twitter">
										<a href="#">
											<i class="tsicon fa fa-twitter"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "ट्विटर"; } else { echo "Twitter"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-youtube">
										<a href="#">
											<i class="tsicon fa fa-youtube-play"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "यूट्यूब"; } else { echo "Youtube"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-rss">
										<a href="#">
											<i class="tsicon fa fa-linkedin"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "लिंक्डइन"; } else { echo "Linkdin"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>