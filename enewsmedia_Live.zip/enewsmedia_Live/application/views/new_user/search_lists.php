			<!-- START CONTAINER -->
			<div class="main-wrapper">
				<!-- Breadcrumb Section -->
				<section class="breadcrumb-section fwd">
					<div class="container">
						<ol class="breadcrumb">
							<li><a href="<?php echo base_url('Enews'); ?>"><?php echo ($website_language == '0') ? "होम" : "Home";?></a></li>
							<li class="active"><?php echo $this->input->get('s');?></li>
						</ol>
					</div>
				</section>
				<div class="clrfix"></div>
				<!-- News List Section -->
				<section class="home-section-01 home-section-02 news-list-section fwd">
					<div class="container">
						<div class="left-col">
							<!-- International Articles Block -->
							<div class="latest-articles-block fwd">
								<h2 class="headding-01">Search Articles</h2>
								<ul class="list-inline articles-list">
									<?php
									//echo "<pre>";print_r($news_listing);die();
									if(isset($search_listing) && !empty($search_listing)) foreach($search_listing as $key => $value){
										$show_image = (isset($value['image']) && !empty($value['image']) && file_exists("assets/news/".$value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
										?>
										<li class="equal-height-col">
											<a href="javascript:void(0);" class="item-col fwd" onclick="view_details('<?php echo $value['id']; ?>', 'news', '<?php echo $value['category_id']; ?>')">
												<div class="img-col fwd">
													<img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
													<div class="overlay-col"></div>
												</div>
												<div class="containt-col fwd">
													<h3 class="headding-02"><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
													<div class="headding-03"><?php echo date('d F, Y', strtotime($value['created'])); ?></div>
												</div>
											</a>
										</li>
										<?php
									}
									else{ ?>
										<h2 class="text-center">Sorry, we couldn't find any result matching for "<?php echo $this->input->get('s') ?>".</h2>
										<?php
									}
									?>
								</ul>
							</div>
						</div>
						<div class="right-col">
							<!-- Stay Connected Block -->
							<div class="stay-connected-block fwd">
								<h2 class="headding-01">Stay Connected</h2>
								<ul class="list-unstyled social-media-links">
									<li><a class="facebook-btn" href="#" target="_blank"><i class="fab fa-facebook-f"></i>Facebook</a></li>
									<li><a class="twitter-btn" href="#" target="_blank"><i class="fab fa-twitter"></i>Twitter</a></li>
									<li><a class="linkedin-btn" href="#" target="_blank"><i class="fab fa-linkedin-in"></i>Linkedin</a></li>
									<li><a class="youtube-btn" href="#" target="_blank"><i class="fab fa-youtube"></i>Youtube</a></li>
								</ul>
							</div>
							<div class="recent-happenings-block fwd">
                                <h2 class="headding-01"><?php echo ($website_language == '0') ? "हाल ही में हुआ" : "Recent Happenings";?></h2>
                                <ul class="list-unstyled recent-news-list">
                                    <?php
                                    //echo "<pre>";print_r($recent_happenings);die();
                                    if(isset($recent_happenings) && !empty($recent_happenings)) foreach($recent_happenings as $key => $value){
                                        $show_image = (isset($value['image']) && !empty($value['image']) && file_exists("assets/news/".$value['image'])) ? base_url('assets/news/'.$value['image']) : base_url('assets/news/no_image.png');
                                        ?>
                                        <li>
                                            <a href="javascript:void(0);" class="item-col" onclick="view_details('<?php echo $value['id']; ?>', 'news', '<?php echo $value['category_id']; ?>')">
                                                <div class="img-col">
                                                    <img src="<?php echo $show_image; ?>" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="containt-col">
                                                    <h3><?php echo ($website_language == '0') ? character_limiter($value['hindi_name'], CHAR_LIMIT) : character_limiter($value['name'], CHAR_LIMIT);?></h3>
                                                    <div class="date-txt">Music - <?php echo date('d F, Y', strtotime($value['created'])); ?></div>
                                                </div>
                                            </a>
                                        </li>
                                        <?php
                                    }
                                    ?>
                                </ul>
                            </div>
							<!-- Subscribe Block -->
							<div class="subscribe-block fwd">
								<h2>Subscribe</h2>
								<p>Get all latest content deliverd to your email a few times a month</p>
								<form class="subscribe-form fwd">
									<input type="email" class="input-textbox" id="InputEmail" placeholder="Email">
									<button type="submit" class="submit-btn"><i class="fas fa-arrow-right"></i></button>
								</form>
							</div>
							<!-- Tags Block -->
							<div class="tags-block fwd">
								<h2 class="headding-01">Tags</h2>
								<ul class="list-inline tags-links">
									<li><a href="#">Fashion</a></li>
									<li><a href="#">Lifestyle</a></li>
									<li><a href="#">Denim</a></li>
									<li><a href="#">Streetstyle</a></li>
									<li><a href="#">Crafts</a></li>
									<li><a href="#">Magzine</a></li>
									<li><a href="#">News</a></li>
									<li><a href="#">Blogs</a></li>
								</ul>
							</div>
						</div>
					</div>
				</section>
				<div class="clrfix"></div>
			</div>
			<!-- END CONTAINER -->
