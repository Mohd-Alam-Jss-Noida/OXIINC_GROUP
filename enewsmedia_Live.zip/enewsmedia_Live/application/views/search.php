	<?php		
	$no_image_path = ASSET_URL. "/assets/news/".''."no_image.png";

	?>
	
	<style>
    	/*.address_color
    	{
    		background: linear-gradient(20deg, #f84270 0%, #fe803b 100%)!important;padding: 19px;color:white;
        }*/

        .address_color
        {
        	background: #171616 !important;
    		padding: 19px;
    		color: white;
		}
    </style>
	<div class="gap-30"></div>

	<?php
		//echo "<pre> --- RECENT --- "; print_r($recent_data); echo "</pre>";
		//echo "<pre> --- POPULAR --- "; print_r($popular_data); echo "</pre>";
		//echo "<pre> --- COMMENT ---"; print_r($comment_data); echo "</pre>";

	//print_r($search_listing); exit();
	?>
	<div class="container">
		<div class="row">
			<div class="col-12">	
			<h2>Search Result </h2>
			</div>
		</div>
	</div>
	<div class="gap-30"></div>
<section class="main-content category-layout-1 pt-0">
		<br>
		<div class="container">
	<div class="tab-pane animated fadeInRight" id="post_tab_b">
		<div class="list-post-block">
			<ul class="list-post">
				<?php foreach($search_listing as $key => $value) { 
					$show_image = isset($search_listing[$key]['image']) ? ASSET_URL."/assets/news/".''.$search_listing[$key]['image'] : $no_image_path;
					$video_thumb_img = isset($search_listing[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$search_listing[$key]['video_thumb_img'] : $no_image_path;
					
					?>
				<li>
					<div class="post-block-style media">
						<div class="post-thumb">
							<?php if(isset($search_listing[$key]['media_type']) && $search_listing[$key]['media_type'] == 'video') {
					 			?>
							<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="" style="height: -webkit-fill-available;">
							<a class="popup cboxElement" href="<?php echo $show_image; ?>">
								<div class="video-icon">
									<i class="fa fa-play"></i>
								</div>
							</a>
					<?php } else { ?>
							<a href="#">
								<img class="img-fluid" src="<?php echo $show_image; ?>" alt="">
							</a>
					<?php } ?>
						</div><!-- Post thumb end -->

						<div class="post-content media-body">
							<div class="grid-category">
								<a class="post-cat travel-color" href="#"><?php if($website_language == '0') { echo $search_listing[$key]['category_hindi_name']; } else { echo $search_listing[$key]['category_name']; } ?></a>
							</div>
							<h2 class="post-title">
								<a href="#" onclick="view_details('<?php echo $search_listing[$key]['id']; ?>', 'news')">
									<?php if($website_language == '0') { echo (strlen($search_listing[$key]['hindi_name']) > 50) ? substr($search_listing[$key]['hindi_name'], 0, 50).' '."..." : $search_listing[$key]['hindi_name']; } else { echo (strlen($search_listing[$key]['name']) > 50) ? substr($search_listing[$key]['name'], 0, 50).' '."..." : $search_listing[$key]['name']; } ?></a>
							</h2>
							<div class="post-meta mb-7">
								<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($search_listing[$key]['created']) && !empty($search_listing[$key]['created']) ? date('d F, Y', strtotime($search_listing[$key]['created'])) : ''; ?></span>								
							</div>
							</div><!-- Post content end -->
					</div><!-- Post block style end -->
				</li><!-- Li 1 end -->	
				<?php } ?>			
			</ul><!-- List post end -->
		</div>
	</div>
</div>
</section>
	