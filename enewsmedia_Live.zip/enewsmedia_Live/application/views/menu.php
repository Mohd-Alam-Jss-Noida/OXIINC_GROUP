<div class="main-nav clearfix is-ts-sticky">
	<div class="container">
		<div class="row justify-content-between">
			<nav class="navbar navbar-expand-lg col-lg-11">
				<div class="site-nav-inner float-left">
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
						<span class="fa fa-bars"></span>
					</button>
				   	<div id="navbarSupportedContent" class="collapse navbar-collapse navbar-responsive-collapse">
						

						<!-- <ul class="nav navbar-nav">
							<li class="nav-item dropdown active"><a href="<?php //echo base_url(); ?>">होम</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle menu-dropdown" data-toggle="dropdown">न्यूज़ <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu" role="menu">
									<li><a href="#">देश</a></li>
									<li><a href="#">दुनिया</a></li>
									<li><a href="#">खेल</a></li>
									<li><a href="#">कारोबार</a></li>
									<li><a href="#">राज्यों से</a></li>
								</ul>
							</li>
							<li class="nav-item dropdown active"><a href="#">सिनेमा</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle menu-dropdown" data-toggle="dropdown">फोटो <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu" role="menu">
									<li><a href="#">मनोरंजन</a></li>
									<li><a href="#">खेल</a></li>
									<li><a href="#">बिजनेस</a></li>
									<li><a href="#">दुनिया</a></li>
									<li><a href="#">लाइफस्टाइल</a></li>
									<li><a href="#">रिलेशनशिप</a></li>
									<li><a href="#">धर्म</a></li>
									<li><a href="#">देश</a></li>
								</ul>
							</li>
							<li class="nav-item dropdown active"><a href="#">वीडियो</a></li>
							<li class="nav-item dropdown active"><a href="#">गैजेट्स</a></li>
							<li class="nav-item dropdown active"><a href="#">कोरोना</a></li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle menu-dropdown" data-toggle="dropdown">LIVE TV <i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu" role="menu">
									<li><a href="#">EnewsMedia</a></li>
									<li><a href="#">EnewsMedia HD</a></li>
								</ul>
							</li>
						</ul> -->

						<!-- NEW MENU LIST -->

						<ul class="nav navbar-nav">
							<li class="nav-item dropdown active"><a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a></li>
							<?php
								//echo $website_language;
								//echo "<pre>"; print_r($menu_data); echo "</pre>"; exit();
								$menu_sub_category_data = array();
								foreach($menu_data as $key => $value)
                                {
                                	$menu_sub_category_data = $menu_data[$key]['sub_category_details'];
                                	?>
                                	<li <?php if(isset($menu_sub_category_data) && !empty($menu_sub_category_data)) { ?> class="dropdown" <?php } else { ?> class="nav-item dropdown active" <?php } ?>>
										<?php
											if(isset($menu_sub_category_data) && !empty($menu_sub_category_data))
											{
												?>
												<a href="#" class="dropdown-toggle menu-dropdown" data-toggle="dropdown"><?php if($website_language == '0') { echo $menu_data[$key]['hindi_name']; } else { echo $menu_data[$key]['name']; } ?> <i class="fa fa-angle-down"></i></a>
												<ul class="dropdown-menu" role="menu">
													<?php
														foreach($menu_sub_category_data as $menu_sub_category_data_key => $menu_sub_category_data_value)
														{
															?>
															<li>
																<a href="#" onclick="view_list('<?php echo $menu_sub_category_data[$menu_sub_category_data_key]['id']; ?>', 'sub_category', 1)"><?php if($website_language == '0') { echo $menu_sub_category_data[$menu_sub_category_data_key]['hindi_name']; } else { echo $menu_sub_category_data[$menu_sub_category_data_key]['name']; } ?>
																</a>
															</li>
															<?php
														}
													?>
												</ul>
												<?php
										    }
											else
											{
												?>
												<a href="#" onclick="view_list('<?php echo $menu_data[$key]['id']; ?>', 'category', 0)"><?php if($website_language == '0') { echo $menu_data[$key]['hindi_name']; } else { echo $menu_data[$key]['name']; } ?></a> <?php
											}
										?>
                                	</li>
                                	<?php
                                }
							?>
							<!-- <li class="dropdown">
								<a href="#" class="dropdown-toggle menu-dropdown" data-toggle="dropdown">LIVE TV<i class="fa fa-angle-down"></i></a>
								<ul class="dropdown-menu" role="menu">
									<li><a href="#">EnewsMedia</a></li>
									<li><a href="#">EnewsMedia HD</a></li>
								</ul>
							</li> -->
						</ul>
						
						<!-- NEW MENU LIST -->
					</div>
				</div>
			</nav>
			<div class="col-lg-1 text-right nav-social-wrap">
				<!-- <div class="top-social">
					<ul class="social list-unstyled">
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
						 <li><a href="#"><i class="fa fa-instagram"></i></a></li>
						<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
					</ul>
				</div>
				 --><div class="nav-search">
					<a href="#search-popup" class="xs-modal-popup">
						<i class="icon icon-search1"></i>
					</a>
				</div>
				<div class="zoom-anim-dialog mfp-hide modal-searchPanel ts-search-form" id="search-popup">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="xs-search-panel">
								<form class="ts-search-group" action="<?php echo base_url('search');?>/">
									<div class="input-group">
										<input type="search" class="form-control" name="s" id="searchInput" placeholder="Search" value="">
										<button class="input-group-btn search-button">
											<i class="icon icon-search1"></i>
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="gap-30"></div>

<script type="text/javascript">

	function view_list(id, page,sub_cat_id_flag)
    {
        window.location = "<?php echo base_url('view_list'); ?>/" + id + "/" + page+"/"+sub_cat_id_flag;
    }

    function view_details(id, page)
    {
    	/*alert('here');
        alert(id);
        alert(page);*/
        window.location = "<?php echo base_url('temp_front_session'); ?>/" + id + "/" + page;
        
    }
    
    function feed_details(id)
    {
      var cat_name = $('#'+id).attr("data-name");
      var title = $('#'+id).attr("data-title");
      var image = $('#'+id).attr("data-image");
  		var desciption = $('#'+id).attr("data-desciption");
  		var created = $('#'+id).attr("data-created");
  		$.ajax({
  			type:'POST',
  			url:'<?php echo base_url('feed/save_data'); ?>',
  			data:{cat_name: cat_name,title: title, image: image, desciption: desciption, created:created},
  			success:function(data){
  				//alert(data)
          	var obj = JSON.parse(data);
          	//alert(obj.status);
          	if(obj.status == 'error')
          	{
          		
          	}
          	if(obj.status == 'success')
          	{
          		window.location = "<?php echo base_url('feed'); ?>/";
          	}
  			}
  		});        
    }

    function view_all_feed(catgory){
    		window.location = "<?php echo base_url('all_feed'); ?>/" + catgory + "/";
    }

</script>