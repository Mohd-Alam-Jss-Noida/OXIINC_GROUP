	<?php
		if(isset($category_data) && !empty($category_data))
		{
			//echo "WEBSITE LANGUAGE --- ".''.$website_language;
		}

		if(isset($category_data) && !empty($category_data))
		{
			//echo "<pre> --- CATEGORY DATA --- "; print_r($category_data); echo "</pre>";
		}
		if(isset($sub_category_data) && !empty($sub_category_data))
		{
			//echo "<pre> --- SUB CATEGORY DATA --- "; print_r($sub_category_data); echo "</pre>";
		}
		if(isset($related_news) && !empty($related_news))
		{
			//echo "<pre> --- RELATED NEWS DATA --- "; print_r($related_news); echo "</pre>";
		}
		if(isset($recent_happenings) && !empty($recent_happenings))
		{
			//echo "<pre> --- RECENT HAPPENINGS DATA --- "; print_r($recent_happenings); echo "</pre>";
		}
		if(isset($comment_count) && !empty($comment_count))
		{
			//echo "<pre> --- COMMENT COUNT --- "; print_r($comment_count); echo "</pre>";
		}

		// SET VARIABLE VALUE
		$category_id = $sub_category_id = $menu_image = $menu_details = $menu_status = $menu_date = $counter = '';
		$category_id = isset($category_data['id']) && !empty($category_data['id']) ? $category_data['id'] : $sub_category_data['category_id'];
		$sub_category_id = isset($sub_category_data['id']) && !empty($sub_category_data['id']) ? $sub_category_data['id'] : '';
		$menu_category_name = isset($category_data['name']) && !empty($category_data['name']) ? $category_data['name'] : $sub_category_data['category_name'];
		$menu_category_hindi_name = isset($category_data['hindi_name']) && !empty($category_data['hindi_name']) ? $category_data['hindi_name'] : $sub_category_data['category_hindi_name'];
		//$menu_sub_category_name = isset($sub_category_data['name']) && !empty($sub_category_data['name']) ? $sub_category_data['name'] : '';
		//$menu_sub_category_hindi_name = isset($sub_category_data['hindi_name']) && !empty($sub_category_data['hindi_name']) ? $sub_category_data['hindi_name'] : '';
		$menu_sub_category_name = isset($sub_category_data['sub_category_name']) && !empty($sub_category_data['sub_category_name']) ? $sub_category_data['sub_category_name'] : $sub_category_data['name'];
		$menu_sub_category_hindi_name = isset($sub_category_data['sub_category_hindi_name']) && !empty($sub_category_data['sub_category_hindi_name']) ? $sub_category_data['sub_category_hindi_name'] : $sub_category_data['hindi_name'];
		
		$menu_image = isset($category_data['image']) && !empty($category_data['image']) ? $category_data['image'] : $sub_category_data['image'];
		$menu_details = isset($category_data['details']) && !empty($category_data['details']) ? $category_data['details'] : $sub_category_data['details'];
		$menu_hindi_details = isset($category_data['hindi_details']) && !empty($category_data['hindi_details']) ? $category_data['hindi_details'] : $sub_category_data['hindi_details'];

		$menu_title = isset($sub_category_data['name']) && !empty($sub_category_data['name']) ? $sub_category_data['name'] : $menu_details;
		$menu_hindi_title = isset($sub_category_data['hindi_name']) && !empty($sub_category_data['hindi_name']) ? $sub_category_data['hindi_name'] : $menu_hindi_details;
		$media_type = isset($sub_category_data['media_type']) && !empty($sub_category_data['media_type']) ? $sub_category_data['media_type'] : '';

		$menu_status = isset($category_data['status']) && !empty($category_data['status']) ? $category_data['status'] : $sub_category_data['status'];
		$menu_date = isset($category_data['created']) && !empty($category_data['created']) ? $category_data['created'] : $sub_category_data['created'];

		// SET COUNTER VARIABLE VALUE
		if(isset($category_data['counter']) && !empty($category_data['counter']))
		{
			$counter = $category_data['counter'];
		}
		else if(isset($sub_category_data['counter']) && !empty($sub_category_data['counter']))
		{
			$counter = $sub_category_data['counter'];
		}
		else
		{
			$counter = '0';
		}
	?>

	<?php
		if(isset($menu_sub_category_name) && !empty($menu_sub_category_name))
		{
			$image_path = "./assets/sub_category/".''.$menu_image;
	        $no_image_path = "./assets/sub_category/".''."no_image.png";
	        $show_image = file_exists("./assets/sub_category/".''.$menu_image) ? $image_path : $no_image_path;
		}
		else
		{
	        $image_path = "./assets/category/".''.$menu_image;
	        $no_image_path = "./assets/category/".''."no_image.png";
	        $show_image = file_exists("./assets/category/".''.$menu_image) ? $image_path : $no_image_path;
		}

		$table_name = 'sub_category';
		if($news_info == 1) {
			$sub_category_id = isset($sub_category_data['sub_category_id']) && !empty($sub_category_data['sub_category_id']) ? $sub_category_data['sub_category_id'] : '';
			$news_id = isset($sub_category_data['id']) && !empty($sub_category_data['id']) ? $sub_category_data['id'] : '';
			$image_path = ASSET_URL."/assets/news/".''.$sub_category_data['image'];
			$video_thumb_img = ASSET_URL."/assets/news/".''.$sub_category_data['video_thumb_img'];
	        $no_image_path = ASSET_URL. "/assets/news/".''."no_image.png";
			//$show_image = file_exists(ASSET_URL."assets/news/".''.$sub_category_data['image']) ? $image_path : $no_image_path;
			$show_image = $image_path;
			$table_name = 'news';

			//echo $image_path; exit();
		}

		//print_r($menu_details); 
		//print_r($related_news); exit();
    ?>

	<div class="gap-30"></div>

	<div class="breadcrumb-section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<ol class="breadcrumb">
						<li>
							<i class="fa fa-home"></i>
								<a href="<?php echo base_url(); ?>"><?php if($website_language == '0') { echo "होम"; } else { echo "Home"; } ?></a>
							<i class="fa fa-angle-right"></i>
						</li>
						<li><?php if($website_language == '0') { echo $menu_category_hindi_name; } else { echo $menu_category_name; } ?></li>
						<li <?php if((isset($menu_sub_category_hindi_name) && !empty($menu_sub_category_hindi_name)) && $sub_id_flag == 1) {} else { ?> style="display: none;" <?php } ?>><i class="fa fa-angle-right"></i>
							<?php if($website_language == '0') { echo $menu_sub_category_hindi_name; } else { echo $menu_sub_category_name; } ?>
						</li>
					</ol>		
				</div>
			</div>
		</div>
	</div>
	
	<section class="block-wrapper pb-lg-0" style="padding: 25px 0;">
		<div class="container">
			<div class="row ts-gutter-30">
				<div class="col-lg-8 col-md-12">
					<div class="single-post">
						<div class="post-header-area">
							<h2 class="post-title title-lg"><?php if($website_language == '0') { echo (strlen($menu_hindi_title) > 75) ? substr($menu_hindi_title, 0, 50).' '."..." : $menu_hindi_title; } else { echo (strlen($menu_title) > 75) ? substr($menu_title, 0, 50).' '."..." : $menu_title; } ?></h2>
							<ul class="post-meta">
								<!-- <li>
									<a href="#" class="post-cat fashion">Lifestyle</a>
								</li> -->
								<!-- <li class="post-author">
									<a href="#"><img src="<?php //echo base_url();?>assets/images/news/e_author.png"><strong><?php //if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></strong></a>
								</li> -->
								<li><i class="fa fa-clock-o"></i> <?php echo date('d F, Y', strtotime($menu_date)); ?></li>
								<li><i class="fa fa-comments"></i> <?php echo $comment_count; ?>
									<?php
										if($website_language == '0')
										{ echo ($comment_count > 1) ? 'टिप्पणियाँ' : 'टिप्पणी'; }
										else
										{ echo ($comment_count > 1) ? 'Comments' : 'Comment'; }
									?>
								</li>										
								<li><i class="fa fa-eye"></i> <?php echo $counter; ?></li>
								<li class="social-share">
									<i class="shareicon fa fa-share"></i>
									<ul class="social-list" style="min-width: 230px !important;">
										<li><!-- <a data-social="facebook" class="facebook fb-share-button" href="https://www.facebook.com/share.php?u=http%3A%2F%2Fenewsmedia.in%2F&title=this is sample text" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" rel="nofollow" style="color: #fff; font-size: 18px;"><i class="fa fa-facebook"></i></a> --><a data-social="facebook" class="facebook fb-share-button" data-href="https://www.facebook.com/share.php?u=http%3A%2F%2Fenewsmedia.in%2F" data-title="<?php if($website_language == '0') { echo $menu_hindi_title; } else { echo $menu_title; } ?>" data-image="<?php echo (isset($media_type) && $media_type == 'video') ? $video_thumb_img : $show_image; ?>" target="_blank" rel="nofollow" style="color: #fff; font-size: 18px;"><i class="fa fa-facebook"></i></a>
										</li>
										<li><a data-social="twitter" class="twitter" href="https://twitter.com/intent/tweet?text=<?php if($website_language == '0') { echo $menu_hindi_title; } else { echo $menu_title; } ?>&url=<?php echo base_url(); ?>&hashtags=enewsmedia" style="color: #fff; font-size: 18px;" onclick="javascript:window.open(this.href,'_blank', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i></a></li>
										<li><a data-social="youtube" class="youtube" href="#" style="color: #fff; font-size: 18px;"><i class="fa fa-youtube-play"></i></a></li>
										<li><a data-social="linkedin" class="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=http%3A%2F%2Fenewsmedia.in%2F&title=<?php if($website_language == '0') { echo $menu_hindi_title; } else { echo $menu_title; } ?>&summary=http%3A%2F%2Fenewsmedia.in%2F&source=Enewsmedia" style="color: #fff; font-size: 18px;" onclick="javascript:window.open(this.href,'_blank', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;" target="_blank"><i class="fa fa-linkedin"></i></a></li>
									</ul>
								</li>
							</ul>							
						</div>
						<div class="post-content-area">
							<?php if(isset($media_type) && $media_type == 'video') { ?>
								<div class="post-block-style media">
									<div class="post-thumb post-media mb-20" style="text-align: center;">
										<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="" style="height: -webkit-fill-available;">
										<a class="popup cboxElement" href="<?php echo $show_image; ?>">
											<div class="video-icon">
												<i class="fa fa-play"></i>
											</div>
										</a>
									</div><!-- Post thumb end -->
								</div>
							<?php } else { ?>
							<div class="post-media mb-20" style="text-align: center;">
								<a href="<?php echo $show_image; ?>" class="gallery-popup cboxElement">
									<img src="<?php echo $show_image; ?>" class="img-fluid" alt="">
								</a>
							</div>
					<?php } ?>
							<p style="text-align: justify;"><?php if($website_language == '0') { echo $menu_hindi_details; } else { echo $menu_details; } ?></p>
						</div>
						<div class="post-footer">
							<div class="gap-30"></div>
							<div class="related-post" <?php if(!isset($related_news) && empty($related_news)) { ?> style="display: none;" <?php } ?>>
								<h2 class="block-title">
									<span class="title-angle-shap"><?php if($website_language == '0') { echo "सम्बंधित खबर"; } else { echo "Related News"; } ?></span>
								</h2>
								<div class="row">
									<?php
										foreach($related_news as $key => $value)
                    {
                    	?>
											<div class="col-md-6">
												<div class="post-block-style" style="padding-bottom:20px;">
													<div class="post-thumb">
														<?php
															$image_path = ASSET_URL."/assets/news/".''.$related_news[$key]['image'];
													        $no_image_path = ASSET_URL."/assets/news/".''."no_image.png";
													        $show_image = file_exists("./assets/news/".''.$related_news[$key]['image']) ? $image_path : $no_image_path;
													        $video_thumb_img = file_exists("./assets/news/".''.$related_news[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$related_news[$key]['video_thumb_img'] : $no_image_path;

													        if($news_info == 1){
						                    		$show_image = isset($related_news[$key]['image']) ? ASSET_URL."/assets/news/".''.$related_news[$key]['image'] : $no_image_path;
						                    	}
                    	
														?>
														<?php if(isset($related_news[$key]['media_type']) && $related_news[$key]['media_type'] == 'video') { ?>
																		<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="">
																		<a class="popup cboxElement" href="<?php echo $show_image; ?>">
																			<div class="video-icon">
																				<i class="fa fa-play"></i>
																			</div>
																		</a>
															<?php } else { ?>
															<a href="#" onclick="view_details('<?php echo $related_news[$key]['id']; ?>', '<?php echo $table_name; ?>')">
															<img class="img-fluid" src="<?php echo $show_image; ?>" alt="">
														</a>
													<?php } ?>
														<div class="grid-cat">
															<a class="post-cat tech" href="#"><?php if($website_language == '0') { echo $menu_category_hindi_name; } else { echo $menu_category_name; } ?></a>
														</div>
													</div>
													<div class="post-content">
														<h2 class="post-title">
															<a href="#" onclick="view_details('<?php echo $related_news[$key]['id']; ?>', '<?php echo $table_name; ?>')">
																<?php if($website_language == '0') { 
																				if(strlen($related_news[$key]['hindi_name']) > 50){
																						echo substr($related_news[$key]['hindi_name'], 0, 50)."...";
																				}else{
																					echo $related_news[$key]['hindi_name'];
																				}
																			}else{
																				if(strlen($related_news[$key]['name']) > 50){
																					echo substr($related_news[$key]['name'], 0, 50)."...";
																				}else{
																					echo $related_news[$key]['name'];
																				}
																			}

																	//echo (strlen($related_news[$key]['hindi_details']) > 50) ? substr($related_news[$key]['hindi_details'], 0, 50).' '."..." : $related_news[$key]['hindi_details']; } else { echo (strlen($related_news[$key]['details']) > 50) ? substr($related_news[$key]['details'], 0, 50).' '."..." : $related_news[$key]['details']; }

																//echo $value['details'];?>
															</a>
														</h2>
														<div class="post-meta mb-7 p-0">
															<!-- <span class="post-date"><img alt="" src="<?php //echo base_url();?>assets/images/news/e_author.png" width="25px"><strong> <?php //if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></strong></span> -->
															<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($related_news[$key]['created']) && !empty($related_news[$key]['created']) ? date('d F, Y', strtotime($related_news[$key]['created'])) : ''; ?></span>
														</div>
													</div>
												</div>
											</div>
											<?php
										}
									?>
								</div>
							</div>
							<div class="gap-30"></div>
														
							<div class="gap-50 d-none d-md-block"></div>
							<div class="comments-form">
								<h3 class="title-normal"><?php if($website_language == '0') { echo "टिप्पणी दें"; } else { echo "Leave Comment"; } ?></h3>
								<label id="comment_error" class="error_red" style="font-weight: normal !important;">&nbsp;</label>
								<label id="comment_msg" class="error_blue" style="font-weight: normal !important;">&nbsp;</label>
								<div class="row">
									<div class="col-md-12">
										<div class="form-group">
											<textarea class="form-control input-msg required-field" name="user_comment" id="user_comment" placeholder="<?php if($website_language == '0') { echo "आपकी टिप्पणी"; } else { echo "Your Comment"; } ?>" rows="10" data-id="comment"></textarea>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input class="form-control" name="user_name" id="user_name" placeholder="<?php if($website_language == '0') { echo "आपका नाम"; } else { echo "Your Name"; } ?>" type="text" onKeyPress="return space_capital_small_alphabets(event)" data-id="comment">
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
											<input class="form-control" name="user_email" id="user_email" placeholder="<?php if($website_language == '0') { echo "तुम्हारा ईमेल"; } else { echo "Your Email"; } ?>" type="email" onKeyPress="return avoid_space(event)" data-id="comment">
										</div>
									</div>
									<!-- <div class="col-md-12">
										<div class="form-group">
											<input class="form-control" name="user_website" id="user_website" placeholder="Your Website" type="text" onKeyPress="return avoid_space(event)" data-id="comment">
										</div>
									</div> -->
								</div>
								<div class="clearfix">
									<button class="comments-btn btn btn-primary" id="post_comment" name="post_comment"><?php if($website_language == '0') { echo "टिप्पणी पोस्ट करें"; } else { echo "Post Comment"; } ?></button>
								</div>
							</div>
						</div>	
					</div>		
				</div>

				<div class="col-lg-4">
					<div class="sidebar">
						<div class="sidebar-widget social-widget">
							<h2 class="block-title">
								<span class="title-angle-shap"> <?php if($website_language == '0') { echo "सामाजिक"; } else { echo "Social"; } ?></span>
							</h2>
							<div class="sidebar-social">
								<ul class="ts-social-list style2">
									<li class="ts-facebook">
										<a href="#">
											<i class="tsicon fa fa-facebook"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "फेसबुक"; } else { echo "Facebook"; } ?></b>
												<span><?php if($website_language == '0') { echo "पसंद"; } else { echo "Likes"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-twitter">
										<a href="#">
											<i class="tsicon fa fa-twitter"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "ट्विटर"; } else { echo "Twitter"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-youtube">
										<a href="#">
											<i class="tsicon fa fa-youtube-play"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "यूट्यूब"; } else { echo "Youtube"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
									<li class="ts-rss">
										<a href="#">
											<i class="tsicon fa fa-linkedin"></i>
											<div class="count">
												<b><?php if($website_language == '0') { echo "लिंक्डइन"; } else { echo "Linkdin"; } ?></b>
												<span><?php if($website_language == '0') { echo "समर्थक"; } else { echo "Follwers"; } ?></span>
											</div>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<div class="post-block-style clearfix" style="padding-bottom: 25px;">
							<h2 class="block-title">
								<?php //echo $recent_happenings; ?>
								<span class="title-angle-shap"><?php if($website_language == '0') { echo "हाल ही में हुआ"; } else { echo "Recent Happenings"; } ?></span>
							</h2>
						</div>
						<?php
							foreach($recent_happenings as $key => $value)
              {
              	$image_path = ASSET_URL."/assets/news/".''.$recent_happenings[$key]['image'];
			        $no_image_path = "./assets/news/".''."no_image.png";
			        $show_image = file_exists("./assets/news/".''.$recent_happenings[$key]['image']) ? $image_path : $no_image_path;
			        $video_thumb_img = file_exists("./assets/news/".''.$recent_happenings[$key]['video_thumb_img']) ? ASSET_URL."/assets/news/".''.$recent_happenings[$key]['video_thumb_img'] : $no_image_path;

			        $table_name = 'news';
                            	?>
								<div class="post-block-style clearfix" style="padding-bottom: 25px;">
									<div class="post-thumb">
										<?php if(isset($recent_happenings[$key]['media_type']) && $recent_happenings[$key]['media_type'] == 'video') { ?>
												<img class="img-fluid" src="<?php echo $video_thumb_img; ?>" alt="">
												<a class="popup cboxElement" href="<?php echo $show_image; ?>">
													<div class="video-icon">
														<i class="fa fa-play"></i>
													</div>
												</a>
									<?php } else { ?>															
										<a href="#" onclick="view_details('<?php echo $recent_happenings[$key]['id']; ?>', '<?php echo $table_name; ?>')">
											<img class="img-fluid" src="<?php echo $show_image ;?>">
											<div class="grid-cat"><a class="post-cat" href="#"><?php if($website_language == '0') { echo $recent_happenings[$key]['category_hindi_name']; } else { echo $recent_happenings[$key]['category_name']; } ?></a></div>
										</a>
									<?php } ?>
									</div>
									<div class="post-content">
										<h2 class="post-title title-md">
											<a href="#" onclick="view_details('<?php echo $recent_happenings[$key]['id']; ?>', '<?php echo $table_name; ?>')">
												<?php if($website_language == '0') { echo (strlen($recent_happenings[$key]['hindi_name']) > 50) ? substr($recent_happenings[$key]['hindi_name'], 0, 40).' '."..." : $recent_happenings[$key]['hindi_name']; } else { echo (strlen($recent_happenings[$key]['name']) > 50) ? substr($recent_happenings[$key]['name'], 0, 40).' '."..." : $recent_happenings[$key]['name']; } ?>
											</a>
										</h2>
										<div class="post-meta mb-7">
											<!-- <span class="post-author"><a href="#"><i class="fa fa-user"></i> &nbsp; <?php //if($website_language == '0') { echo "व्यवस्थापक"; } else { echo "Admin"; } ?></a></span> -->
											<span class="post-date"><i class="fa fa-clock-o"></i> <?php echo isset($recent_happenings[$key]['created']) && !empty($recent_happenings[$key]['created']) ? date('d F, Y', strtotime($recent_happenings[$key]['created'])) : ''; ?></span>
										</div>
									</div>
								</div>
                            	<?php
                            }
                        ?>
						<div class="gap-10 d-none d-lg-block"></div>
					</div>
				</div>
			</div>
		</div>
		<input type="hidden" name="hid_website_language" id="hid_website_language" value="<?php echo $website_language; ?>">
		<input type="hidden" name="hid_category_id" id="hid_category_id" value="<?php echo $category_id; ?>">
		<input type="hidden" name="hid_sub_category_id" id="hid_sub_category_id" value="<?php echo $sub_category_id; ?>">
		<input type="hidden" name="hid_news_id" id="hid_news_id" value="<?php echo $news_id; ?>">
	</section>

	<script src="<?php echo ASSET_URL; ?>/assets/js/jquery.js"></script>
	<script type="text/javascript">
		function space_capital_small_alphabets(e)
        {
            var unicode=e.charCode? e.charCode : e.keyCode
            if (unicode!=8) //if the key isn't the backspace key (which we should allow)
            { 
                if ((unicode<65||unicode>90) && (unicode<97||unicode>122) && (unicode!=32)) //if not a number
                    return false //disable key press
            }
        }

		function avoid_space(event)
        {
            var k = event ? event.which : window.event.keyCode;
            if (k == 32) return false;
        }

	    $(document).ready(function() {
	        //alert("VIEW PAGE");
	        $('.facebook').on('click', function(){
	        	var href = $(this).attr("data-href");
	        	var image = $(this).attr("data-image");
	        	var title = $(this).attr("data-title");
	        	$('meta[property="og\\:type"]').remove();
	        	$('meta[property="og\\:description"]').remove();
	        	$('meta[property="og\\:title"]').remove();
	        	$('meta[property="og\\:image"]').remove();
	        	socialShare(href,title,image);
	        	//window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"
	        	//

	        });

	        $("input").keypress(function(event) {
                if(event.which == 13)
                {
                    if($(this).data("id") == 'comment')
                    { comment(); }
                }
            });

            $('#post_comment').click(function(){
		       comment();
		    });

            function socialShare(openLink, shareTitle, shareImage){
            	$('head').append( '<meta property="og:type" content="website" />' );
            	$('head').append( '<meta property="og:description" content="'+shareTitle+'" />' );
            	$('head').append( '<meta property="og:title" content="'+shareTitle+'" />' );
            	$('head').append( '<meta property="og:image" content="'+shareImage+'" />' );

            	setTimeout(function(){
            		window.open(openLink,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');
            		return false;
            		}, 2000);	        	        	
            }

            function comment()
            {
                var chk=0;
                var user_comment = $('#user_comment').val();
                var user_name = $('#user_name').val();
                var user_email = $('#user_email').val();
                //var user_website = $('#user_website').val();
             	var category_id = $('#hid_category_id').val();
             	var website_language = $('#hid_website_language').val();
				var sub_category_id = $('#hid_sub_category_id').val();
				var hid_news_id = $('#hid_news_id').val();

				var email_check = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

                if(document.getElementById('user_comment').value=='')
                {
                    document.getElementById('comment_msg').innerHTML="";
                    if(website_language == '0')
                    	document.getElementById('comment_error').innerHTML="कृपया टिप्पणी दर्ज करें";
                    else
                    	document.getElementById('comment_error').innerHTML="Please enter comment";
                    document.getElementById("user_comment").focus();
                    chk=1;
                }
                else if(document.getElementById('user_name').value=='')
                {
                    document.getElementById('comment_msg').innerHTML="";
                    if(website_language == '0')
                    	document.getElementById('comment_error').innerHTML="कृपया नाम दर्ज करें";
                    else
                    	document.getElementById('comment_error').innerHTML="Please enter name";
                    document.getElementById("user_name").focus();
                    chk=1;
                }
                else if(document.getElementById('user_email').value=='')
                {
                	document.getElementById('comment_msg').innerHTML="";
                    if(website_language == '0')
                    	document.getElementById('comment_error').innerHTML="कृपया ईमेल दर्ज करें";
                    else
                    	document.getElementById('comment_error').innerHTML="Please enter email";
                    document.getElementById("user_email").focus();
                    chk=1;
                }
                else if(email_check.test(user_email) === false)
			    {
			    	document.getElementById('comment_msg').innerHTML="";
                    if(website_language == '0')
                    	document.getElementById('comment_error').innerHTML="अवैध ईमेल";
                    else
                    	document.getElementById('comment_error').innerHTML="Invaild email";
                    document.getElementById("user_email").focus();
                    chk=1;
                }

                if(chk==1)
                {
                    return false;
                }
                else
                {
	            	$.ajax({
		      			type:'POST',
		      			url:'<?php echo base_url('home/add_comment'); ?>',
		     			data:{category_id: category_id, sub_category_id: sub_category_id, comment: user_comment, name: user_name, email: user_email},
		      			success:function(data){
		      				//alert(data)
				          	var obj = JSON.parse(data);
				          	//alert(obj.status);
				          	if(obj.status == 'error')
				          	{
				          		document.getElementById('comment_error').innerHTML=obj.message;
				          	}
				          	if(obj.status == 'success')
				          	{
				          		document.getElementById('comment_error').innerHTML="";
				          		if(website_language == '0')
			                    	document.getElementById('comment_error').innerHTML="आपकी टिप्पणी सफलतापूर्वक जुड़ गई";
			                    else
			                    	document.getElementById('comment_error').innerHTML="Your comment added successfully";
                                setTimeout(function(){
                            		window.location.reload();
                                }, 3000);
				          	}
		      			}
		      		});
                }
            }

	        var refreshId = setInterval(function() {
	        	//alert('ADD VIEW PAGE COUNTER IN DB')
	        	var category_id = $('#hid_category_id').val();
				var sub_category_id = $('#hid_sub_category_id').val();
				var news_id = $('#hid_news_id').val();

				//alert(category_id);
				//alert(sub_category_id);
				$.ajax({
	      			type:'POST',
	      			url:'<?php echo base_url('home/view_counter'); ?>',
	      			data:{category_id: category_id, sub_category_id: sub_category_id, news_id: news_id},
	      			success:function(data){
	      				//alert(data)
			          	var obj = JSON.parse(data);
			          	//alert(obj.status);
			          	if(obj.status == 'error')
			          	{
			          		//document.getElementById('about_us_error').innerHTML="<p>Error</p>";
			          	}
			          	if(obj.status == 'success')
			          	{
			          		//document.getElementById('about_us_msg').innerHTML="<p>Success</p>";
			          	}
	      			}
	      		});
	        }, 60000); // 10000 = 10 SECONDS, 60000 = 1 MINUTES
	    });
</script>