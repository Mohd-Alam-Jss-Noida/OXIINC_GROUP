<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Enews extends CI_Controller {
	function __construct() {
		parent::__construct();
		error_reporting(E_ALL);
        ini_set('display_errors', 1);
        $this->load->helper('text');
		$this->load->model('Enews_model');
		date_default_timezone_set("Asia/Calcutta");
	}

	public function index() {
		$data = array();
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['recent_happenings'] = $this->Enews_model->get_recent_happenings_data();	
		$data['all_categories_data'] = $this->Enews_model->fetch_all_category_data_front();
		$data['all_data'] = $this->Enews_model->fetch_all_data_front();
		$data['all_feed_categories'] = $this->Enews_model->all_feed_categories();
		//if(isset($_GET['data']) && $_GET['data'] == 1)
		$data['feed_data'] = $this->Enews_model->rss_feed();
		$data['corona_count'] = $this->Enews_model->corona_updates();
		$data['menu_id'] = 'Home';
		$data['popular'] = $this->Enews_model->get_popular_data();
		$data['title'] = 'Enewsmedia - The Power Of Information';

		$today = date("D, d M Y");
		$feedArr = array('1061' => 'national', '1125' => 'international','11215' => 'bollywood', '1053' => 'sports','3379' => 'jeevan_mantra', '1051' => 'business','10711' => 'auto', '7911' => 'happy_life');

		//CODE FOR NATIONAL BANNER
		$feed_national = $data['feed_data']['national'];
		if(isset($feed_national) && !empty($feed_national)){
			$banner_national = array();
			foreach($feed_national as $key => $value){
				$pub_date = explode(" ",$value['@attributes']['pubDate']);
				$pubDate = $pub_date[3]." ".$pub_date[4]." ".$pub_date[5]." ".$pub_date[6];
				if ($today == $pubDate) {
					$banner_national[] = $value;
				}
			}
			if (count($banner_national) > 1) {
				shuffle($banner_national);
				$data['feed_data_national'] = $banner_national[0];
			}
			else{
				shuffle($feed_national);
				$data['feed_data_national'] = $feed_national[0];
			}
		}

		//CODE FOR INTERNATIONAL BANNER
		$data['feed_international'] = $data['feed_data']['international'];
		if(isset($data['feed_international']) && !empty($data['feed_international'])){
			$banner_international = array();
			foreach($data['feed_international'] as $key => $value){
				$pub_date = explode(" ",$value['@attributes']['pubDate']);
				$pubDate = $pub_date[3]." ".$pub_date[4]." ".$pub_date[5]." ".$pub_date[6];
				if ($today == $pubDate) {
					$banner_international[] = $value;
				}
			}
			if (count($banner_international) > 1) {
				shuffle($banner_international);
				$data['feed_data_international'] = $banner_international[0];
			}
			else{
				shuffle($data['feed_international']);
				$data['feed_data_international'] = $data['feed_international'][0];
			}
		}

		//CODE FOR BOLLYWOOD BANNER
		$data['feed_bollywood'] = $data['feed_data']['bollywood'];
		if(isset($data['feed_bollywood']) && !empty($data['feed_bollywood'])){
			$banner_bollywood = array();
			foreach($data['feed_bollywood'] as $key => $value){
				$pub_date = explode(" ",$value['@attributes']['pubDate']);
				$pubDate = $pub_date[3]." ".$pub_date[4]." ".$pub_date[5]." ".$pub_date[6];
				if ($today == $pubDate) {
					$banner_bollywood[] = $value;
				}
			}
			if (count($banner_bollywood) > 1) {
				shuffle($banner_bollywood);
				$data['feed_data_bollywood'] = $banner_bollywood[0];
			}
			else{
				shuffle($data['feed_bollywood']);
				$data['feed_data_bollywood'] = $data['feed_bollywood'][0];
			}
		}

		//CODE FOR SPORTS BANNER
		$feed_sports = $data['feed_data']['sports'];
		if(isset($feed_sports) && !empty($feed_sports)){
			$banner_sports = array();
			foreach($feed_sports as $key => $value){
				$pub_date = explode(" ",$value['@attributes']['pubDate']);
				$pubDate = $pub_date[3]." ".$pub_date[4]." ".$pub_date[5]." ".$pub_date[6];
				if ($today == $pubDate) {
					$banner_sports[] = $value;
				}
			}
			if (count($banner_sports) > 1) {
				shuffle($banner_sports);
				$data['feed_data_sports'] = $banner_sports[0];
			}
			else{
				shuffle($feed_sports);
				$data['feed_data_sports'] = $feed_sports[0];
			}
		}

		$data['feed_business'] = $data['feed_data']['business'];

		$data['category_name'] = $feedArr;

		//echo "<pre>";print_r($data['corona_count']);die();
        $data['main_containt'] = 'index';
        $this->load->view('new_user/containt', $data);
	}

	public function post(){
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['load_page']='post';
        $this->load->view('load_page', $data);
	}

	public function view_list(){
		//echo "<pre>";print_r($_SESSION);//die();
		$data = array();
		$temp_session = $this->session->userdata('sub_cat_id');
		if(isset($temp_session) && !empty($temp_session)){
			//echo "Y";die();
			$temporary_array_key_unset = array('sub_cat_id');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
	        $data['sub_cat_id'] = $this->uri->segment(3);
	        $data['table'] = $this->uri->segment(4);
	        $data['sub_id_flag'] = $this->uri->segment(5);
	        $data['menu_id'] = $this->uri->segment(6);
	        $this->session->set_userdata($data);
		}
		else{
			//echo "N";die();
	        $data['sub_cat_id'] = $this->uri->segment(3);
	        $data['table'] = $this->uri->segment(4);
	        $data['sub_id_flag'] = $this->uri->segment(5);
	        $data['menu_id'] = $this->uri->segment(6);
	        $this->session->set_userdata($data);
		}
		?>
			<script type="text/javascript">
				window.location = "<?php echo base_url('Enews/news_lists'); ?>";
		    </script>
		<?php
	}

	public function news_lists(){
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$id = $this->session->userdata('sub_cat_id');
		$table = $this->session->userdata('table');
		$sub_id_flag = $this->session->userdata('sub_id_flag');	
		$data['menu_id'] = $this->session->userdata('menu_id');
		$data['corona_count'] = $this->Enews_model->corona_updates();
		$data['news_listing'] = $this->Enews_model->fetch_news_listing($id, $sub_id_flag);

		//1 = subcategory present, 0=sub category not present
		if($sub_id_flag == 1){
			$data['category_data'] = $this->Enews_model->get_sub_category_details($id);
		}else{
			$data['category_data'] = $this->Enews_model->category_details($id);		
		}		
		$data['sub_id_flag'] = $sub_id_flag;
		$data['recent_happenings'] = $this->Enews_model->get_recent_happenings_data();
		$data['popular'] = $this->Enews_model->get_popular_data();
		$data['title'] = ($data['website_language'] == '0') ? $data['category_data']['hindi_name'].' News - The Power Of Information' : $data['category_data']['name'].' News - The Power Of Information';
		//echo "<pre>";print_r($data['category_data']);die();
	    $data['main_containt'] = 'news_lists';
        $this->load->view('new_user/containt', $data);
	}

	public function view_details(){
		$data = array();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session)){
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
	        $data['temp'] = $this->uri->segment(3);
	        $data['table'] = $this->uri->segment(4);
	        $data['menu_id'] = $this->uri->segment(5);
	        $this->session->set_userdata($data);
		}
		else{
			//echo "N";
	        $data['temp'] = $this->uri->segment(3);
	        $data['table'] = $this->uri->segment(4);
	        $data['menu_id'] = $this->uri->segment(5);
	        $this->session->set_userdata($data);
		}
		?>
			<script type="text/javascript">
				window.location = "<?php echo base_url('Enews/news_details'); ?>";
		    </script>
		<?php
	}

	public function news_details(){
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$id = $this->session->userdata('temp');
		$table = $this->session->userdata('table');
		$sub_id_flag = $this->session->userdata('sub_id_flag');
		$data['menu_id'] = $this->session->userdata('menu_id');

		$data['comment_count'] = ($table == 'category') ? $this->Enews_model->comment_count('category_id', $id) : $this->Enews_model->comment_count('sub_category_id', $id);
		$data['news_info'] = 0;
		if($table == 'category'){
			$data['category_data'] = $this->Enews_model->category_details($id);		
		}
		else if($table == 'sub_category'){
			$data['sub_category_data'] = $this->Enews_model->get_sub_category_details($id);
			$data['related_news'] = $this->Enews_model->get_all_category_details($data['sub_category_data']['category_id']);
		}
		else if($table == 'news'){
			$data['sub_category_data'] = $this->Enews_model->get_news_details($id);
			//$data['related_news'] = $this->Enews_model->get_all_category_details($data['sub_category_data']['category_id']);
			$data['related_news'] = $this->Enews_model->get_all_related_news($data['sub_category_data']['category_id']);
			$data['news_info'] = 1;
			$data['sub_id_flag'] = $sub_id_flag;
		}
		$data['recent_happenings'] = $this->Enews_model->get_recent_happenings_data();
		$data['popular'] = $this->Enews_model->get_popular_data();
		$data['title'] = ($data['website_language'] == '0') ? $data['sub_category_data']['hindi_name'] : $data['sub_category_data']['name'];
		//echo "<pre>";print_r($data['comment_count']);die();
	    $data['main_containt'] = 'news_details';
        $this->load->view('new_user/containt', $data);
	}

	public function search(){
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$search_keyword = $this->input->get('s');		
		$sub_id_flag = $this->session->userdata('sub_id_flag');		
		$data['recent_happenings'] = $this->Enews_model->get_recent_happenings_data();
		if ($search_keyword) {
			$data['search_listing'] = $this->Enews_model->search_news_data($search_keyword, $data['website_language']);
		}
		else{
			$data['search_listing'] = false;
		}
		$data['popular'] = $this->Enews_model->get_popular_data();
		//echo "<pre>";print_r($data['search_listing']);die();
        $data['main_containt'] = 'search_lists';
        $this->load->view('new_user/containt', $data);
	}

	function view_counter()
	{
		$data = array();
		$category_id = $sub_category_id = $counter = $db_counter = '';
		$category_id = $this->input->post('category_id');
		$sub_category_id = $this->input->post('sub_category_id');
		$news_id = $this->input->post('news_id');

		$category_id = isset($category_id) && !empty($category_id) ? $category_id : '';
		$sub_category_id = isset($sub_category_id) && !empty($sub_category_id) ? $sub_category_id : '';
		$news_id = isset($news_id) && !empty($news_id) ? $news_id : '';

		/*if($category_id!='')
		{
			$table = 'category';
			$counter = $this->Enews_model->check_db_counter($table, $category_id);
			$db_counter = $counter + 1;
			$data['counter'] = $db_counter;
	        $output = $this->Enews_model->change_status($table, $data, 'id = '.$category_id);
	        echo $output;
		}
		if($sub_category_id!='')
		{
			$table = 'sub_category';
			$counter = $this->Enews_model->check_db_counter($table, $sub_category_id);
			$db_counter = $counter + 1;
			$data['counter'] = $db_counter;
	        $output = $this->Enews_model->change_status($table, $data, 'id = '.$sub_category_id);
	        echo $output;
		}*/
		if($news_id!='')
		{
			$table = 'news';
			$counter = $this->Enews_model->check_db_counter($table, $news_id);
			$db_counter = $counter + 1;
			$data['counter'] = $db_counter;
	        $output = $this->Enews_model->change_status($table, $data, 'id = '.$news_id);
	        echo $output;
		}
	}

	function add_comment()
	{
		$data = array();
        $data['category_id'] = $this->input->post('category_id');
        $sub_category_id = $this->input->post('sub_category_id');
        $data['sub_category_id'] = isset($sub_category_id) && !empty($sub_category_id) ? $sub_category_id : '0';
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['comment'] = $this->input->post('comment');
        $data['status'] = '1';
        $result = $this->Enews_model->insert_table_data('comment', $data);
        echo $result;
	}

	function about()
	{
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['about_us'] = $this->Enews_model->fetch_about_us_data_front();
		$data['load_page']='about';
    	$this->load->view('load_page', $data);
    }

    function contact()
	{
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['recent_data'] = $this->Enews_model->get_recent_happenings_data();
		$data['popular_data'] = $this->Enews_model->get_popular_data();
		$data['comment_data'] = $this->Enews_model->fetch_comment_data_front();
		$data['load_page']='contact';
    	$this->load->view('load_page', $data);
    }

    function privacy_policy()
	{
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['privacy_policy'] = $this->Enews_model->fetch_privacy_policy_data_front();
		$data['load_page']='privacy_policy';
    	$this->load->view('load_page', $data);
    }

    function terms_conditions()
	{
		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['terms_conditions'] = $this->Enews_model->fetch_terms_conditions_data_front();
		$data['load_page']='terms_conditions';
    	$this->load->view('load_page', $data);
    }


    function insert_enquiry()
    {
    	$data = $result = array();
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['subject'] = $this->input->post('subject');
        $data['message'] = $this->input->post('message');
        $data['status'] = '1';
        $result = $this->Enews_model->insert_table_data('enquiry', $data);
        if($_SERVER['HTTP_HOST'] != 'localhost')
        {
        	$this->send_enquiry_email($this->input->post('name'), $this->input->post('email'), $this->input->post('subject'), $this->input->post('message'));
        }
        echo $result;
    }

    public function send_enquiry_email($name, $email, $enquiry_subject, $enquiry_message)
	{
		//$enquiry_mail = 'krunal.tailor@oxiinc.in';
		$enquiry_mail = $email;
		//$logo = "./assets/images/logos/logo.png";
		//$logo = base_url('assets/images/logos/logo.png');
		$logo = base_url('assets/images/favicon.png');
		$subject = 'Enquiry On Enewsmedia';
		$emailer = 'email_template/enquiry_mail.html';
		$mail_content = file_get_contents($emailer);
		$logo_url=$logo;
		$fb_url="<i class='fa fa-facebook'></i>";
		$tw_url="<i class='fa fa-twitter'></i>";
		$yt_url="<i class='fa fa-youtube-play'></i>";
		$link_url="<i class='fa fa-linkedin'></i>";
		$mail_content = str_replace('@__logo__@', $logo_url, $mail_content);
		$mail_content = str_replace('@__name__@', $name, $mail_content);
		$mail_content = str_replace('@__email__@', $email, $mail_content);
		$mail_content = str_replace('@__subject__@', $enquiry_subject, $mail_content);
		$mail_content = str_replace('@__message__@', $enquiry_message, $mail_content);
		$mail_content = str_replace('@__fb__@', $fb_url, $mail_content);
		$mail_content = str_replace('@__tw__@', $tw_url, $mail_content);
		$mail_content = str_replace('@__youtube__@', $yt_url, $mail_content);
		$mail_content = str_replace('@__linkedin__@', $link_url, $mail_content);
		$to = array($enquiry_mail);
	    $message = $mail_content;
	    $this->load->config('enewsmedia_email');
        $email_config = $this->config->config['enewsmedia_enquiry'];
        $this->email->initialize($email_config);
        $this->email->clear(); //IMP
        $this->email->from($email_config['smtp_user']);
        if ($_SERVER['HTTP_HOST'] == 'localhost')
        {
            $mailTo = array('amol.patil@oxiincgroup.com'); //send mail to project creators id
        }
        $this->email->to($to);
        //$this->email->cc($cc);
        //$this->email->bcc($bcc);
        if (!empty($this->mailbcc))
        {
            $this->email->bcc($this->mailbcc);
        }
        $this->email->subject($subject);
        $this->email->message($message);
        if ($this->email->send())
        {
        	// echo "<pre>"; print_r($this->email); echo "</pre>";
            return true;
        }
        else
        {
        	// echo "<pre>"; print_r($this->email); echo "</pre>";
            // show_error($this->email->print_debugger());
            return false;
        }
	}

	function logout()
    {
    	$client_array_key_unset = array('temp', 'table');
        $this->session->set_userdata(array('client_logged_in' => FALSE));
        $this->session->sess_destroy();
        $this->session->unset_userdata($client_array_key_unset);
        unset($client_array_key_unset);
        //$this->index();
        ?>
        <script type="text/javascript">
        	var jump_home_page = "<?php echo base_url(); ?>";
            window.location = jump_home_page;
        </script>
        <?php
    }

    //OLD FEED CONTROLLER
	public function category_news(){
		$data = array();
	    $cat_name = $this->uri->segment(3);
	    $this->session->set_userdata('cat_name', $cat_name);
	    $data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
	    $data['feed_data'] = $this->Enews_model->all_rss_feed_of_category($cat_name);
	    $data['recent_happenings'] = $this->Enews_model->get_recent_happenings_data();
	    $data['popular'] = $this->Enews_model->get_popular_data();
	    $data['title'] = ucfirst(str_replace('_', ' ', $cat_name)).' News - The Power Of Information';
		//echo "<pre>";print_r($data['feed_data']);die();
        $data['main_containt'] = 'category_news';
        $this->load->view('new_user/containt', $data);
	}

	public function category_news_details(){
		if($this->input->post()){
            $post_data = $this->input->post();
            if(isset($post_data["cat_name"]) && !empty($post_data["cat_name"]) && isset($post_data["title"]) && !empty($post_data["title"]) && isset($post_data["description"]) && !empty($post_data["description"]) && isset($post_data["image"]) && !empty($post_data["image"]) && isset($post_data["pubDate"]) && !empty($post_data["pubDate"])){

            	$data['cat_name'] 		= $post_data["cat_name"];
            	$data['title'] 			= $post_data["title"];
            	$data['description'] 	= $post_data["description"];
            	$data['image'] 			= $post_data["image"];
            	$data['pubDate'] 		= $post_data["pubDate"];
            	$this->session->set_userdata($data);
            	echo "1";
            }
            else{ echo "0"; }
        }
        else{ echo "0"; }
	}

	public function category_news_story() {
		$session_data = array(); $related_data = array(); $data = array();
		$today = date("D, d M Y");
		$session_data['cat_name'] 		= $this->session->userdata('cat_name');
    	$session_data['title'] 			= $this->session->userdata('title');
    	$session_data['description'] 	= $this->session->userdata('description');
    	$session_data['image'] 			= $this->session->userdata('image');
    	$session_data['pubDate'] 		= $this->session->userdata('pubDate');
		$data['category_news_details'] 	= $session_data;

    	$category_feed_data = $this->Enews_model->all_rss_feed_of_category($session_data['cat_name']);
    	if(isset($category_feed_data) && !empty($category_feed_data)){
	    	foreach($category_feed_data['item'] as $key => $value){
	    		$pub_date = explode(" ",$value['@attributes']['pubDate']);
	    		$pubDate = $pub_date[3]." ".$pub_date[4]." ".$pub_date[5]." ".$pub_date[6];
	    		if ($today == $pubDate) {
	    			$related_data[] = $value;
	    		}
	    	}
	    	if (count($related_data) > 1) {
				shuffle($related_data);
				$data['related_news'] = $related_data;
			}
			else{
				$related_data = array_slice($category_feed_data['item'], 0, 20, true);   // returns first 20 elements
				shuffle($related_data);
				$data['related_news'] = $related_data;
			}
	    }

		$data['website_language'] = $this->Enews_model->fetch_setting_data('website_language');
		$data['menu_data'] = $this->Enews_model->fetch_category_data_front();
		$data['news_info'] = 0;
		$data['recent_happenings'] = $this->Enews_model->get_recent_happenings_data();
		$data['popular'] = $this->Enews_model->get_popular_data();
		$data['title'] = $session_data['title'];
		//echo "<pre>";print_r($data['related_news']);die();
        $data['main_containt'] = 'category_news_story';
        $this->load->view('new_user/containt', $data);
	}
}