<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Enms extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		error_reporting(0);
		$this->load->model('enewsmedia_model', 'enmm');
    	$this->load->library('upload');
	}

	public function index()
	{
		$this->load->view('admin/index');
	}

	public function check_login()
    {
        $data = array();
        $data['email'] = $this->input->post('email');
        $data['password'] = $this->input->post('password');
        $output = $this->enmm->check_login($data);
        echo $output;
    }

    public function dashboard()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['category_count'] = $this->enmm->category_count();
			$data['sub_category_count'] = $this->enmm->sub_category_count();
			$data['sub_category_section_count'] = $this->enmm->sub_category_section_count();
			$data['comment_count'] = $this->enmm->comment_count_admin();
			$data['load_page']='admin/dashboard';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function check_admin_login()
	{
		$admin_login_id = $this->session->userdata('id');
		if(isset($admin_login_id) && !empty($admin_login_id))
		{ return $admin_login_id; }
		else
		{ $this->index(); }
	}

	public function add_category()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['category_last_id'] = $this->enmm->fetch_last_id('category');
			$data['load_page']='admin/add_category';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function add_sub_category()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['category'] = $this->enmm->fetch_category_data();
			$data['sub_category_last_id'] = $this->enmm->fetch_last_id('sub_category');
			$data['load_page']='admin/add_sub_category';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function add_sub_category_section()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['category'] = $this->enmm->fetch_category_data();
			$data['sub_category'] = $this->enmm->fetch_sub_category_data();
			$data['sub_category_section_last_id'] = $this->enmm->fetch_last_id('sub_category_section');
			$data['load_page']='admin/add_sub_category_section';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function add_news()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['category'] = $this->enmm->fetch_category_data();
			$data['sub_category'] = $this->enmm->fetch_sub_category_data();
			$data['news_section_last_id'] = $this->enmm->fetch_last_id('news');
			$data['load_page']='admin/add_news';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function display_sub_category()
	{
		$data = array();
		$id = $this->input->post('id');
		$data = $this->enmm->fetch_all_sub_category_data($id);
		//echo "<pre>"; print_r($data); echo "</pre>"; die();
		echo json_encode($data);
	}

	public function add_about_us()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/add_about_us';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function add_privacy_policy()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/add_privacy_policy';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function add_terms_conditions()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/add_terms_conditions';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function insert_about_us()
    {
    	$data = array();
        $data['title'] = $this->input->post('title');
        $data['hindi_title'] = $this->input->post('hindi_title');
        $data['details'] = $this->input->post('details');
        $data['hindi_details'] = $this->input->post('hindi_details');
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('about_us', $data);
        echo $result;
    }

    public function insert_privacy_policy()
    {
    	$data = array();
        $data['details'] = $this->input->post('details');
        $data['hindi_details'] = $this->input->post('hindi_details');
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('privacy_policy', $data);
        echo $result;
    }

    public function insert_terms_conditions()
    {
    	$data = array();
        $data['details'] = $this->input->post('details');
        $data['hindi_details'] = $this->input->post('hindi_details');
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('terms_and_conditions', $data);
        echo $result;
    }

	public function temp_session()
	{
		$page = $this->uri->segment(3);
		$data = array();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
	        $data['temp'] = $this->uri->segment(2);
	        $this->session->set_userdata($data);
		}
		else
		{
			//echo "N";
	        $data['temp'] = $this->uri->segment(2);
	        $this->session->set_userdata($data);
		}

		if($page == 'category')
		{
			?>
				<script type="text/javascript">
					var jump_edit_category_view_page = "<?php echo base_url('edit_category'); ?>";
				    window.location = jump_edit_category_view_page;
			    </script>
			<?php
		}
		if($page == 'category_view')
		{
			?>
				<script type="text/javascript">
					var jump_category_view_page = "<?php echo base_url('category_view'); ?>";
				    window.location = jump_category_view_page;
			    </script>
			<?php
		}
		if($page == 'sub_category')
		{
			?>
				<script type="text/javascript">
					var jump_edit_sub_category_view_page = "<?php echo base_url('edit_sub_category'); ?>";
				    window.location = jump_edit_sub_category_view_page;
			    </script>
			<?php
		}
		if($page == 'sub_category_view')
		{
			?>
				<script type="text/javascript">
					var jump_sub_category_view_page = "<?php echo base_url('sub_category_view'); ?>";
				    window.location = jump_sub_category_view_page;
			    </script>
			<?php
		}
		if($page == 'sub_category_section')
		{
			?>
				<script type="text/javascript">
					var jump_edit_sub_category_section_page = "<?php echo base_url('edit_sub_category_section'); ?>";
				    window.location = jump_edit_sub_category_section_page;
			    </script>
			<?php
		}
		if($page == 'sub_category_section_view')
		{
			?>
				<script type="text/javascript">
					var jump_sub_category_section_view_page = "<?php echo base_url('sub_category_section_view'); ?>";
				    window.location = jump_sub_category_section_view_page;
			    </script>
			<?php
		}
		if($page == 'edit_news')
		{
			?>
				<script type="text/javascript">
					var jump_edit_news_page = "<?php echo base_url('edit_news'); ?>";
				    window.location = jump_edit_news_page;
			    </script>
			<?php
		}
		if($page == 'news_view')
		{
			?>
				<script type="text/javascript">
					var jump_news_view_page = "<?php echo base_url('news_view'); ?>";
				    window.location = jump_news_view_page;
			    </script>
			<?php
		}
		if($page == 'about_us')
		{
			?>
				<script type="text/javascript">
					var jump_sub_category_view_page = "<?php echo base_url('edit_about_us'); ?>";
				    window.location = jump_sub_category_view_page;
			    </script>
			<?php
		}
		if($page == 'privacy_policy')
		{
			?>
				<script type="text/javascript">
					var jump_edit_privacy_policy_page = "<?php echo base_url('edit_privacy_policy'); ?>";
				    window.location = jump_edit_privacy_policy_page;
			    </script>
			<?php
		}
		if($page == 'terms_and_conditions')
		{
			?>
				<script type="text/javascript">
					var jump_edit_terms_conditions_page = "<?php echo base_url('edit_terms_conditions'); ?>";
				    window.location = jump_edit_terms_conditions_page;
			    </script>
			<?php
		}
	}

	public function edit_category()
	{
		$data = array();
		$data['category_data'] = $this->enmm->category_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_category';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function edit_about_us()
	{
		$data = array();
		$data['about_us_data'] = $this->enmm->about_us_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_about_us';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function edit_privacy_policy()
	{
		$data = array();
		$data['privacy_policy_data'] = $this->enmm->privacy_policy_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_privacy_policy';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function edit_terms_conditions()
	{
		$data = array();
		$data['terms_conditions_data'] = $this->enmm->terms_conditions_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_terms_conditions';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function category_view()
	{
		$data = array();
		$data['category_details'] = $this->enmm->category_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/category_view';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function edit_sub_category()
	{
		$data = array();
		$data['category_data'] = $this->enmm->fetch_category_data();
		$data['sub_category_data'] = $this->enmm->sub_category_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_sub_category';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function edit_sub_category_section()
	{
		$data = array();
		$data['category_data'] = $this->enmm->fetch_category_data();
		$data['sub_category_data'] = $this->enmm->fetch_sub_category_data();
		$data['sub_category_section_data'] = $this->enmm->sub_category_section_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_sub_category_section';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function edit_news()
	{
		$data = array();
		$data['category_data'] = $this->enmm->fetch_category_data();
		$data['sub_category_data'] = $this->enmm->fetch_sub_category_data();
		$data['news_section_data'] = $this->enmm->news_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/edit_news';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function sub_category_view()
	{
		$data = array();
		$data['sub_category_details'] = $this->enmm->get_sub_category_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/sub_category_view';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function sub_category_section_view()
	{
		$data = array();
		$data['sub_category_section_details'] = $this->enmm->get_sub_category_section_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/sub_category_section_view';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function news_view()
	{
		$data = array();
		$data['news_section_details'] = $this->enmm->get_news_details($this->session->userdata('temp'));
        $output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/news_view';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function insert_category()
    {
        /// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/category/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 		}
 		/// STORE IN DATBASE
        $data = array();
        $data['name'] = $this->input->post('name');
        $data['hindi_name'] = $this->input->post('hindi_name');
        $data['image'] = $this->input->post('image_name');
        $data['details'] = $this->input->post('details');
        $data['hindi_details'] = $this->input->post('hindi_details');
        $sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('category', $data);
        echo $result;
    }

    public function insert_sub_category()
    {
    	/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/sub_category/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 		}
 		/// STORE IN DATBASE
        $data = array();
        $data['category_id'] = $this->input->post('category');
        $data['name'] = $this->input->post('name');
        $data['hindi_name'] = $this->input->post('hindi_name');
        $data['image'] = $this->input->post('image_name');
        $data['details'] = $this->input->post('details');
        $data['hindi_details'] = $this->input->post('hindi_details');
        $sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('sub_category', $data);
        echo $result;
    }

    public function insert_sub_category_section()
    {
    	/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/sub_category_section/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 		}
 		/// STORE IN DATBASE
        $data = array();
        $data['category_id'] = $this->input->post('category');
        $data['sub_category_id'] = $this->input->post('sub_category');
        $data['name'] = $this->input->post('name');
        $data['hindi_name'] = $this->input->post('hindi_name');
        $data['image'] = $this->input->post('image_name');
        $data['details'] = $this->input->post('details');
        $data['hindi_details'] = $this->input->post('hindi_details');
        $sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('sub_category_section', $data);
        echo $result;
    }

    public function category_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/category_list';
			$data['category_data'] = $this->enmm->fetch_category_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function sub_category_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/sub_category_list';
			$data['category_data'] = $this->enmm->fetch_category_data();
			$data['sub_category_data'] = $this->enmm->fetch_sub_category_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function sub_category_section_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/sub_category_section_list';
			//$data['category_data'] = $this->enmm->fetch_category_data();
			//$data['sub_category_data'] = $this->enmm->fetch_sub_category_data();
			$data['sub_category_section_data'] = $this->enmm->fetch_sub_category_section_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function news_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/news_list';
			//$data['category_data'] = $this->enmm->fetch_category_data();
			//$data['sub_category_data'] = $this->enmm->fetch_sub_category_data();
			$data['news_section_data'] = $this->enmm->fetch_news_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function comment_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/comment_list';
			$data['comment_data'] = $this->enmm->fetch_comment_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function enquiry()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/enquiry';
			$data['enquiry_data'] = $this->enmm->fetch_enquiry_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function about_us_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/about_us_list';
			$data['about_us_data'] = $this->enmm->fetch_about_us_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function privacy_policy_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/privacy_policy_list';
			$data['privacy_policy_data'] = $this->enmm->fetch_privacy_policy_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function terms_conditions_list()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page'] = 'admin/terms_conditions_list';
			$data['terms_conditions_data'] = $this->enmm->fetch_terms_conditions_data();
	        $this->load->view('admin/load_page', $data);
	    }
	}	

	function profile()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['load_page']='admin/profile';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	function setting()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['website_language_data'] = $this->enmm->fetch_setting_data('website_language');
			$data['load_page']='admin/setting';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function password()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			$data['category_last_id'] = $this->enmm->fetch_last_id('category');
			$data['load_page']='admin/password';
	        $this->load->view('admin/load_page', $data);
	    }
	}

	public function check_old_password()
	{
		$data = array();
		$new_password = base64_decode($this->input->post('password'));
		$data['id'] = $this->input->post('id');
		$data['password'] = md5($new_password);
		$output = $this->enmm->check_old_password($data);
		echo $output; 
	}

	public function change_password()
	{
		$data = array();
		$table = $this->input->post('table');
		$id = $this->input->post('id');
		$new_password = base64_decode($this->input->post('password'));
		$data['password'] = md5($new_password);
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
    }

	function admin_logout()
    {
    	//echo "<pre>"; print_r($_SESSION); echo "</pre>"; die();
    	$admin_array_key_unset = array('id','name','email','status','temp','admin_logged_in');
        $this->session->set_userdata(array('admin_logged_in' => FALSE));
        $this->session->sess_destroy();
        $this->session->unset_userdata($admin_array_key_unset);
        unset($admin_array_key_unset);
        //$this->index();
        ?>
        <script type="text/javascript">
        	var jump_home_page = "<?php echo base_url('enms'); ?>";
            window.location = jump_home_page;
        </script>
        <?php
    }

    public function change_status()
	{
		$data = array();
		$table = $this->input->post('table');
		$id = $this->input->post('id');
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function edit_category_details()
	{
        $data = array();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
		}
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_name = $this->enmm->check_db_image($table, $id);	
 			if(isset($image_name) && !empty($image_name))
 			{
 				$delete_image = "./assets/category/".''.$image_name;
 				unlink($delete_image);
 			}
 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/category/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 			$data['image'] = $this->input->post('image_name');
 		}
		$data['name'] = $this->input->post('name');
		$data['hindi_name'] = $this->input->post('hindi_name');
		$data['details'] = $this->input->post('details');
		$data['hindi_details'] = $this->input->post('hindi_details');
		$sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function edit_about_us_details()
	{
		$data = array();
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		$data['title'] = $this->input->post('title');
		$data['hindi_title'] = $this->input->post('hindi_title');
		$data['details'] = $this->input->post('details');
		$data['hindi_details'] = $this->input->post('hindi_details');
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function edit_privacy_policy_details()
	{
		$data = array();
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		$data['details'] = $this->input->post('details');
		$data['hindi_details'] = $this->input->post('hindi_details');
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function edit_terms_conditions_details()
	{
		$data = array();
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		$data['details'] = $this->input->post('details');
		$data['hindi_details'] = $this->input->post('hindi_details');
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function edit_sub_category_details()
	{
		$data = array();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
		}
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_name = $this->enmm->check_db_image($table, $id);
 			if(isset($image_name) && !empty($image_name))
 			{
 				$delete_image = "./assets/sub_category/".''.$image_name;
 				unlink($delete_image);
 			}
 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/sub_category/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 			$data['image'] = $this->input->post('image_name');
 		}
		$data['category_id'] = $this->input->post('category');
		$data['name'] = $this->input->post('name');
		$data['hindi_name'] = $this->input->post('hindi_name');
		$data['details'] = $this->input->post('details');
		$data['hindi_details'] = $this->input->post('hindi_details');
		$sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function edit_sub_category_section_details()
	{
		$data = array();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
		}
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_name = $this->enmm->check_db_image($table, $id);
 			if(isset($image_name) && !empty($image_name))
 			{
 				$delete_image = "./assets/sub_category_section/".''.$image_name;
 				unlink($delete_image);
 			}
 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/sub_category_section/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 			$data['image'] = $this->input->post('image_name');
 		}
		$data['category_id'] = $this->input->post('category');
		$data['sub_category_id'] = $this->input->post('sub_category');
		$data['name'] = $this->input->post('name');
		$data['hindi_name'] = $this->input->post('hindi_name');
		$data['details'] = $this->input->post('details');
		$data['hindi_details'] = $this->input->post('hindi_details');
		$sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}

	public function set_setting()
	{
        $data = array();
		$counter = '';
		$name = $this->input->post('name');
		$status = $this->input->post('status');

        if($name == 'website_language')
        {
        	$counter = $this->enmm->setting_count($name);
        	$table = 'setting';
	        
	        if($counter == '0')
	        {
	        	//echo "INSERT";
		        $data['name'] = $name;
		        $data['status'] = $status;
		        $result = $this->enmm->insert_table_data('setting', $data);
	        }
	        else
	        {
	        	//echo "UPDATE";
		        $data['status'] = $status;
		        $result = $this->enmm->change_status($table, $data, 'name LIKE "'. $name .'"');
	        }        
        }
        echo $result;
	}

    public function test()
	{
		$output = $this->check_admin_login();
		if(isset($output) && !empty($output))
		{
			//$data['load_page'] = 'admin/test';
			$data['load_page'] = 'admin/ALL-FORM';
			$this->load->view('admin/load_page', $data);
	    }
	}

	//News 
	public function insert_news_data()
    {
    	/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
    		$image_file_name = $this->input->post('image_name');
    		$remove_ext = explode('.', $image_file_name);
    		$id = $remove_ext[0];
 			$upload_directory = "./assets/news/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 			$thumb_img = '';
 			if($this->input->post('media_type') == 'video'){
	 			exec("/usr/local/bin/ffmpeg -i ".$upload_directory." -ss 00:00:05 -vframes 1 -vf fps=1/60 ./assets/news/thumb_".$id.".jpg 2>&1", $o, $v);
	 			if($v == 0){
	 				$thumb_img = "thumb_".$id.".jpg";
	 			}
	 		}
 		}
 		/// STORE IN DATBASE
        $data = array();
        $data['cat_id'] = $this->input->post('category');
        $data['sub_cat_id'] = $this->input->post('sub_category');
        $data['image'] = $this->input->post('image_name');
        $data['news_title'] = $this->input->post('name');
        $data['news_priority'] = $this->input->post('news_priority'); 
		$data['media_type'] = $this->input->post('media_type');
		$data['is_breaking_news'] = $this->input->post('breaking_news');
		$data['video_thumb_img'] = $thumb_img;
        $data['news_hindi_title'] = $this->input->post('hindi_name');
        $data['news_desc'] = $this->input->post('details');
        $data['news_hindi_desc'] = $this->input->post('hindi_details');
        $sequence = $this->input->post('sequence');
        $data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
        $data['status'] = '1';

        //echo "here"; print_r($data); exit();
        $result = $this->enmm->insert_table_data('news', $data);
        echo $result;
    }

    public function edit_news_details()
	{
		$data = array();
		//print_r($_POST); 
		//print_r($_FILES); //exit();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
		}
		$id = $this->input->post('id');
		$table = $this->input->post('table');
		/// STORE IN FOLDER
    	if(!empty($_FILES['image']))
 		{
 			$image_name = $this->enmm->check_db_image($table, $id);
 			if(isset($image_name) && !empty($image_name))
 			{
 				$delete_image = ASSET_URL."/assets/news/".''.$image_name;
 				unlink($delete_image);
 			}

 			$image_file_name = $this->input->post('image_name');
 			$upload_directory = "./assets/news/".''.$image_file_name;
 			move_uploaded_file($_FILES['image']['tmp_name'], $upload_directory);
 			$thumb_img = '';
 			if($this->input->post('media_type') == 'video'){
	 			exec("/usr/local/bin/ffmpeg -i ".$upload_directory." -ss 00:00:05 -vframes 1 -vf fps=1/60 ./assets/news/thumb_".$id.".jpg 2>&1", $o, $v);
	 			
	 			if($v == 0){
	 				$thumb_img = "thumb_".$id.".jpg";
	  			}
	 		}
 			$data['image'] = $this->input->post('image_name');
 		}
 		$data['cat_id'] = $this->input->post('category');
		$data['sub_cat_id'] = $this->input->post('sub_category');
		$data['news_title'] = $this->input->post('name');		
		$data['news_hindi_title'] = $this->input->post('hindi_name');
		$data['media_type'] = $this->input->post('media_type');
		$data['is_breaking_news'] = $this->input->post('breaking_news');
		$data['video_thumb_img'] = $thumb_img;
		$data['news_priority'] = $this->input->post('news_priority');
		$data['news_desc'] = $this->input->post('details');
		$data['news_hindi_desc'] = $this->input->post('hindi_details');
		$sequence = $this->input->post('sequence');

		//print_r($data); exit();
        //$data['sequence'] = isset($sequence) && !empty($sequence) ? $sequence : '0';
		$data['status'] = $this->input->post('status');
        $output = $this->enmm->change_status($table, $data, 'id = '.$id);
        echo $output;
	}
}