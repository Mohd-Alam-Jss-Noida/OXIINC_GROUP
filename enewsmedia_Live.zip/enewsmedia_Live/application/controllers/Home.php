<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('enewsmedia_model', 'enmm');
	}

	public function index()
	{
		$data = array();
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['recent_happenings'] = $this->enmm->get_recent_happenings_data();	
		$data['popular'] = $this->enmm->get_popular_data();	
		$data['all_categories_data'] = $this->enmm->fetch_all_category_data_front();
		$data['all_data'] = $this->enmm->fetch_all_data_front();
		$data['all_feed_categories'] = $this->enmm->all_feed_categories();
		//if(isset($_GET['data']) && $_GET['data'] == 1)
		$data['feed_data'] = $this->enmm->rss_feed();
		$data['corona_count'] = $this->enmm->corona_updates();
		$data['load_page']='index';
		$this->load->view('load_page', $data);
	}

	public function post()
	{
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['load_page']='post';
        $this->load->view('load_page', $data);
	}

	public function view_list()
	{
		//echo $id = $this->uri->segment(2);
		//echo $page = $this->uri->segment(3);
		$data = array();
		$temp_session = $this->session->userdata('sub_cat_id');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('sub_cat_id');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
	        $data['sub_cat_id'] = $this->uri->segment(2);
	        $data['table'] = $this->uri->segment(3);
	        $data['sub_id_flag'] = $this->uri->segment(4);
	        $this->session->set_userdata($data);
		}
		else
		{
			//echo "N";
	        $data['sub_cat_id'] = $this->uri->segment(2);
	        $data['table'] = $this->uri->segment(3);
	        $data['sub_id_flag'] = $this->uri->segment(4);
	        $this->session->set_userdata($data);
		}
		?>
			<script type="text/javascript">
				var jump_view_page = "<?php echo base_url('news_list_front'); ?>";
			    window.location = jump_view_page;
		    </script>
		<?php
	}


	public function temp_front_session()
	{
		//echo $id = $this->uri->segment(2);
		//echo $page = $this->uri->segment(3);
		$data = array();
		$temp_session = $this->session->userdata('temp');
		if(isset($temp_session) && !empty($temp_session))
		{
			//echo "Y";
			$temporary_array_key_unset = array('temp');
	        $this->session->unset_userdata($temporary_array_key_unset);
	        unset($temporary_array_key_unset);
	        $data['temp'] = $this->uri->segment(2);
	        $data['table'] = $this->uri->segment(3);
	        $this->session->set_userdata($data);
		}
		else
		{
			//echo "N";
	        $data['temp'] = $this->uri->segment(2);
	        $data['table'] = $this->uri->segment(3);
	        $this->session->set_userdata($data);
		}
		?>
			<script type="text/javascript">
				var jump_view_page = "<?php echo base_url('view'); ?>";
			    window.location = jump_view_page;
		    </script>
		<?php
	}

	public function news_list_front()
	{
		//echo "inside here"; exit();
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$id = $this->session->userdata('sub_cat_id');
		$table = $this->session->userdata('table');
		$sub_id_flag = $this->session->userdata('sub_id_flag');		
		$data['news_listing'] = $this->enmm->fetch_news_listing($id, $sub_id_flag);

		//1 = subcategory present,0=sub category not present
		if($sub_id_flag == 1){
			$data['category_data'] = $this->enmm->get_sub_category_details($id);
		}else{
			$data['category_data'] = $this->enmm->category_details($id);		
		}		
		$data['sub_id_flag'] = $sub_id_flag;
//print_r($data['menu_data']); exit();
	    $data['load_page']='news_list';
        $this->load->view('load_page', $data);
	}

	public function view()
	{
		//echo "inside here"; exit();
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$id = $this->session->userdata('temp');
		$table = $this->session->userdata('table');
		$sub_id_flag = $this->session->userdata('sub_id_flag');
		$data['comment_count'] = ($table == 'category') ? $this->enmm->comment_count('category_id', $id) : $this->enmm->comment_count('sub_category_id', $id);
		$data['news_info'] = 0;
		if($table == 'category')
		{
			$data['category_data'] = $this->enmm->category_details($id);		
		}
		else if($table == 'sub_category')
		{
			$data['sub_category_data'] = $this->enmm->get_sub_category_details($id);
			$data['related_news'] = $this->enmm->get_all_category_details($data['sub_category_data']['category_id']);
		}
		else if($table == 'news')
		{
			$data['sub_category_data'] = $this->enmm->get_news_details($id);
			//$data['related_news'] = $this->enmm->get_all_category_details($data['sub_category_data']['category_id']);

			$data['related_news'] = $this->enmm->get_all_related_news($data['sub_category_data']['category_id']);
			$data['news_info'] = 1;
			$data['sub_id_flag'] = $sub_id_flag;

			//print_r($data['related_news']); exit();
		}
		$data['recent_happenings'] = $this->enmm->get_recent_happenings_data();
		$data['load_page']='view';
        $this->load->view('load_page', $data);
	}

	public function search()
	{
		//echo "inside here"; exit();
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$search_keyword = $this->input->get('s');		
		$sub_id_flag = $this->session->userdata('sub_id_flag');		
		$data['search_listing'] = $this->enmm->search_news_data($search_keyword, $data['website_language']);

		
//print_r($data['search_listing']); exit();
	    $data['load_page']='search';
        $this->load->view('load_page', $data);
	}

	function view_counter()
	{
		$data = array();
		$category_id = $sub_category_id = $counter = $db_counter = '';
		$category_id = $this->input->post('category_id');
		$sub_category_id = $this->input->post('sub_category_id');
		$news_id = $this->input->post('news_id');

		$category_id = isset($category_id) && !empty($category_id) ? $category_id : '';
		$sub_category_id = isset($sub_category_id) && !empty($sub_category_id) ? $sub_category_id : '';
		$news_id = isset($news_id) && !empty($news_id) ? $news_id : '';

		/*if($category_id!='')
		{
			$table = 'category';
			$counter = $this->enmm->check_db_counter($table, $category_id);
			$db_counter = $counter + 1;
			$data['counter'] = $db_counter;
	        $output = $this->enmm->change_status($table, $data, 'id = '.$category_id);
	        echo $output;
		}
		if($sub_category_id!='')
		{
			$table = 'sub_category';
			$counter = $this->enmm->check_db_counter($table, $sub_category_id);
			$db_counter = $counter + 1;
			$data['counter'] = $db_counter;
	        $output = $this->enmm->change_status($table, $data, 'id = '.$sub_category_id);
	        echo $output;
		}*/
		if($news_id!='')
		{
			$table = 'news';
			$counter = $this->enmm->check_db_counter($table, $news_id);
			$db_counter = $counter + 1;
			$data['counter'] = $db_counter;
	        $output = $this->enmm->change_status($table, $data, 'id = '.$news_id);
	        echo $output;
		}
	}

	function add_comment()
	{
		$data = array();
        $data['category_id'] = $this->input->post('category_id');
        $sub_category_id = $this->input->post('sub_category_id');
        $data['sub_category_id'] = isset($sub_category_id) && !empty($sub_category_id) ? $sub_category_id : '0';
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['comment'] = $this->input->post('comment');
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('comment', $data);
        echo $result;
	}

	function about()
	{
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['about_us'] = $this->enmm->fetch_about_us_data_front();
		$data['load_page']='about';
    	$this->load->view('load_page', $data);
    }

    function contact()
	{
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['recent_data'] = $this->enmm->get_recent_happenings_data();
		$data['popular_data'] = $this->enmm->get_popular_data();
		$data['comment_data'] = $this->enmm->fetch_comment_data_front();
		$data['load_page']='contact';
    	$this->load->view('load_page', $data);
    }

    function privacy_policy()
	{
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['privacy_policy'] = $this->enmm->fetch_privacy_policy_data_front();
		$data['load_page']='privacy_policy';
    	$this->load->view('load_page', $data);
    }

    function terms_conditions()
	{
		$data['website_language'] = $this->enmm->fetch_setting_data('website_language');
		$data['menu_data'] = $this->enmm->fetch_category_data_front();
		$data['terms_conditions'] = $this->enmm->fetch_terms_conditions_data_front();
		$data['load_page']='terms_conditions';
    	$this->load->view('load_page', $data);
    }


    function insert_enquiry()
    {
    	$data = $result = array();
        $data['name'] = $this->input->post('name');
        $data['email'] = $this->input->post('email');
        $data['subject'] = $this->input->post('subject');
        $data['message'] = $this->input->post('message');
        $data['status'] = '1';
        $result = $this->enmm->insert_table_data('enquiry', $data);
        if($_SERVER['HTTP_HOST'] != 'localhost')
        {
        	$this->send_enquiry_email($this->input->post('name'), $this->input->post('email'), $this->input->post('subject'), $this->input->post('message'));
        }
        echo $result;
    }

    public function send_enquiry_email($name, $email, $enquiry_subject, $enquiry_message)
	{
		//$enquiry_mail = 'krunal.tailor@oxiinc.in';
		$enquiry_mail = $email;
		//$logo = "./assets/images/logos/logo.png";
		//$logo = base_url('assets/images/logos/logo.png');
		$logo = base_url('assets/images/favicon.png');
		$subject = 'Enquiry On Enewsmedia';
		$emailer = 'email_template/enquiry_mail.html';
		$mail_content = file_get_contents($emailer);
		$logo_url=$logo;
		$fb_url="<i class='fa fa-facebook'></i>";
		$tw_url="<i class='fa fa-twitter'></i>";
		$yt_url="<i class='fa fa-youtube-play'></i>";
		$link_url="<i class='fa fa-linkedin'></i>";
		$mail_content = str_replace('@__logo__@', $logo_url, $mail_content);
		$mail_content = str_replace('@__name__@', $name, $mail_content);
		$mail_content = str_replace('@__email__@', $email, $mail_content);
		$mail_content = str_replace('@__subject__@', $enquiry_subject, $mail_content);
		$mail_content = str_replace('@__message__@', $enquiry_message, $mail_content);
		$mail_content = str_replace('@__fb__@', $fb_url, $mail_content);
		$mail_content = str_replace('@__tw__@', $tw_url, $mail_content);
		$mail_content = str_replace('@__youtube__@', $yt_url, $mail_content);
		$mail_content = str_replace('@__linkedin__@', $link_url, $mail_content);
		$to = array($enquiry_mail);
	    $message = $mail_content;
	    $this->load->config('enewsmedia_email');
        $email_config = $this->config->config['enewsmedia_enquiry'];
        $this->email->initialize($email_config);
        $this->email->clear(); //IMP
        $this->email->from($email_config['smtp_user']);
        if ($_SERVER['HTTP_HOST'] == 'localhost')
        {
            $mailTo = array('amol.patil@oxiincgroup.com'); //send mail to project creators id
        }
        $this->email->to($to);
        //$this->email->cc($cc);
        //$this->email->bcc($bcc);
        if (!empty($this->mailbcc))
        {
            $this->email->bcc($this->mailbcc);
        }
        $this->email->subject($subject);
        $this->email->message($message);
        if ($this->email->send())
        {
        	// echo "<pre>"; print_r($this->email); echo "</pre>";
            return true;
        }
        else
        {
        	// echo "<pre>"; print_r($this->email); echo "</pre>";
            // show_error($this->email->print_debugger());
            return false;
        }
	}

	function logout()
    {
    	$client_array_key_unset = array('temp', 'table');
        $this->session->set_userdata(array('client_logged_in' => FALSE));
        $this->session->sess_destroy();
        $this->session->unset_userdata($client_array_key_unset);
        unset($client_array_key_unset);
        //$this->index();
        ?>
        <script type="text/javascript">
        	var jump_home_page = "<?php echo base_url(); ?>";
            window.location = jump_home_page;
        </script>
        <?php
    }
}