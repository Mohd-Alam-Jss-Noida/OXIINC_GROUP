
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <div class="my-channel-section-01">
			  <div class="block-01 fwd">
			    <div class="left-col">
			      <img src="https://entube.in/alpha/uploads/Customer_pan/850013675entube_gagan.png" class="img-col" alt=""/>
				  <h3>Mohd Alam Oxiinc Group</h3>
			    </div>
			    <div class="right-col">
				  <a href="#" class="cust-channel-btn">Youtube Studio</a>
			      <a href="#" class="cust-channel-btn">Customize Channel</a>
			    </div>
			  </div>
			  
			  <div class="block-02 fwd">
			    <div class="scroller scroller-left"><i class="glyphicon glyphicon-chevron-left"></i></div>
				<div class="scroller scroller-right"><i class="glyphicon glyphicon-chevron-right"></i></div>
				<!-- Nav tabs -->
				<div class="tab-wrapper">
				<ul class="nav nav-tabs list" role="tablist">
				    <li class="active"><a href="home-tab.php">Home</a></li>
					<li><a href="videos-tab.php">Videos</a></li>
					<li><a href="playlist-tab.php">Playlist</a></li>
					<li><a href="channels-tab.php">Channels</a></li>
					<li><a href="discussion-tab.php">Discussion</a></li>
					<li><a href="about-tab.php">About</a></li>
				</ul>
				</div>
				
			   
	  
	
	  