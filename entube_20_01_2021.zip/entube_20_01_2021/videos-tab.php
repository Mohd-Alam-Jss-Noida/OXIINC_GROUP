<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('my-channel.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start Videos Tab -->
				  <div role="tabpanel" class="">
				    <div class="tab-container fwd">
					    <div class="tab-title">Uploads</div>
						<div class="dropdown video-login-popup video-login-popup2">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
						  <ul class="dropdown-menu">
							<li><a href="#">Most popular</a></li>
							<li><a href="#">Date added (oldest)</a></li>
							<li><a href="#">Date added (newest)</a></li>
						  </ul>
						</div>
					  <ul class="list-inline video-list">
					    <li>
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</li>
						<li>
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</li>
					  </ul>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>