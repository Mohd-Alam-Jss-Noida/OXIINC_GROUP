<!-- Css -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
<!-- Fontawesome -->
<link href="css/fontawesome/all.css" rel="stylesheet">
<link href="css/fontawesome/fontawesome.css" rel="stylesheet">
<link href="css/fontawesome/brands.css" rel="stylesheet">
<link href="css/fontawesome/solid.css" rel="stylesheet">
<link href="css/animate.css" rel="stylesheet">
<!-- Scrollbar Css -->
<link href="css/mCustomScrollbar.css" rel="stylesheet" type="text/css" />

<!-- Datepicker Css -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
<!-- Data Table Css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.css"/>

<link href="css/common-style.css" rel="stylesheet">
<link href="css/home.css" rel="stylesheet">
<link href="css/custom-inner-style.css" rel="stylesheet">
<link href="css/custom-inner-responsive.css" rel="stylesheet">


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->