$(document).ready(function($){
//---- File Upload Button
	const realFileBtn = document.getElementById("real-file");
	const customBtn = document.getElementById("upload-video-btn");
	const customTxt = document.getElementById("upload-video-text");

	customBtn.addEventListener("click", function() {
	  realFileBtn.click();
	});

	realFileBtn.addEventListener("change", function() {
	  if (realFileBtn.value) {
		customTxt.innerHTML = realFileBtn.value.match(
		  /[\/\\]([\w\d\s\.\-\(\)]+)$/
		)[1];
	  } else {
		customTxt.innerHTML = "No file chosen, yet.";
	  }
	});	
});


$(document).ready(function($){
//---- Video File Upload Button
    const realFileBtn = document.getElementById("photo");
    const customBtn = document.getElementById("channel-icon-btn");
    const customTxt = document.getElementById("channel-icon-text");

    customBtn.addEventListener("click", function() {
        realFileBtn.click();
    });

    realFileBtn.addEventListener("change", function() {
        if (realFileBtn.value) {
            customTxt.innerHTML = realFileBtn.value.match(
                /[\/\\]([\w\d\s\.\-\(\)]+)$/
                )[1];
        } else {
            customTxt.innerHTML = "No file chosen, yet.";
        }
    });
});	
	

$(document).ready(function($){
//---- Image File Upload Button
    const realFileBtn = document.getElementById("channel_banner");
    const customBtn = document.getElementById("channel-banner-btn");
    const customTxt = document.getElementById("channel-banner-text");

    customBtn.addEventListener("click", function() {
      realFileBtn.click();
    });

    realFileBtn.addEventListener("change", function() {
      if (realFileBtn.value) {
        customTxt.innerHTML = realFileBtn.value.match(
          /[\/\\]([\w\d\s\.\-\(\)]+)$/
        )[1];
      } else {
        customTxt.innerHTML = "No file chosen, yet.";
      }
    });
});	


