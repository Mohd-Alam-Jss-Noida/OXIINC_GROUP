$(document).ready(function($){
	
	
//-- Main Wrapper Height	
	var contentheight = $(window).height() - $("header").height() - $("footer").height() + "px";
	$(".main-wrapper").css("min-height", contentheight);
	
	
//-- Toggle the side navigation
	$('.menu-icon').on('click', function(){
		$(this).toggleClass('active-leftnav');
        $('.slide-nav').toggleClass('left-slide');
    });
	
	
//-- Add Remove class side navigation	
	/*$('.slide-nav').hover(
		function(){ 
		  $(this).addClass('left-slide'),
		  $('.menu-icon').addClass('active-leftnav') 
		},
		function(){ 
		  $(this).removeClass('left-slide'),
		  $('.menu-icon').removeClass('active-leftnav') 
		}
	)*/
	

//-- Go to Top Scroll
	var offset = 500,
		offset_opacity = 1200,
		scroll_top_duration = 700,
		$back_to_top = $('.cd-top');

	$(window).scroll(function(){
		( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
		if( $(this).scrollTop() > offset_opacity ) { 
			$back_to_top.addClass('cd-fade-out');
		}
	});

	$back_to_top.on('click', function(event){
		event.preventDefault();
		$('body,html').animate({
			scrollTop: 0 ,
			}, scroll_top_duration
		);
	});
	
	
//-- Scrollbar Script
		$(".scrollbox").mCustomScrollbar({
			theme:"rounded-dots",
			scrollInertia:400
		});


//-- Equal Height Col	
    function displayWindowSize(){
		equalheight = function(container){
		
			var currentTallest = 0,
			currentRowStart = 0,
			rowDivs = new Array(),
			$el,
			topPosition = 0;
			$(container).each(function() {
				
				$el = $(this);
				$($el).height('auto')
				topPostion = $el.position().top;
				
				if (currentRowStart != topPostion) {
					for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
						rowDivs[currentDiv].height(currentTallest);
					}
					rowDivs.length = 0; // empty the array
					currentRowStart = topPostion;
					currentTallest = $el.height();
					rowDivs.push($el);
					} else {
					rowDivs.push($el);
					currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
				}
				for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
					rowDivs[currentDiv].height(currentTallest);
				}
			});
		}
		
		$(window).load(function() {
			equalheight('.equal-height-col');
		});
		
		$(window).resize(function(){
			equalheight('.equal-height-col');
		});		
    }
    window.addEventListener("resize", displayWindowSize);
    displayWindowSize();


	
});




