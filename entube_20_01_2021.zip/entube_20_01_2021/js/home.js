$(document).ready(function($){

//-- Home Recommendation Slider
	var owl = $('.home-recommendetions-section .owl-carousel');
	  owl.owlCarousel({
		margin: 15,
		nav: true,
		loop: true,
		autoplay:false,
		autoplayTimeout:3000,
		autoplayHoverPause:true,
		responsive: {
		  0: {
			margin: 10,
			items: 2
		  },
		  480: {
			items: 3
		  },
		  600: {
			items: 4
		  },
		  980: {
			items: 5
		  },
		  1280: {
			items: 6
		  },
		  1600: {
			items: 7
		  }
		}
	  })

	  
//-- Home Recently Uploaded Slider
	var owl = $('.home-section-01 .owl-carousel');
	  owl.owlCarousel({
		margin: 25,
		nav: true,
		loop: true,
		autoplay:true,
		autoplayTimeout:3000,
		autoplayHoverPause:true,
		responsive: {
		  0: {
			margin: 15,
			items: 2
		  },
		  640: {
			items: 3
		  },
		  1280: {
			items: 4
		  },
		  1600: {
			items: 5
		  }
		}
	  })

});




