<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<!-- Css -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
	<!-- Fontawesome -->
	<link href="css/fontawesome/all.css" rel="stylesheet">
	<link href="css/fontawesome/fontawesome.css" rel="stylesheet">
	<link href="css/fontawesome/brands.css" rel="stylesheet">
	<link href="css/fontawesome/solid.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<!-- Owlcarousel -->
	<link rel="stylesheet" href="css/owlcarousel/owl.carousel.min.css">
	<!-- Scrollbar Css -->
	<link href="css/mCustomScrollbar.css" rel="stylesheet" type="text/css" />

	<link href="css/common-style.css" rel="stylesheet">
	<link href="css/home.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">

		<!-- Category / Advertisement Section -->
		<section class="home-section-01 home-video-slider">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <h2 class="headding-01">Category / Advertisement</h2>
			  <div class="video-list-inline">
			  
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
					  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-02.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Message from CMD</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 5100 views</span>
					    <span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
				  	  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-03.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc Group Information</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-02.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Message from CMD</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 5100 views</span>
					    <span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
				  	  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-03.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc Group Information</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item equal-height-col">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
			 
			 </div>
			  <hr>
			</div>
		  </div>
		</section>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <!-- jQuery -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
	    <!-- Fontawesome -->
	    <script defer src="js/fontawesome/all.js"></script>
	    <script defer src="js/fontawesome/brands.js"></script>
	    <script defer src="js/fontawesome/solid.js"></script>
	    <script defer src="js/fontawesome/fontawesome.js"></script>
	    <!-- owlcarousel -->
	    <script src="js/owlcarousel/owl.carousel.js"></script>
		<!-- Scrollbar Script -->
		<script src="js/mCustomScrollbar.concat.min.js"></script>
	  
	    <script src="js/common-script.js"></script>
	    <script src="js/home.js"></script>
		
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.home-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>