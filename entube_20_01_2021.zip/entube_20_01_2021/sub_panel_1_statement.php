<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body class="open_panel_menu">
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <header>
		<div class="row">
			<div class="container-fluid">
				<nav class="navbar navbar-default">
					<div class="container-fluid">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
								<span class="sr-only">Toggle navigation</span>

								<i class="fa fa-ellipsis-v fa-w-6"></i>
							</button>
							<div class="menu-icon">
								<img src="https://www.entube.in/new_user_assets/images/menu-icon.png" alt=""/>
								<img src="https://www.entube.in/new_user_assets/images/close-icon.png" alt=""/>
							</div>
							<a href="https://www.entube.in/"><img src="https://www.entube.in/new_user_assets/images/entube-logo.png" class="logo-col" alt="Entube"/></a>
						</div>
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
																<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="https://www.oxiinc.com/assets/uploads/profile_images/download16.jpg" alt="" style="width: 50px; height: 50px; border-radius: 50%;" /></a>
									<ul class="dropdown-menu">
										<li><a href="https://www.entube.in/E_Panelist_page/E_panelist_my_profile" ><i class="fas fa-fw fa-user-circle"></i>My Profile</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="https://www.entube.in/E_Panelist_page_new/my_digital" ><i class="fas fa-fw fa-video"></i>My VWS</a></li>
										<li><a href="https://www.entube.in/E_Panelist_page_new/my_digital_statement" ><i class="fas fa-fw fa-video"></i>My VWS Statement</a></li>
										<!-- 											<li><a href="" ><i class="fas fa-fw fa-video"></i>My VWS</a></li>
										 -->
										<li role="separator" class="divider"></li>
										<li><a href="https://www.entube.in/Upload_video/List_Of_Upload" ><i class="fas fa-fw fa-video"></i>Creator Studio</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="https://www.entube.in/Entube/logout" ><i class="fas fa-fw fa-video"></i>Logout</a></li>
									</ul>
								</li>
									
								
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="https://www.entube.in/new_user_assets/images/bell-icon.png" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
										<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-fw fa-star "></i> Something else here</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="https://www.entube.in/new_user_assets/images/message-icon.png" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
										<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-fw fa-star "></i> Something else here</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="https://www.entube.in/new_user_assets/images/grid-icon.png" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fab fa-youtube-square"></i> Enews Media TV</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube Serial Trailer</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-video"></i> EnTube For Movie</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube For Artist</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fas fa-compact-disc"></i> EnTube Music</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube Academy</a></li>
										<li><a href="#"><i class="fab fa-youtube"></i> EnTube Gaming</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="https://www.entube.in/new_user_assets/images/video-upload-icon.png" alt=""/></a>
									<ul class="dropdown-menu">
										<li><a href="#"><i class="fas fa-upload"></i> Upload Your Video</a></li>
										<li role="separator" class="divider"></li>
										<li><a href="#"><i class="fab fa-youtube"></i> Go Live Now</a></li>
									</ul>
								</li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="https://www.entube.in/new_user_assets/images/search-icon.png" alt=""/></a>
									<ul class="dropdown-menu">
										<li>
											<form class="search-section" action="https://www.entube.in/Entube/search" method="post" onsubmit="return validateSearchForm()">
												<input type="text" class="search-textbox" name="search" id="search" placeholder="Search for...">
												<button type="submit" class="search-btn">Submit</button>
											</form>
										</li>
									</ul>
								</li>
							</ul>
						</div>
					</div>
				</nav>
				<div class="slide-nav">
					<ul class="list-unstyled scrollbox">
							

							<li class="list-title">DIGITAL MARKETING PROGRAM</li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/panel_statement"><span>Panel</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_1_statement"><span>Sub Panel 1 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_2_statement"><span>Sub Panel 2 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_3_statement"><span>Sub Panel 3 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_4_statement"><span>Sub Panel 4 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_5_statement"><span>Sub Panel 5 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_6_statement"><span>Sub Panel 6 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_7_statement"><span>Sub Panel 7 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_8_statement"><span>Sub Panel 8 Statement</span></a></li>
							<li><a href="https://www.entube.in/E_Panelist_page_new/sub_panel_9_statement"><span>Sub Panel 9 Statement</span></a></li>
							<li class="logout-txt"><a href="https://www.entube.in/Entube/logout">LOGOUT</a></li>

											</ul>
				</div>
			</div>
		</div>
	</header>
	  <!-- End Header -->
	  
	
	<!-- Start Container -->
	<div class="main-wrapper">
		<section class="video-detail-page myvws-section-01 myvws-statement-section-01">
			<div id="wrapper">
				<div id="content-wrapper">
					<div class="container-fluid pb-0">
						<div class="video-block section-padding">
							<div class="row">
								<div class="col-md-12">
									<div class="main-title">
										<h2 class="headding-01">Entube Report</h2>
										<!--<img src="https://www.entube.in/new_user_assets/images/my_digital.jpg" width="100%">-->
									</div>
								</div>
							</div>
							
							<marquee onmouseover="this.stop();" onmouseout="this.start();">
							Note:- Statement Generates only after completing the task on oxiinc.in / entube.in / ouropinion.in so first complete the task. (Oxiinc Digital account upgradation ke bad oxiinc.in / entube.in / ouropinion.in par task complete karne ke bad hi statement generate hoga esliye pehle task complete karen.)
						   </marquee>
							
							<div class="default-block block-01">
							  <div class="form-group half-width">
							    <label>From Date:</label>
								<div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
									<input class="date-textbox" type="text" placeholder="mm/dd/yyyy" readonly />
									<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
								</div>
							  </div>
							  <div class="form-group half-width">
							    <label>To Date:</label>
								<div id="datepicker2" class="input-group date" data-date-format="mm-dd-yyyy">
									<input class="date-textbox" type="text" placeholder="mm/dd/yyyy" readonly />
									<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
								</div>
							  </div>
							  <div class="form-group">
							    <button type="submit" class="date-submit-btn">Serach Details</button>
							  </div>
							  <div class="form-group full-width">
							    <button type="button" class="date-submit-btn">Yesterday</button>
								<button type="button" class="date-submit-btn">Today</button>
								<button type="button" class="date-submit-btn">Month Till Date</button>
							  </div>
							</div>
							
							<div class="default-block block-02">
							  <h4>Digital Report</h4>
							  <a href="#" class="report-btn">Copy</a>
							  <a href="#" class="report-btn">Excel</a>
							  <a href="#" class="report-btn">CSV</a>
							  <a href="#" class="report-btn">PDF</a>
							  <a href="#" class="report-btn">Print</a>
							  
							  <div class="data-table-col">
							  <table class="table table-bordered table-hover dt-responsive">
								<thead>
								  <tr>
									<th>Sr No.</th>
									<th>Sharing Date</th>
									<th>Video</th>
									<th>Total (RP)</th>
									<th>Service Charge (%)</th>
									<th>Net Amount Credited (RP)</th>
									<th>Shopping Wallet Amount Credited (RP) (20%)</th>
									<th>Digital Wallet Amount Credited (RP) (80%)</th>
									<th>Success / Unsuccess</th>
									<th>Payment Status</th>
									<th>Payment To Be Credited On</th>
									<th>Natural Disaster Wallet</th>
									<th>Payment Date</th>
								  </tr>
								</thead>
								<tbody>
								  <tr>
									<td>1</td>
									<td>29 May, 2020</td>
									<td>https://entube.in/alpha/uploads/video/922620921entube.mp4</td>
									<td>100</td>
									<td>5</td>
									<td>95</td>
									<td>19</td>
									<td>76</td>
									<td>Success</td>
									<td>Amount Occurred</td>
									<td>28 June, 2020</td>
									<td>-</td>
									<td>Pending</td>
								  </tr>
								  
								  <tr>
									<td>2</td>
									<td>29 May, 2020</td>
									<td>https://entube.in/alpha/uploads/video/922620921entube.mp4</td>
									<td>100</td>
									<td>5</td>
									<td>95</td>
									<td>19</td>
									<td>76</td>
									<td>Success</td>
									<td>Amount Occurred</td>
									<td>28 June, 2020</td>
									<td>-</td>
									<td>Pending</td>
								  </tr>
								</tbody>
							  </table>
							  </div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
	<!-- end Container -->
	
	

	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>

		
		<script>
			$(function () {
			  $("#datepicker").datepicker({ 
					autoclose: true, 
					todayHighlight: true
			  }).datepicker('update', new Date());
			  
			  $("#datepicker2").datepicker({ 
					autoclose: true, 
					todayHighlight: true
			  }).datepicker('update', new Date());
			});
		</script>
		
		<script>
		  $('table').DataTable();
		</script>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>