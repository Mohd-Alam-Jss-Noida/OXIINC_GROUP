<!-- Start Container -->
	  <div class="main-wrapper">
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <div class="my-channel-section-01 customise-channel-section-01">
			  <h2 class="headding-01">Upload Your Video</h2>
			  <div class="block-01 fwd">
			    <div class="banner-img-col fwd">
				  <img src="https://entube.in/alpha/assets/entub.jpg" alt=""/>
				  <div class="upload-img-col">
				    <img src="https://entube.in/alpha/uploads/Customer_pan/1676192721_entube_image.png" alt=""/>
				  </div>
				  <div class="edit-btn" data-toggle="modal" data-target="#UploadImage"><i class="fas fa-pencil-alt"></i></div>
				  <div class="edit-btn-2" data-toggle="modal" data-target="#UploadBannerImage"><i class="fas fa-pencil-alt"></i></div>
				</div>
				<!-- User Image Upload Modal -->
				<div class="modal fade login-container" id="UploadImage" tabindex="-1" role="dialog" aria-labelledby="UploadImageLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content login-form-block">
					  <div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<div class="fwd">
						  <img src="https://entube.in/alpha/uploads/Customer_pan/1676192721_entube_image.png" class="up-user-img" alt=""/>
						</div>
						<div class="fwd">
						  <input type="file" id="photo" hidden="hidden" />
						  <button type="button" id="channel-icon-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
						  <span id="channel-icon-text" class="upload-video-text">No file chosen, yet.</span>
						  <button type="button" class="cust-channel-btn upload-video-btn">Submit</button>
						  <div class="erroemsg" style="display:none;">Please enter valid text</div>
						</div>
					  </div>
					</div>
				  </div>
				</div>
				<!-- User Banner Image Upload Modal -->
				<div class="modal fade login-container" id="UploadBannerImage" tabindex="-1" role="dialog" aria-labelledby="UploadIBannerImageLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content login-form-block">
					  <div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						  <img src="https://entube.in/alpha/assets/entub.jpg" class="up-banner-img" alt=""/>
						  <input type="file" id="channel_banner" hidden="hidden" />
						  <button type="button" id="channel-banner-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
						  <span id="channel-banner-text" class="upload-video-text">No file chosen, yet.</span>
						  <button type="button" class="cust-channel-btn upload-video-btn">Submit</button>
					  </div>
					</div>
				  </div>
				</div>
				
			    <div class="left-col">
				  <h3>Mohd Alam Oxiinc Group</h3>
				  <div class="edit-btn"><i class="fas fa-pencil-alt"></i></div>
				  <div class="text-col">View as:</div>
				  <div class="dropdown video-login-popup video-login-popup2">
				    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Yourself <i class="fas fa-caret-down"></i></a>
				    <ul class="dropdown-menu">
					  <li><a href="#">New Visitor</a></li>
					  <li><a href="#">Returning Subscriber</a></li>
				    </ul>
				  </div>
			    </div>
			  </div>
			  
			  <div class="block-02 fwd">
			    <div class="scroller scroller-left"><i class="glyphicon glyphicon-chevron-left"></i></div>
				<div class="scroller scroller-right"><i class="glyphicon glyphicon-chevron-right"></i></div>
				<!-- Nav tabs -->
				<div class="tab-wrapper">
				<ul class="nav nav-tabs list" role="tablist">
				    <li><a href="customise_home.php">Home</a></li>
					<li><a href="customise_videos.php">Videos</a></li>
					<li><a href="#">Playlist</a></li>
					<li><a href="#">Channels</a></li>
					<li><a href="customise_discussion.php">Discussion</a></li>
					<li><a href="customise_about.php">About</a></li>
				</ul>
				</div>
				<div class="devider-col"></div>
