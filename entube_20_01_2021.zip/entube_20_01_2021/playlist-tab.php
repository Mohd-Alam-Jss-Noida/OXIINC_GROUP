<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('my-channel.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start Playlist Tab -->
				  <div role="tabpanel" class="">
				    <div class="tab-container fwd">
					    <div class="tab-title">Created Playlist</div>
						<div class="dropdown video-login-popup video-login-popup2">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
						  <ul class="dropdown-menu">
							<li><a href="#">Most popular</a></li>
							<li><a href="#">Date added (oldest)</a></li>
							<li><a href="#">Date added (newest)</a></li>
						  </ul>
						</div>
					  <p>This channel has no playlists.</p>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>