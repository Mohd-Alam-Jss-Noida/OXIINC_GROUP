<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		
		
		<section class="video-detail-page library-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <!-- Video Left Section -->
			  <div class="left-container">
				<div class="containt-block">
				  <!-- History -->
				  <section class="home-video-slider">
				      <h2 class="headding-01"><i class="fa fa-history"></i> History</h2>
					  <a href="#" class="see-all-link">See All</a>
					  <div class="video-list-inline">		  
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-02.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Message from CMD</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 5100 views</span>
								<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-03.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc Group Information</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
					 </div>	 
				  </section>
				  <div class="clrfix"></div>

				  <!-- Watch later -->
				  <section class="home-video-slider">
				      <h2 class="headding-01"><i class="fa fa-clock"></i> Watch later <span class="no-count">31</span></h2>
					  <div class="video-list-inline">		  
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-02.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Message from CMD</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 5100 views</span>
								<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-03.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc Group Information</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
					 </div>	 
				  </section>
				  <div class="clrfix"></div>
				  
				  <!-- Playlists -->
				  <section class="home-video-slider">
				      <h2 class="headding-01"><i class="fa fa-clock"></i> Playlists</h2>
					  <p>Playlists you create or save will show up here.</p>
					  <!--<div class="video-list-inline">		  
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
					 </div>--> 
				  </section>
				  <div class="clrfix"></div>
				  
				  <!-- Liked videos  -->
				  <section class="home-video-slider">
				      <h2 class="headding-01"><i class="fa fa-thumbs-up"></i> Liked videos <span class="no-count">998</span></h2>
					  <div class="video-list-inline">		  
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-02.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Message from CMD</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 5100 views</span>
								<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-03.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc Group Information</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
						<div class="item equal-height-col">
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
							  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
							  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</div>
					 </div>	 
				  </section>
				  <div class="clrfix"></div>
				</div>
			  </div>
			  
			  
			  <!-- User Details Section -->
			  <div class="right-container">
			    <div class="library-user-col">
				  <div class="user-img"><img src="images/user-img.png" alt=""/></div>
				  <div class="user-name">User Name</div>
				  <div class="user-activity">
				    <span>Subscriptions</span>
					<span>243</span>
				  </div>
				  <div class="user-activity">
				    <span>Uploads</span>
					<span>0</span>
				  </div>
				  <div class="user-activity">
				    <span>Likes</span>
					<span>2,608</span>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>