<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<!-- Css -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
	<!-- Fontawesome -->
	<link href="css/fontawesome/all.css" rel="stylesheet">
	<link href="css/fontawesome/fontawesome.css" rel="stylesheet">
	<link href="css/fontawesome/brands.css" rel="stylesheet">
	<link href="css/fontawesome/solid.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<!-- Owlcarousel -->
	<link rel="stylesheet" href="css/owlcarousel/owl.carousel.min.css">
	<!-- Scrollbar Css -->
	<link href="css/mCustomScrollbar.css" rel="stylesheet" type="text/css" />

	<link href="css/common-style.css" rel="stylesheet">
	<link href="css/home.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	    <!-- Recommendetions -->
		<section class="home-recommendetions-section home-video-slider">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <div class="owl-carousel owl-theme">
				<div class="item">
				  <a href="#" class="list-col">All Recommendetions</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">Bollywood Music</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">Marathi Music</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">Comedy</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">Share Market</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">History</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">Smartphones</a>
				</div>
				<div class="item">
				  <a href="#" class="list-col">Recently uploaded</a>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Banner Section -->
		<div class="banner-section large-devise-screen-home-banner">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		  <ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active">
			  <span class="item-no">1</span>
			  <span class="item-title">Oxiinc.in Information Oxiinc Group Part 1 Projects</span>
			</li>
			<li data-target="#carousel-example-generic" data-slide-to="1">
			  <span class="item-no">2</span>
			  <span class="item-title">Message from CMD</span>
			</li>
			<li data-target="#carousel-example-generic" data-slide-to="2">
			  <span class="item-no">3</span>
			  <span class="item-title">Oxiinc Group Lucknow Program Teaser</span>
			</li>
			<li data-target="#carousel-example-generic" data-slide-to="3">
			  <span class="item-no">4</span>
			  <span class="item-title">Oxiinc Digital literacy program in Mumbai</span>
			</li>
		  </ol>

		  <div class="carousel-inner" role="listbox">
			<div class="item active">
			  <img src="images/banner01.jpg" class="img-responsive" alt="..." data-toggle="modal" data-target="#myModal"/>
			</div>
			<div class="item">
			  <img src="images/banner01.jpg" class="img-responsive" alt="..." data-toggle="modal" data-target="#myModa2"/>
			</div>
			<div class="item">
			  <img src="images/banner01.jpg" class="img-responsive" alt="..." data-toggle="modal" data-target="#myModa3"/>
			</div>
			<div class="item">
			  <img src="images/banner01.jpg" class="img-responsive" alt="..." data-toggle="modal" data-target="#myModa4"/>
			</div>
		  </div>

		  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			<span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			<span class="sr-only">Next</span>
		  </a>
		</div>
		
		
			<!-- Banner Modal 1 -->
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<video width="100%" controls="controls">
				      <source src="https://youtu.be/R4k2rF-6-2I" type="video/mp4" />
				    </video>
				  </div>
				</div>
			  </div>
			</div>
			<!-- Banner Modal 2 -->
			<div class="modal fade" id="myModa2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<video width="100%" controls="controls">
				      <source src="https://youtu.be/R4k2rF-6-2I" type="video/mp4" />
				    </video>
				  </div>
				</div>
			  </div>
			</div>
			<!-- Banner Modal 3 -->
			<div class="modal fade" id="myModa3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<video width="100%" controls="controls">
				      <source src="https://youtu.be/R4k2rF-6-2I" type="video/mp4" />
				    </video>
				  </div>
				</div>
			  </div>
			</div>
			<!-- Banner Modal 4 -->
			<div class="modal fade" id="myModa4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-body">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<video width="100%" controls="controls">
				      <source src="https://youtu.be/R4k2rF-6-2I" type="video/mp4" />
				    </video>
				  </div>
				</div>
			  </div>
			</div>
		</div>
		

		<!-- Recommended Videos Section -->
		<section class="home-section-01 home-video-slider">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <h2 class="headding-01">Recommended</h2>
			  <div class="video-list-inline">
			  
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
					  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-02.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Message from CMD</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 5100 views</span>
					    <span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
				  	  </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-03.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc Group Information</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
			 
			 </div>
			  <hr>
			</div>
		  </div>
		</section>
		

		<!-- Recently Uploaded Videos Section -->
		<section class="home-section-01 home-video-slider">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <h2 class="headding-01">Recently Uploaded</h2>
			  <div class="owl-carousel owl-theme">
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-03.jpg"  class="home-video-item-img"alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Message from CMD</a>
				  	  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 5100 views</span>
					    <span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-04.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc Group Information</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
				  	  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-01.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
				  	  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
				      </div>
					</div>
				  </div>
				</div>
				<div class="item">
				  <div class="item-containt-col">
				    <a href="#" class="video-img-col">
					  <img src="images/video-img/img-02.jpg" class="home-video-item-img" alt=""/>
					  <i class="fas fa-play-circle"></i>
					  <div class="video-overlay"></div>
					</a>
					<div class="video-containt-col">
					  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
					  <a href="#" class="video-title">Enexpress.in Information Oxiinc...</a>
					  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
					  <div class="video-views">
					    <span><i class="far fa-eye"></i> 6876 views</span>
					    <span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
					  </div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <!-- jQuery -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
	    <!-- Fontawesome -->
	    <script defer src="js/fontawesome/all.js"></script>
	    <script defer src="js/fontawesome/brands.js"></script>
	    <script defer src="js/fontawesome/solid.js"></script>
	    <script defer src="js/fontawesome/fontawesome.js"></script>
	    <!-- owlcarousel -->
	    <script src="js/owlcarousel/owl.carousel.js"></script>
		<!-- Scrollbar Script -->
		<script src="js/mCustomScrollbar.concat.min.js"></script>
	  
	    <script src="js/common-script.js"></script>
	    <script src="js/home.js"></script>
		
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.home-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>