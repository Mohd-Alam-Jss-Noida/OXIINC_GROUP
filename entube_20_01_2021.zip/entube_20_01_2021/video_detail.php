<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		
		
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <!-- Video Left Section -->
			  <div class="left-container">
			    <div class="main-video-col">
				  <!--<img src="images/video-detail-banner.jpg" alt="" class="img-responsive"/>-->			  
				  <video width="100%" controls="controls">
				    <source src="https://youtu.be/R4k2rF-6-2I" type="video/mp4" />
				  </video>
				  <!--<i class="fas fa-play-circle"></i>
				  <div class="video-overlay"></div>-->
				</div>
				<div class="containt-block">
				  <h2>Oxiinc.in Information Oxiinc Group Part 1 Projects</h2>
				  <div class="col-left">
				    <span><i class="far fa-eye"></i> 9702 Views</span>
				  </div>
				  <div class="col-right">
				    <span class="dropdown video-login-popup">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="far fa-thumbs-up"></i> 206</a>
					  <ul class="dropdown-menu">
						<li><h4>Want to watch this again later?</h4></li>
						<li>Sign in to add this video to a playlist.</li>
						<li role="separator" class="divider"></li>
						<li><a href="#" class="signin-btn">Sign in</a></li>
					  </ul>
					</span>
					<span class="dropdown video-login-popup">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="far fa-thumbs-down"></i> 10</a>
					  <ul class="dropdown-menu">
						<li><h4>Want to watch this again later?</h4></li>
						<li>Sign in to add this video to a playlist.</li>
						<li role="separator" class="divider"></li>
						<li><a href="#" class="signin-btn">Sign in</a></li>
					  </ul>
					</span>
					<span class="dropdown video-login-popup">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-share-square"></i> Share</a>
					  <ul class="dropdown-menu">
						<li class="social-media">
						  <a href="#"><i class="fab fa-facebook-f"></i></a>
						  <a href="#"><i class="fab fa-twitter"></i></a>
						  <a href="#"><i class="fab fa-whatsapp"></i></a>
						</li>
					  </ul>
					</span>
					<span class="dropdown video-login-popup">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-bars"></i> Save</a>
					  <ul class="dropdown-menu">
						<li><h4>Want to watch this again later?</h4></li>
						<li>Sign in to add this video to a playlist.</li>
						<li role="separator" class="divider"></li>
						<li><a href="#" class="signin-btn">Sign in</a></li>
					  </ul>
					</span>
				  </div>
				</div>
				
				<div class="containt-block">
				  <div class="col-left space-left">
				    <img src="images/channel-logo.png" alt="" class="channel-logo"/>
				    <a href="" class="title-01 fwd">Oxiinc Channel <i class="far fa-check-circle"></i></a>
					<span class="title-02 fwd">Published on Feb-22-2020</span>
				  </div>
				  <div class="col-right col-2-right">
				    <span class="subscribe-btn">Subscribe <strong>1.4M</strong></span>
					<span class="notification-btn"><i class="far fa-bell"></i></span>
				  </div>
				  <div class="col-2-full space-left">
				    <span class="title-03 fwd">Description :</span>
					<span class="title-04 fwd">Oxiinc.in E-Commerce, B2B, B2C, Business & Service Listing Web Site with Reseller Opportunity, Etc</span>
				  </div>
				</div>
				
				<div class="containt-block">
				  <div class="col-left fwd">
				    <span>27 Comments</span>
					<span class="dropdown video-login-popup video-login-popup2">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
					  <ul class="dropdown-menu">
						<li><a href="#">Top Comments</a></li>
						<li><a href="#">Newest First</a></li>
					  </ul>
					</span>
				  </div>
				  <div class="col-left space-left col-3-full">
				    <span class="video-user-icon"><i class="fas fa-user"></i></span>
					<form class="form-horizontal">
					  <textarea class="video-textareabox" placeholder="Add a public comment..." rows="2"></textarea>
					  <button type="submit" class="video-submitbtn">Cancel</button>
					  <button type="submit" class="video-submitbtn">Comment</button>
					</form>    
				  </div>
				  <div class="col-left space-left user-comment-col">
				    <span class="video-user-icon2"><i class="fas fa-user"></i></span>
				    <span class="title-05 fwd">Vikas2222</span>
					<span class="title-06 fwd">Thank you for the explanations.</span>
					<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
					<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
				  </div>
				  <div class="col-left space-left user-comment-col">
				    <span class="video-user-icon2"><i class="fas fa-user"></i></span>
				    <span class="title-05 fwd">Pradeepkumar99</span>
					<span class="title-06 fwd">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs</span>
					<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
					<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
				  </div>
				  <div class="col-left space-left user-comment-col">
				    <span class="video-user-icon2"><i class="fas fa-user"></i></span>
				    <span class="title-05 fwd">Vikas2222</span>
					<span class="title-06 fwd"> is dummy text used in laying out print, graphic or web designs</span>
					<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
					<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
				  </div>
				  <div class="col-left space-left user-comment-col">
				    <span class="video-user-icon2"><i class="fas fa-user"></i></span>
				    <span class="title-05 fwd">Vikas2222</span>
					<span class="title-06 fwd">Thank you for the explanations.</span>
					<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
					<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
				  </div>
				</div>
			  </div>
			  
			  
			  <!-- Video Right Section -->
			  <div class="right-container">
			    <div class="video-detail-advertise-banner">
				  <img src="images/video-detail-advertise-banner.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="block-title">
				  <span>Up Next</span>
				  <span>
				    Autoplay
				    <form>
						<input type="checkbox" name="toggle" id="toggle" class="toggle"checked>
						<label for="toggle"></label>
					</form>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="img-responsive" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="img-responsive" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="img-responsive" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="img-responsive" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="img-responsive" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>