<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('my-channel.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start Discussion Tab -->
				  <div role="tabpanel" class="">
				    <div class="tab-container fwd">
					  <div class="containt-block">
					  <div class="col-left fwd">
						<span>2 Comments</span>
						<span class="dropdown video-login-popup video-login-popup2">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
						  <ul class="dropdown-menu">
							<li><a href="#">Top Comments</a></li>
							<li><a href="#">Newest First</a></li>
						  </ul>
						</span>
					  </div>
					  <div class="col-left space-left col-3-full">
						<span class="video-user-icon"><i class="fas fa-user"></i></span>
						<form class="form-horizontal">
						  <textarea class="video-textareabox" placeholder="Add a public comment..." rows="2"></textarea>
						  <button type="submit" class="video-submitbtn">Cancel</button>
						  <button type="submit" class="video-submitbtn">Comment</button>
						</form>    
					  </div>
					  <div class="col-left space-left user-comment-col">
						<span class="video-user-icon2"><i class="fas fa-user"></i></span>
						<span class="title-05 fwd">Vikas2222</span>
						<span class="title-06 fwd">Thank you for the explanations.</span>
						<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
						<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
					  </div>
					  <div class="col-left space-left user-comment-col">
						<span class="video-user-icon2"><i class="fas fa-user"></i></span>
						<span class="title-05 fwd">Pradeepkumar99</span>
						<span class="title-06 fwd">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs</span>
						<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
						<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
					  </div>
				      </div>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>