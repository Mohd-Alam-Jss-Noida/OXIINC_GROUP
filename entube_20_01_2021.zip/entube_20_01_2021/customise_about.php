<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('customise_header.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start About Tab -->
				  <div>
				    <div class="tab-container fwd">
					  <div class="left-content left-block">
					    <div class="tab-title fwd">
						  7 views  <br>
						  Joined 29 May 2020
						</div>
						<br>
					    <div class="tab-title"><strong>Description</strong></div>
						<div class="textarea-content fwd">
						  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
						  <div class="edit-btn"><i class="fas fa-pencil-alt"></i></div>
						</div>
						<div class="containt-block edit-textarea">
						  <form class="form-horizontal">
						    <textarea class="video-textareabox" placeholder="Add a public comment..." rows="2"></textarea>
							<button type="submit" class="video-submitbtn">Done</button>
						    <button type="submit" class="video-submitbtn">Cancel</button>
						  </form>
						</div>
						
						<div class="detail-col fwd">
						  <div class="tab-title"><strong>Details [?]</strong></div>
						  <div class="textarea-content fwd">
						    <p><strong>For business enquiries:</strong> &nbsp;&nbsp;
						      <span class="email-id">alam.oxxinc@gmail.com</span>[?]
						    </p>
						    <div class="edit-btn"><i class="fas fa-pencil-alt"></i></div>
						  </div>
						  <div class="containt-block edit-textarea">	
						    <p><strong>Email for business enquiries</strong></p><br><br>
						    <form class="form-horizontal">
						      <input type="text" class="video-textareabox" placeholder="Email Id">
							  <button type="submit" class="video-submitbtn">Done</button>
						      <button type="submit" class="video-submitbtn">Cancel</button>
						    </form>
						  </div>
						  <div class="containt-block">
						    <p><strong>Location:</strong></p><br><br>
						    <select class="video-textareabox">
							  <option>1</option>
							  <option>2</option>
							  <option>3</option>
							  <option>4</option>
							  <option>5</option>
							</select>
						  </div>
						</div>
						
						<div class="containt-block">
						  <p><strong>Links:</strong></p><br>
						  <div class="cust-channel-btn add-links-btn"><i class="fas fa-plus"></i> Links</div>
						</div>
					  </div>
					  <div class="right-content right-block">
					    <div class="tab-title">Featured channels</div>
						<div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div>
					  </div>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>