<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('customise_header.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start Playlist Tab -->
				  <div>
				    <div class="tab-container fwd">
					  <div class="left-content left-block">
						<a href="#" class="back-btn"><i class="fas fa-long-arrow-alt-left"></i></a>
						  <div class="tab-title">Created playlists</div>
						  <div class="dropdown video-login-popup video-login-popup2">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SORT BY <i class="fas fa-caret-down"></i></a>
							<ul class="dropdown-menu">
							  <li><a href="#">Last video added</a></li>
							  <li><a href="#">Date added (oldest)</a></li>
							  <li><a href="#">Date added (newest)</a></li>
							</ul>
						  </div>
					    <ul class="list-inline video-list">	
							<li>
							   <a href="#" class="item-containt-col">
								<div class="video-img-col video-img-block">
								  <div class="playlist-text" style="background:url(https://entube.in/alpha/uploads/product/295399750_entube_image_gagan.png);">
									<div class="playlist-col">
									  <h4>1</h4>
									  <img src="https://entube.in/alpha/black/img/play.png" style="width: 20px">
									</div>
								  </div>
								  <div class="play-all-txt">
								    <i class="fas fa-play-circle"></i> 
									<span>Play All</span>
								  </div>
								  <div class="video-overlay"></div>
								</div>
								<div class="video-containt-col">
								  <div class="video-title">My video playlist</div>
								</div>
							   </a>     
							</li>
							<li>
							   <a href="#" class="item-containt-col">
								<div class="video-img-col video-img-block">
								  <div class="playlist-text" style="background:url(https://entube.in/alpha/uploads/product/295399750_entube_image_gagan.png);">
									<div class="playlist-col">
									  <h4>1</h4>
									  <img src="https://entube.in/alpha/black/img/play.png" style="width: 20px">
									</div>
								  </div>
								  <div class="play-all-txt">
								    <i class="fas fa-play-circle"></i> 
									<span>Play All</span>
								  </div>
								  <div class="video-overlay"></div>
								</div>
								<div class="video-containt-col">
								  <div class="video-title">My video playlist</div>
								</div>
							   </a>     
							</li>
							<li>
							   <a href="#" class="item-containt-col">
								<div class="video-img-col video-img-block">
								  <div class="playlist-text" style="background:url(https://entube.in/alpha/uploads/product/295399750_entube_image_gagan.png);">
									<div class="playlist-col">
									  <h4>1</h4>
									  <img src="https://entube.in/alpha/black/img/play.png" style="width: 20px">
									</div>
								  </div>
								  <div class="play-all-txt">
								    <i class="fas fa-play-circle"></i> 
									<span>Play All</span>
								  </div>
								  <div class="video-overlay"></div>
								</div>
								<div class="video-containt-col">
								  <div class="video-title">My video playlist</div>
								</div>
							   </a>     
							</li>
							<li>
							   <a href="#" class="item-containt-col">
								<div class="video-img-col video-img-block">
								  <div class="playlist-text" style="background:url(https://entube.in/alpha/uploads/product/295399750_entube_image_gagan.png);">
									<div class="playlist-col">
									  <h4>1</h4>
									  <img src="https://entube.in/alpha/black/img/play.png" style="width: 20px">
									</div>
								  </div>
								  <div class="play-all-txt">
								    <i class="fas fa-play-circle"></i> 
									<span>Play All</span>
								  </div>
								  <div class="video-overlay"></div>
								</div>
								<div class="video-containt-col">
								  <div class="video-title">My video playlist</div>
								</div>
							   </a>     
							</li>
						</ul>
					  </div>
					  <div class="right-content right-block">
					    <div class="tab-title">Featured channels</div>
						<div class="cust-channel-btn add-channels-btn"><i class="fas fa-plus"></i> Add Channels</div>
					  </div>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>