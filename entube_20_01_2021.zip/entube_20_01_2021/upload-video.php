<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
		<div class="main-wrapper">
		  <section class="video-detail-page">
			<div class="row">
			  <div class="container-fluid large-devise-screen">
				<div class="my-channel-section-01 guest-profile-section-01 video-upload-section-01">
				  <div class="main-title myvws-section-01">
					<h2 class="headding-01">Upload Video</h2>
				  </div>
				  <div class="login-form-block">
				    
					
					
					
				    <form>
					  <div class="right-block">
				      <div class="form-group full-width-col">
					    <input type="file" id="real-file" hidden="hidden" />
					    <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn"><i class="fa fa-upload"></i> Upload Video</button>
					    <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
						<div class="video-col">
						  <img src="images/video-watermark.png" class="img-responsive" alt=""/>
						</div>
					  </div>
				     </div> 
					
					  <div class="left-block">
					    <div class="form-group full-width-col">
					      <label>Video Title (required)</label>
						  <input type="text" class="input-textbox input-video-title" id="">
						  <div id="the-count">
							<span id="current">0</span>
							<span id="maximum">/ 100</span>
						  </div>
						  <div class="erroemsg" style="display:none;">Please enter valid text</div>
					    </div>
					
						<div class="form-group full-width-col">
					      <label>Video Description</label>
						  <textarea class="input-textarea input-video-desc" name="the-textarea" id="the-textarea" maxlength="5000" placeholder="Tell viewers about your video" autofocus></textarea>
						  <div id="the-count">
							<span id="current">0</span>
							<span id="maximum">/ 5000</span>
						  </div>
						  <div class="erroemsg" style="display:none;">Please enter valid text</div>
					    </div>
						
						<div class="form-group full-width-col">
					      <label>Thumbnail</label>
						  <p class="note-txt">Select or upload a picture that shows what's in your video. A good thumbnail stands out and draws viewers' attention.</p>
						  <input type="file" id="real-file" hidden="hidden" />
						  <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn"><i class="fa fa-upload"></i> Upload Thumbnail</button>
						  <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
						  <p class="note-txt-2" style="margin-top:8px;">Note: size : 400 * 230</p>
						  <div class="video_container_hide">
							<ul class="list-inline thumb-list equal-height-col">
							  <li><img src="images/thumbnail-watermark.png" class="img-responsive" alt=""/></li>
							  <li><img src="images/video-watermark.png" class="img-responsive" alt=""/></li>
							  <li><img src="images/video-watermark.png" class="img-responsive" alt=""/></li>
							  <li><img src="images/video-watermark.png" class="img-responsive" alt=""/></li>
							  <li><img src="images/video-watermark.png" class="img-responsive" alt=""/></li>
							</ul>
						  </div>
					    </div>					
						
						<div class="form-group half-width">
					      <label>Video Category</label>
						  <input type="text" class="input-textbox" id="">
						  <div class="erroemsg" style="display:none;">Please enter valid text</div>
					    </div>
						<div class="form-group half-width">
					      <label>Video Playlists</label>
						  <select class="input-textbox input-selectbox">
						    <option>Select Option</option>
						    <option>1</option>
						    <option>2</option>
					  	  </select>
						  <div class="erroemsg" style="display:none;">Please select playlists</div>
					    </div>
					    <div class="form-group half-width">
					      <label>Video Audience</label>
						  <select class="input-textbox input-selectbox">
						    <option>Yes, it's Made for Kids.</option>
						    <option>No, it's not Made for Kids</option>
						  </select>
						  <div class="erroemsg" style="display:none;">Please select audience</div>
					    </div>
					    <div class="form-group half-width">
					      <label>Video Visibility</label>
						  <select class="input-textbox input-selectbox">
						    <option>Public</option>
						    <option>Private</option>
						    <option>Unlist</option>
						  </select>
						  <div class="erroemsg" style="display:none;">Please select visibility</div>
					    </div>
						<div class="form-group full-width-col">
					      <label>Video Hashtag (Optional)</label>
						  <p class="note-txt-2">Note: Add space after each hashtag</p>
						  <textarea class="input-textarea" rows="3"></textarea>
						  <div class="erroemsg" style="display:none;">Please enter valid text</div>
					    </div>
						
						<div class="form-group full-width-col center-align-btn">
					      <button type="submit" class="input-submitbtn">Save Draft</button>
					      <button type="submit" class="input-submitbtn">Publish</button>
					      <div class="sucessmsg" style="display:none;">Sucessfully login</div>
					    </div>
					  </div>
					</form>
				    
				    
				  
					<!--<form style="display:none;">
					  <div class="form-group half-width">
					    <input type="file" id="real-file" hidden="hidden" />
					    <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
					    <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
					  </div>
					  <div class="form-group half-width">
					    <input type="file" id="real-file" hidden="hidden" />
					    <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn">Upload Image</button>
					    <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
					  </div>
					  <br>
					  <div class="clrfix"></div>
					  <br>
					  <div class="form-group half-width">
					    <label>Video Name</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Title</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Category</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Sub Category</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Shrot Description</label>
						<textarea class="input-textarea" rows="3"></textarea>
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Large Description</label>
						<textarea class="input-textarea" rows="3"></textarea>
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group full-width-col">
					    <label>Specification Description</label>
						<textarea class="input-textarea" rows="3"></textarea>
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Playlists</label>
						<select class="input-textbox input-selectbox">
						  <option>Select Option</option>
						  <option>1</option>
						  <option>2</option>
						</select>
						<div class="erroemsg" style="display:none;">Please select playlists</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Audience</label>
						<select class="input-textbox input-selectbox">
						  <option>Yes, it's Made for Kids.</option>
						  <option>No, it's not Made for Kids</option>
						</select>
						<div class="erroemsg" style="display:none;">Please select audience</div>
					  </div>
					  <div class="form-group full-width-col">
					    <label>Video Visibility</label>
						<select class="input-textbox input-selectbox">
						  <option>Public</option>
						  <option>Private</option>
						  <option>Unlist</option>
						</select>
						<div class="erroemsg" style="display:none;">Please select visibility</div>
					  </div>
					  <div class="form-group full-width-col center-align-btn">
					    <button type="submit" class="input-submitbtn">Sign in</button>
					    <button type="submit" class="input-submitbtn">Reset</button>
					    <div class="sucessmsg" style="display:none;">Sucessfully login</div>
					  </div>				  
					</form>-->
					
				  </div>
				</div>
			  </div>
			</div>
		  </section>
		  <div class="clrfix"></div>			 
		</div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
		
		<script>
		  $('textarea').keyup(function() {
			  var characterCount = $(this).val().length,
				  current = $('#current'),
				  maximum = $('#maximum'),
				  theCount = $('#the-count');
				
			  current.text(characterCount);
			 
			  
			  /*This isn't entirely necessary, just playin around*/
			  if (characterCount < 70) {
				current.css('color', '#666');
			  }
			  if (characterCount > 70 && characterCount < 90) {
				current.css('color', '#6d5555');
			  }
			  if (characterCount > 90 && characterCount < 100) {
				current.css('color', '#793535');
			  }
			  if (characterCount > 100 && characterCount < 120) {
				current.css('color', '#841c1c');
			  }
			  if (characterCount > 120 && characterCount < 139) {
				current.css('color', '#8f0001');
			  }
			  
			  if (characterCount >= 140) {
				maximum.css('color', '#8f0001');
				current.css('color', '#8f0001');
				theCount.css('font-weight','bold');
			  } else {
				maximum.css('color','#666');
				theCount.css('font-weight','normal');
			  }
			  
				  
			});  
		</script>
		
		
	  <!-- End Footer -->
    </div>
  </body>
</html>