<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <div class="my-channel-section-01 channel-dashboard-section-01">
				<h2 class="headding-01">Channel videos</h2>
				<a href="#" class="cust-channel-btn">Upload Video</a>
				<div class="sucess-msg">Sucessfully update</div>
				<div class="dashboard-table fwd">
				
				  <div class="dashboard-table-content table-head">
				    <div class="default-col col-0">Sr No.</div>
				    <div class="default-col col-1">Video</div>
					<div class="default-col col-2">Visibility</div>
					<div class="default-col col-3">Restrictions</div>
					<div class="default-col col-4">Status</div>
					<div class="default-col col-5">Date</div>
					<div class="default-col col-6">Views</div>
					<div class="default-col col-7">Comments</div>
					<div class="default-col col-8">Likes</div>
					<div class="default-col col-9">Dislike</div>
				  </div>
				  
				  <div class="dashboard-table-content fwd">
				    <div class="default-col col-0">1</div>
				    <div class="default-col col-1">
					  <div class="img-col">
					    <img src="https://entube.in/alpha/uploads/product/1034595956_entube_image_gagan.png" alt=""/>
					  </div>
					  <div class="title-col">
					    Flag Video <br>
						<i class="fas fa-pencil-alt"></i>
						<i class="fas fa-trash-alt"></i>
					  </div>
					</div>
					<div class="default-col col-2">
					  <i class="far fa-eye"></i> Public
					</div>
					<div class="default-col col-3">
					  Copyright claim <br>
					  + 1 more
					</div>
					<div class="default-col col-4">Active</div>
					<div class="default-col col-5">
					  2 Jun 2020 <br>
					  Published
					</div>
					<div class="default-col col-6">1</div>
					<div class="default-col col-7">0</div>
					<div class="default-col col-8">1</div>
					<div class="default-col col-9">1</div>
				  </div>
				  
				  <div class="dashboard-table-content fwd">
				    <div class="default-col col-0"><strong>1</strong></div>
				    <div class="default-col col-1">
					  <div class="img-col">
					    <img src="https://entube.in/alpha/uploads/product/1034595956_entube_image_gagan.png" alt=""/>
					  </div>
					  <div class="title-col">
					    Flag Video <br>
						<i class="fas fa-pencil-alt"></i>
						<i class="fas fa-trash-alt"></i>
					  </div>
					</div>
					<div class="default-col col-2">
					  <i class="far fa-eye"></i> Public
					</div>
					<div class="default-col col-3">
					  Copyright claim <br>
					  + 1 more
					</div>
					<div class="default-col col-4">Active</div>
					<div class="default-col col-5">
					  2 Jun 2020 <br>
					  Published
					</div>
					<div class="default-col col-6">1</div>
					<div class="default-col col-7">0</div>
					<div class="default-col col-8">1</div>
					<div class="default-col col-9">1</div>
				  </div>
				  
				  <div class="dashboard-table-content fwd">
				    <div class="default-col col-0">1</div>
				    <div class="default-col col-1">
					  <div class="img-col">
					    <img src="https://entube.in/alpha/uploads/product/1034595956_entube_image_gagan.png" alt=""/>
					  </div>
					  <div class="title-col">
					    Flag Video <br>
						<i class="fas fa-pencil-alt"></i>
						<i class="fas fa-trash-alt"></i>
					  </div>
					</div>
					<div class="default-col col-2">
					  <i class="far fa-eye"></i> Public
					</div>
					<div class="default-col col-3">
					  Copyright claim <br>
					  + 1 more
					</div>
					<div class="default-col col-4">Active</div>
					<div class="default-col col-5">
					  2 Jun 2020 <br>
					  Published
					</div>
					<div class="default-col col-6">1</div>
					<div class="default-col col-7">0</div>
					<div class="default-col col-8">1</div>
					<div class="default-col col-9">1</div>
				  </div>
				  
				  <div class="dashboard-table-content fwd">
				    <div class="default-col col-0">1</div>
				    <div class="default-col col-1">
					  <div class="img-col">
					    <img src="https://entube.in/alpha/uploads/product/1034595956_entube_image_gagan.png" alt=""/>
					  </div>
					  <div class="title-col">
					    Flag Video <br>
						<i class="fas fa-pencil-alt"></i>
						<i class="fas fa-trash-alt"></i>
					  </div>
					</div>
					<div class="default-col col-2">
					  <i class="far fa-eye"></i> Public
					</div>
					<div class="default-col col-3">
					  Copyright claim <br>
					  + 1 more
					</div>
					<div class="default-col col-4">Active</div>
					<div class="default-col col-5">
					  2 Jun 2020 <br>
					  Published
					</div>
					<div class="default-col col-6">1</div>
					<div class="default-col col-7">0</div>
					<div class="default-col col-8">1</div>
					<div class="default-col col-9">1</div>
				  </div>
				  
				  <div class="dashboard-table-content fwd">
				    <div class="default-col col-0">1</div>
				    <div class="default-col col-1">
					  <div class="img-col">
					    <img src="https://entube.in/alpha/uploads/product/1034595956_entube_image_gagan.png" alt=""/>
					  </div>
					  <div class="title-col">
					    Flag Video <br>
						<i class="fas fa-pencil-alt"></i>
						<i class="fas fa-trash-alt"></i>
					  </div>
					</div>
					<div class="default-col col-2">
					  <i class="far fa-eye"></i> Public
					</div>
					<div class="default-col col-3">
					  Copyright claim <br>
					  + 1 more
					</div>
					<div class="default-col col-4">Active</div>
					<div class="default-col col-5">
					  2 Jun 2020 <br>
					  Published
					</div>
					<div class="default-col col-6">1</div>
					<div class="default-col col-7">0</div>
					<div class="default-col col-8">1</div>
					<div class="default-col col-9">1</div>
				  </div>
				  
				
				  
				    <nav aria-label="Page navigation">
					  <ul class="pagination">
						<li>
						  <a href="#" aria-label="Previous">
							<span aria-hidden="true">&laquo;</span>
						  </a>
						</li>
						<li><a href="#">1</a></li>
						<li><a href="#">2</a></li>
						<li><a href="#">3</a></li>
						<li><a href="#">4</a></li>
						<li><a href="#">5</a></li>
						<li>
						  <a href="#" aria-label="Next">
							<span aria-hidden="true">&raquo;</span>
						  </a>
						</li>
					  </ul>
					</nav>
				</div>
			 </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
    </div>
  </body>
</html>