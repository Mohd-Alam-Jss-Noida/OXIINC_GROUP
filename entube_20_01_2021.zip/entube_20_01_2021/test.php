<!DOCTYPE html>

<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<!-- Css -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800|Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet"> 
	<!-- Fontawesome -->
	<link href="css/fontawesome/all.css" rel="stylesheet">
	<link href="css/fontawesome/fontawesome.css" rel="stylesheet">
	<link href="css/fontawesome/brands.css" rel="stylesheet">
	<link href="css/fontawesome/solid.css" rel="stylesheet">
	<link href="css/animate.css" rel="stylesheet">
	<!-- Owlcarousel -->
	<link rel="stylesheet" href="css/owlcarousel/owl.carousel.min.css">
	
	<!-- Scrollbar Css -->
	<link href="css/mCustomScrollbar.css" rel="stylesheet" type="text/css" />

	<link href="css/common-style.css" rel="stylesheet">
	<link href="css/home.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
  </head>

<body>


<div class="container">

    <br/>

    <h2>Custom scrollbar using jquery mcustomscrollbar Plugin</h2>

    <br/>

    <div class="scrollbox" style="width:400px; height:200px; color:#000;">

      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod

      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,

      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo

      consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse

      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non

      proident, sunt in culpa qui officia deserunt mollit anim id est laborum.


      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod

      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,

      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo

      consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse

      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non

      proident, sunt in culpa qui officia deserunt mollit anim id est laborum.


      Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod

      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,

      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo

      consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse

      cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non

      proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

    </div>

</div>

 <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <!-- jQuery -->
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	    <script src="js/bootstrap.min.js"></script>
	    <!-- Fontawesome -->
	    <script defer src="js/fontawesome/all.js"></script>
	    <script defer src="js/fontawesome/brands.js"></script>
	    <script defer src="js/fontawesome/solid.js"></script>
	    <script defer src="js/fontawesome/fontawesome.js"></script>
	    <!-- owlcarousel -->
	    <script src="js/owlcarousel/owl.carousel.js"></script>
		<!-- Scrollbar Script -->
		<script src="js/mCustomScrollbar.concat.min.js"></script>
	  
	    <script src="js/common-script.js"></script>
	    <script src="js/home.js"></script>
	  <!-- End Footer -->
<script>


	

</script>


</body>

</html>