<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		
		
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <!-- Video Left Section -->
			  <div class="left-container">
				<div class="containt-block">
					<section class="trending-section-01">
					  <a href="#" class="trending-cat">
						<span class="icon-col"><img src="images/tmusic-icon.png" alt=""></span>
						<span class="title-col">Music</span>
					  </a>
					  <a href="#" class="trending-cat">
						<span class="icon-col"><img src="images/tnews-icon.png" alt=""></span>
						<span class="title-col">News</span>
					  </a>
					  <a href="#" class="trending-cat">
						<span class="icon-col"><img src="images/tmovies-icon.png" alt=""></span>
						<span class="title-col">Movies</span>
					  </a>
					  <a href="#" class="trending-cat">
						<span class="icon-col"><img src="images/tgaming-icon.png" alt=""></span>
						<span class="title-col">Gaming</span>
					  </a>
					</section>
					
					<section class="trending-section-02 home-video-slider">
						  <div class="video-list-inline">
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-01.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#1Trending Oxiinc.in E-Commerce, B2B, B2C, Business & Service Listing Web Site with Reseller Opportunity, Etc.</a>
								  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 6876 views</span>
									<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-02.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#2Trending Oxiinc.com Consumers Empowerment on Digital media platform with digital business with Data Security System , Etc.</a>
								  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 5100 views</span>
									<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-03.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#3Trending Entube.in Information Oxiinc Group Part 1 Projects Advertise Program Launched with new offers for content creators,</a>
								  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 6876 views</span>
									<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-01.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#4Trending Ouropinion.in Feedback Data Collection third party service Launched For Manufacturer, Products Supplier, Politician, Etc.</a>
								  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 6876 views</span>
									<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>
						 </div>
					</section>
					
					
					<section class="trending-section-02 home-video-slider">
						  <h2 class="headding-01">Recently trending</h2>
						  <div class="video-list-inline">
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-01.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#1Trending Oxiinc.in E-Commerce, B2B, B2C, Business & Service Listing Web Site with Reseller Opportunity, Etc.</a>
								  <a href="#" class="video-channel" style="color:#fff;">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 6876 views</span>
									<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-02.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#2Trending Oxiinc.com Consumers Empowerment on Digital media platform with digital business with Data Security System , Etc.</a>
								  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 5100 views</span>
									<span><i class="far fa-calendar-alt"></i> 2 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>
							<div class="item equal-height-col">
							  <div class="item-containt-col">
								<a href="#" class="video-img-col">
								  <img src="images/video-img/img-03.jpg" class="trending-video-item-img" alt=""/>
								  <i class="fas fa-play-circle"></i>
								  <div class="video-overlay"></div>
								</a>
								<div class="video-containt-col">
								  <div class="chanel-img-col"><img src="images/chanel-img.jpg" alt=""/></div>
								  <a href="#" class="video-title">#3Trending Entube.in Information Oxiinc Group Part 1 Projects Advertise Program Launched with new offers for content creators,</a>
								  <a href="#" class="video-channel">Oxiinc Channel <i class="fas fa-check-circle"></i></a>
								  <div class="video-views">
									<span><i class="far fa-eye"></i> 6876 views</span>
									<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
								  </div>
								</div>
								<span class="dropdown video-login-popup video-login-popup2">
								  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
								  <ul class="dropdown-menu">
								    <li><a href="#"><i class="fas fa-fw fa-star"></i> Add To Watch Later</a></li>
								    <li><a href="#"><i class="fas fa-fw fa-signal"></i> Add To Playlist</a></li>
								  </ul>
							    </span>
							  </div>
							</div>					
						 </div>
						  <hr>
					</section>
				</div>
			  </div>
			  
			  
			  <!-- Video Right Section -->
			  <div class="right-container">
			    <h2 class="headding-01">Most Popular</h2>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="trending-mp-video-img" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="trending-mp-video-img" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="trending-mp-video-img" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="trending-mp-video-img" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
				<div class="video-card">
				  <div class="video-card-img">
				    <img src="images/video-card-img.jpg" class="trending-mp-video-img" alt=""/>
					<i class="fas fa-play-circle"></i>
					<div class="video-overlay"></div>
				  </div>
				  <div class="video-card-info">
				    <span class="title"><a href="#">Entube.in Information Oxiinc Group Part 1 Projects</a></span>
					<span class="channel-title"><a href="#">Oxiinc Channel <i class="far fa-check-circle"></i></a></span>
					<span class="view-text">170 Views</span>
				  </div>
				  <span class="dropdown video-login-popup video-login-popup2">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
					<ul class="dropdown-menu">
					  <li><a href="#"><i class="fas fa-fw fa-star"></i> Top Rated</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-signal"></i> Viewed</a></li>
					  <li><a href="#"><i class="fas fa-fw fa-times-circle"></i> Close</a></li>
					</ul>
				  </span>
				</div>
			  </div>
			</div>
		  </div>
		</section>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>