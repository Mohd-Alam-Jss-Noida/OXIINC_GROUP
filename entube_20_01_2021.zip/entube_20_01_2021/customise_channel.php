<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <div class="my-channel-section-01 customise-channel-section-01">
			  <div class="block-01 fwd">
			    <div class="banner-img-col fwd">
				  <img src="https://entube.in/alpha/assets/entub.jpg" alt=""/>
				  <div class="upload-img-col">
				    <img src="https://entube.in/alpha/uploads/Customer_pan/1676192721_entube_image.png" alt=""/>
				  </div>
				  <div class="edit-btn" data-toggle="modal" data-target="#UploadImage"><i class="fas fa-pencil-alt"></i></div>
				  <div class="edit-btn-2" data-toggle="modal" data-target="#UploadBannerImage"><i class="fas fa-pencil-alt"></i></div>
				</div>
				<!-- User Image Upload Modal -->
				<div class="modal fade login-container" id="UploadImage" tabindex="-1" role="dialog" aria-labelledby="UploadImageLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content login-form-block">
					  <div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						  <img src="https://entube.in/alpha/uploads/Customer_pan/1676192721_entube_image.png" class="up-user-img" alt=""/>
						  <input type="file" id="real-file" hidden="hidden" />
						  <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
						  <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
					  </div>
					</div>
				  </div>
				</div>
				<!-- User Banner Image Upload Modal -->
				<div class="modal fade login-container" id="UploadBannerImage" tabindex="-1" role="dialog" aria-labelledby="UploadIBannerImageLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content login-form-block">
					  <div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						  <img src="https://entube.in/alpha/assets/entub.jpg" class="up-banner-img" alt=""/>
						  <input type="file" id="real-file" hidden="hidden" />
						  <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
						  <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
					  </div>
					</div>
				  </div>
				</div>
				
			    <div class="left-col">
				  <h3>Mohd Alam Oxiinc Group</h3>
				  <div class="text-col">View as:</div>
				  <div class="dropdown video-login-popup video-login-popup2">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Yourself <i class="fas fa-caret-down"></i></a>
				  <ul class="dropdown-menu">
					<li><a href="#">New Visitor</a></li>
					<li><a href="#">Returning Subscriber</a></li>
				  </ul>
				  </div>
			    </div>
			  </div>
			  
			  <div class="block-02 fwd">
			    <div class="scroller scroller-left"><i class="glyphicon glyphicon-chevron-left"></i></div>
				<div class="scroller scroller-right"><i class="glyphicon glyphicon-chevron-right"></i></div>
				<!-- Nav tabs -->
				<div class="tab-wrapper">
				<ul class="nav nav-tabs list" role="tablist">
				  <li class="active"><a href="#home-tab" data-toggle="tab">Home</a></li>
					<li><a href="#videos-tab" data-toggle="tab">Videos</a></li>
					<li><a href="#playlist-tab" data-toggle="tab">Playlist</a></li>
					<li><a href="#channels-tab" data-toggle="tab">Channels</a></li>
					<li><a href="#discussion-tab" data-toggle="tab">Discussion</a></li>
					<li><a href="#about-tab" data-toggle="tab">About</a></li>
				</ul>
				</div>
			   <!-- Tab panes -->
				<div class="tab-content">
				  <!-- Start Home Tab -->
				  <div role="tabpanel" class="tab-pane fade in active" id="home-tab">
				    <div class="tab-container fwd">
					  <p>Home content here...</p>
					</div>  
				  </div>
				  
				  <!-- Start Videos Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="videos-tab">
				    <div class="tab-container fwd">
					  <p>Video content here...</p>
					</div>
				  </div>
				  
				  <!-- Start Playlist Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="playlist-tab">
				    <div class="tab-container fwd">
					  <p>This channel has no playlists.</p>
					</div>
				  </div>
				  
				  <!-- Start Channels Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="channels-tab">
				    <div class="tab-container fwd">
					  <p>This channel doesn't feature any other channels.</p>
					</div>
				  </div>
				  
				  <!-- Start Discussion Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="discussion-tab">
				    <div class="tab-container fwd">
					  <p>Discussion content here...</p>
					</div>
				  </div>
				  
				  <!-- Start About Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="about-tab">
				    <div class="tab-container fwd">
					  <p>About content here...</p>
				    </div>
				  </div>
			    </div>
			  </div>
		    </div>
		  </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
    </div>
  </body>
</html>