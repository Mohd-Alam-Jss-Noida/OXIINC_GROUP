
<!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- Fontawesome -->
  <script defer src="js/fontawesome/all.js"></script>
  <script defer src="js/fontawesome/brands.js"></script>
  <script defer src="js/fontawesome/solid.js"></script>
  <script defer src="js/fontawesome/fontawesome.js"></script>
  <!-- Scrollbar Script -->
  <script src="js/mCustomScrollbar.concat.min.js"></script>
  <!-- Scrolling Tab Script -->
  <script src="js/scrolling-tab/scrolling-tab.js"></script>
  
  <!-- Datepicker Script --> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
  <!-- Data Table Script -->
  <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.21/datatables.min.js"></script>


  <script defer src="js/common-script.js"></script>
  <script defer src="js/custom-inner-script.js"></script>
