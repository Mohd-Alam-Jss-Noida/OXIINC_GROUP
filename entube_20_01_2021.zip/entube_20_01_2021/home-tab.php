<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('my-channel.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start Home Tab -->
				  <div role="tabpanel" class="">
				    <div class="tab-container fwd">
					  <div class="upload-icon"><img src="images/file-upload-icon.png" alt=""/></div>
					  <h4>Upload a video to get started</h4>
					  <p>Start sharing story and connecting with viewers. Videos you upload will show up here.</p>
					  <input type="file" id="real-file" hidden="hidden" />
					  <button type="button" id="upload-video-btn" class="cust-channel-btn">Upload Video</button>
					  <span id="upload-video-text">No file chosen, yet.</span>
					  <p class="more-txt">Learn more about <a href="#">how to get started</a></p>
					</div>  
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>