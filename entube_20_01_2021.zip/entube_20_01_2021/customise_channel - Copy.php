<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		<section class="video-detail-page">
		  <div class="row">
		    <div class="container-fluid large-devise-screen">
			  <div class="my-channel-section-01 customise-channel-section-01">
			  <div class="block-01 fwd">
			    <div class="banner-img-col fwd">
				  <img src="https://entube.in/alpha/assets/entub.jpg" alt=""/>
				  <div class="upload-img-col">
				    <img src="images/user-upload-img.jpg" alt=""/>
				  </div>
				  <div class="edit-btn"><i class="fas fa-pencil-alt" data-toggle="modal" data-target="#UploadImage"></i></div>
				  <div class="edit-btn-2"><i class="fas fa-pencil-alt"></i></div>
				</div>
				<!-- User Image Upload Modal -->
				<div class="modal fade login-container" id="UploadImage" tabindex="-1" role="dialog" aria-labelledby="UploadImageLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content login-form-block">
					  <div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						  <img src="images/user-upload-img.jpg" alt=""/>
						  <input type="file" id="real-file" hidden="hidden" />
						  <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
						  <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
					  </div>
					</div>
				  </div>
				</div>
				<!-- User Banner Image Upload Modal -->
				<div class="modal fade login-container" id="UploadImage" tabindex="-1" role="dialog" aria-labelledby="UploadImageLabel">
				  <div class="modal-dialog" role="document">
					<div class="modal-content login-form-block">
					  <div class="modal-body">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						  <img src="images/user-upload-img.jpg" alt=""/>
						  <input type="file" id="real-file" hidden="hidden" />
						  <button type="button" id="upload-video-btn" class="cust-channel-btn upload-video-btn">Upload Video</button>
						  <span id="upload-video-text" class="upload-video-text">No file chosen, yet.</span>
					  </div>
					</div>
				  </div>
				</div>
				
			    <div class="left-col">
				  <h3>Mohd Alam Oxiinc Group</h3>
				  <div class="text-col">View as:</div>
				  <div class="dropdown video-login-popup video-login-popup2">
				  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Yourself <i class="fas fa-caret-down"></i></a>
				  <ul class="dropdown-menu">
					<li><a href="#">New Visitor</a></li>
					<li><a href="#">Returning Subscriber</a></li>
				  </ul>
				  </div>
			    </div>
			  </div>
			  
			  <div class="block-02 fwd">
			    <div class="scroller scroller-left"><i class="glyphicon glyphicon-chevron-left"></i></div>
				<div class="scroller scroller-right"><i class="glyphicon glyphicon-chevron-right"></i></div>
				<!-- Nav tabs -->
				<div class="tab-wrapper">
				<ul class="nav nav-tabs list" role="tablist">
				  <li class="active"><a href="#home-tab" data-toggle="tab">Home</a></li>
					<li><a href="#videos-tab" data-toggle="tab">Videos</a></li>
					<li><a href="#playlist-tab" data-toggle="tab">Playlist</a></li>
					<li><a href="#channels-tab" data-toggle="tab">Channels</a></li>
					<li><a href="#discussion-tab" data-toggle="tab">Discussion</a></li>
					<li><a href="#about-tab" data-toggle="tab">About</a></li>
				</ul>
				</div>
			   <!-- Tab panes -->
				<div class="tab-content">
				  <!-- Start Home Tab -->
				  <div role="tabpanel" class="tab-pane fade in active" id="home-tab">
				    <div class="tab-container fwd">
					  <div class="upload-icon"><img src="images/file-upload-icon.png" alt=""/></div>
					  <h4>Upload a video to get started</h4>
					  <p>Start sharing story and connecting with viewers. Videos you upload will show up here.</p>
					  <input type="file" id="real-file" hidden="hidden" />
					  <button type="button" id="upload-video-btn" class="cust-channel-btn">Upload Video</button>
					  <span id="upload-video-text">No file chosen, yet.</span>
					  <p class="more-txt">Learn more about <a href="#">how to get started</a></p>
					</div>  
				  </div>
				  
				  <!-- Start Videos Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="videos-tab">
				    <div class="tab-container fwd">
					    <div class="tab-title">Uploads</div>
						<div class="dropdown video-login-popup video-login-popup2">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
						  <ul class="dropdown-menu">
							<li><a href="#">Most popular</a></li>
							<li><a href="#">Date added (oldest)</a></li>
							<li><a href="#">Date added (newest)</a></li>
						  </ul>
						</div>
					  <ul class="list-inline video-list">
					    <li>
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</li>
						<li>
						  <div class="item-containt-col">
							<a href="#" class="video-img-col">
							  <img src="images/video-img/img-01.jpg" alt=""/>
							  <i class="fas fa-play-circle"></i>
							  <div class="video-overlay"></div>
							</a>
							<div class="video-containt-col">
							  <a href="#" class="video-title">Oxiinc.in Information Oxiinc...</a>
							  <div class="video-views">
								<span><i class="far fa-eye"></i> 6876 views</span>
								<span><i class="far fa-calendar-alt"></i> 1 Weeks ago</span>
							  </div>
							</div>
						  </div>
						</li>
					  </ul>
					</div>
				  </div>
				  
				  <!-- Start Playlist Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="playlist-tab">
				    <div class="tab-container fwd">
					    <div class="tab-title">Created Playlist</div>
						<div class="dropdown video-login-popup video-login-popup2">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
						  <ul class="dropdown-menu">
							<li><a href="#">Most popular</a></li>
							<li><a href="#">Date added (oldest)</a></li>
							<li><a href="#">Date added (newest)</a></li>
						  </ul>
						</div>
					  <p>This channel has no playlists.</p>
					</div>
				  </div>
				  
				  <!-- Start Channels Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="channels-tab">
				    <div class="tab-container fwd">
					  <p>This channel doesn't feature any other channels.</p>
					</div>
				  </div>
				  
				  <!-- Start Discussion Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="discussion-tab">
				    <div class="tab-container fwd">
					  <div class="containt-block">
					  <div class="col-left fwd">
						<span>2 Comments</span>
						<span class="dropdown video-login-popup video-login-popup2">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-sort"></i> SORT BY</a>
						  <ul class="dropdown-menu">
							<li><a href="#">Top Comments</a></li>
							<li><a href="#">Newest First</a></li>
						  </ul>
						</span>
					  </div>
					  <div class="col-left space-left col-3-full">
						<span class="video-user-icon"><i class="fas fa-user"></i></span>
						<form class="form-horizontal">
						  <textarea class="video-textareabox" placeholder="Add a public comment..." rows="2"></textarea>
						  <button type="submit" class="video-submitbtn">Cancel</button>
						  <button type="submit" class="video-submitbtn">Comment</button>
						</form>    
					  </div>
					  <div class="col-left space-left user-comment-col">
						<span class="video-user-icon2"><i class="fas fa-user"></i></span>
						<span class="title-05 fwd">Vikas2222</span>
						<span class="title-06 fwd">Thank you for the explanations.</span>
						<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
						<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
					  </div>
					  <div class="col-left space-left user-comment-col">
						<span class="video-user-icon2"><i class="fas fa-user"></i></span>
						<span class="title-05 fwd">Pradeepkumar99</span>
						<span class="title-06 fwd">Lorem ipsum, or lipsum as it is sometimes known, is dummy text used in laying out print, graphic or web designs</span>
						<span class="user-likes-video"><i class="far fa-thumbs-up"></i> 206</span>
						<span class="user-likes-video"><i class="far fa-thumbs-down"></i> 10</span>
					  </div>
				      </div>
					</div>
				  </div>
				  
				  <!-- Start About Tab -->
				  <div role="tabpanel" class="tab-pane fade" id="about-tab">
				    <div class="tab-container fwd">
					  <div class="left-content">
					    <div class="tab-title">Description</div>
					    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
					  </div>
					  <div class="right-content">
					    <div class="tab-title">Stats</div>
						<span class="desc-col">Joined 29 May 2020</span>
						<span class="desc-col">2 views</span>
					  </div>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
    </div>
  </body>
</html>