<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
		<div class="main-wrapper">
		  <section class="video-detail-page">
			<div class="row">
			  <div class="container-fluid large-devise-screen">
				<div class="my-channel-section-01 guest-profile-section-01 video-upload-section-01">
				  <div class="main-title myvws-section-01">
					<h2 class="headding-01">Upload Video</h2>
				  </div>
				  <div class="login-form-block">
					<form>
					  <div class="form-group half-width">
					    <input type="file" id="real-file" hidden="hidden" />
					    <button type="button" id="upload-video-btn" class="cust-channel-btn">Upload Video</button>
					    <span id="upload-video-text">No file chosen, yet.</span>
					  </div>
					  <div class="form-group half-width">
					    <div class="upload-img-col">
						  <img src="images/video-img/img-01.jpg" alt=""/>
						</div>
					  </div>
					  <br>
					  <div class="clrfix"></div>
					  <br>
					  <div class="form-group half-width">
					    <label>Video Name</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Title</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Category</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Sub Category</label>
						<input type="text" class="input-textbox" id="">
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Shrot Description</label>
						<textarea class="input-textarea" rows="3"></textarea>
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Large Description</label>
						<textarea class="input-textarea" rows="3"></textarea>
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group full-width-col">
					    <label>Specification Description</label>
						<textarea class="input-textarea" rows="3"></textarea>
						<div class="erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Playlists</label>
						<select class="input-textbox input-selectbox">
						  <option>Select Option</option>
						  <option>1</option>
						  <option>2</option>
						</select>
						<div class="erroemsg" style="display:none;">Please select playlists</div>
					  </div>
					  <div class="form-group half-width">
					    <label>Video Audience</label>
						<select class="input-textbox input-selectbox">
						  <option>Yes, it's Made for Kids.</option>
						  <option>No, it's not Made for Kids</option>
						</select>
						<div class="erroemsg" style="display:none;">Please select audience</div>
					  </div>
					  <div class="form-group full-width-col">
					    <label>Video Visibility</label>
						<select class="input-textbox input-selectbox">
						  <option>Public</option>
						  <option>Private</option>
						  <option>Unlist</option>
						</select>
						<div class="erroemsg" style="display:none;">Please select visibility</div>
					  </div>
					  <div class="form-group full-width-col">
					    <button type="submit" class="input-submitbtn">Sign in</button>
					    <button type="submit" class="input-submitbtn">Reset</button>
					    <div class="sucessmsg" style="display:none;">Sucessfully login</div>
					  </div>				  
					</form>
				  </div>
				</div>
			  </div>
			</div>
		  </section>
		  <div class="clrfix"></div>			 
		</div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
		<!-- Add Class Active Page  -->
		<script>
			(function($) {
				$(window).load(function() {
					$(".slide-nav ul li.video-active").addClass('active-li');
				});
			})(jQuery);
		</script>
	  <!-- End Footer -->
    </div>
  </body>
</html>