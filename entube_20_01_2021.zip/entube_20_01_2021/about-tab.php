<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>EnTube - Indian Video Social Media Company Improve-Express-Share</title>
	
	<?Php include_once('head_inner.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
			  <?Php include_once('my-channel.php') ?>
				
			   <!-- Tab panes -->
				<div class="tab-content">
				
				  <!-- Start About Tab -->
				  <div role="tabpanel" class="">
				    <div class="tab-container fwd">
					  <div class="left-content">
					    <div class="tab-title">Description</div>
					    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
					  </div>
					  <div class="right-content">
					    <div class="tab-title">Stats</div>
						<span class="desc-col">Joined 29 May 2020</span>
						<span class="desc-col">2 views</span>
					  </div>
					</div>
				  </div>
				  
				</div>
			  </div>
			  </div>
		    </div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	  
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	    <?Php include_once('scripts_inner.php') ?>
	  <!-- End Footer -->
    </div>
  </body>
</html>