<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">

		<!-- Package Material Section -->
		<section class="order-status-section-01 package-material-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">Order <span>Package Material</span></h1>
			<form class="form-block">
			<div class="package-material-container form-content-block">
			  <h3 class="headding-02">Note - Minimum Packing Material order to be placed - 100 pcs of Courier Bags and 12 pcs of Cello Tape.</h3>
			  <div class="form-block tbl-responsive">
			    <table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
				  <thead>
					<tr>
						<th>Product Name</th>
						<th>Quanity</th>
						<th>Price Per Unit</th>
						<th>Total Price</th>
						<th>Cancel</th>
					</tr>
				  </thead>
				  <tbody>
					<tr>
						<td>
						  <div class="form-group">
							<select class="textbox input-selectbox">
							  <option>Select the material</option>
							  <option>Oxiinc Printed Cello Tape - (24 mm * 65 mtr) Small Per pc</option>
							  <option>Oxiinc Printed Cello Tape - (48 mm * 65 mtr) Big Per pc</option>
							  <option>Oxiinc Courier Bag size - (20 inch * 24 inch) Per pc</option>
							  <option>Oxiinc Courier Bag size - (14 inch * 17 inch) Per pc</option>
							  <option>Oxiinc Courier Bag size - (12 inch * 16 inch) Per pc</option>
							  <option>Oxiinc Courier Bag size - (15 inch * 19 inch) Per pc</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <div class="form-group">
							<input type="number" class="textbox" id="InputAccountHolderName">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <div class="form-group">
							<input type="text" class="textbox" id="InputAccountHolderName" readonly="">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <div class="form-group">
							<input type="text" class="textbox" id="InputAccountHolderName" readonly="">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <button type="button" class="submit-btn delete-icon-btn"><i class="fa fa-trash" aria-hidden="true"></i></button>
						</td>
					</tr>
					<tr>
						<td>
						  <div class="form-group">
							<select class="textbox input-selectbox">
							  <option>Select the material</option>
							  <option>Oxiinc Printed Cello Tape - (24 mm * 65 mtr) Small Per pc</option>
							  <option>Oxiinc Printed Cello Tape - (48 mm * 65 mtr) Big Per pc</option>
							  <option>Oxiinc Courier Bag size - (20 inch * 24 inch) Per pc</option>
							  <option>Oxiinc Courier Bag size - (14 inch * 17 inch) Per pc</option>
							  <option>Oxiinc Courier Bag size - (12 inch * 16 inch) Per pc</option>
							  <option>Oxiinc Courier Bag size - (15 inch * 19 inch) Per pc</option>
							</select>
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <div class="form-group">
							<input type="number" class="textbox" id="InputAccountHolderName">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <div class="form-group">
							<input type="text" class="textbox" id="InputAccountHolderName" readonly="">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <div class="form-group">
							<input type="text" class="textbox" id="InputAccountHolderName" readonly="">
							<span class="bar"></span>
							<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
						  </div>
						</td>
						<td>
						  <button type="button" class="submit-btn delete-icon-btn"><i class="fa fa-trash" aria-hidden="true"></i></button>
						</td>
					</tr>
				  </tbody>
				  <tfoot>
					<tr>
					  <th colspan="5">
					    <div class="form-group">
					      <button type="button" class="submit-btn"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button>
						</div>
					  </th>
					</tr>
				  </tfoot>
			    </table>
			  </div>
			</div>
			
			
			<div class="package-material-container form-content-block">
			  <h3 class="headding-02">Digital Bank Details</h3>
			  <div class="tbl-responsive">
			    <table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
				  <thead>
					<tr>
						<th>Name</th>
						<th>Bank Name</th>
						<th>Account No</th>
						<th>IFSC Code</th>
						<th>Address</th>
					</tr>
				  </thead>
				  <tbody>
					<tr>
						<td>EROCKETMALL ONLINE ASIA LIMITED</td>
						<td>HDFC BANK LTD</td>
						<td>50200038864387</td>
						<td>HDFC0009358</td>
						<td>HDFC BANK LTD, GROUND FLOOR OPUS CENTER 47 MIDC, OPP TUNGA HOTEL, ANDHERI EAST MUMBAI MAHARASHTRA 400093.</td>
					</tr>
					<tr>
						<td>EROCKETMALL ONLINE ASIA LIMITED</td>
						<td>HDFC BANK LTD</td>
						<td>50200038864387</td>
						<td>HDFC0009358</td>
						<td>HDFC BANK LTD, GROUND FLOOR OPUS CENTER 47 MIDC, OPP TUNGA HOTEL, ANDHERI EAST MUMBAI MAHARASHTRA 400093.</td>
					</tr>
				  </tbody>
			    </table>
			  </div>
			</div>
			
			
			<div class="package-material-container form-content-block">
			  <div class="form-block half-width fleft">
				  <div class="form-group">
				    <label for="InputDisplayName">Payment Mode</label>
				    <select class="textbox input-selectbox">
					  <option>NEFT</option>
					  <option>RTGS</option>
					  <option>IMPS</option>
					  <option>UPI</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Amount</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">Remark</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Branch Deposit Bank</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-block half-width frite">
			      <div class="form-group">
				    <label for="InputDisplayName">Payee Bank</label>
				    <select class="textbox input-selectbox">
					  <option>HDFC Bank</option>
					  <option>ICIC Bank</option>
					  <option>AXIS Bank</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Bank Statement Images</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Transcation Number</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
				    <label for="InputAccountHolderName">Payment Deposit Date</label>
					<div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
						<input class="textbox" type="text" readonly />
						<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					</div> 
					<div class="input-erroemsg" style="display:none;">Please select Date</div>
				  </div>
			  </div>
			  <div class="text-center">
			    <button type="submit" class="submit-btn">Send</button>
			  </div>
			</div>
			</form>
		  </div>
		</section>
		<div class="clrfix"></div>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>