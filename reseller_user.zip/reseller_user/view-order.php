<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	   
		<!-- Order Status Section-01 Start -->
		<section class="order-status-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">Order <span>Details View</span></h1>
			<div class="container">
			   <div class="form-content-block order-view-col">
				  <form>
					 <div class="form-group">
						<span class="text-item-left">Product Image :</span>
						<span class="text-item-right">
						   <img src="https://www.oxiinc.in/uploads/Multiple_Picture/939786637.png" width="150px" class="product-img">
						</span>
					 </div>
					 <div class="form-group">
					    <span class="text-item-left">Product Name :</span>
						<span class="text-item-right">BJORK MENS PRINTED BLACK SHIRT</span>
					 </div>
					 <div class="form-group">
						<span class="text-item-left">Customer Name :</span>
						<span class="text-item-right">G</span>
					 </div>
					 <div class="form-group">
						<span class="text-item-left">Customer Contact :</span>
						<span class="text-item-right">07774991416</span>
					 </div>
					 <div class="form-group">
						<span class="text-item-left">Qty :</span>
						<span class="text-item-right">1</span>
					 </div>
					 <div class="form-group">
						<span class="text-item-left">Size :</span>
						<span class="text-item-right">M</span>
					 </div>
					 <div class="form-group">
						<span class="text-item-left">Purchased On :</span>
						<span class="text-item-right">2020-10-03 12:57:56</span>
					 </div>
					 <div class="form-group">
						<span class="text-item-left">Status :</span>
						<span class="text-item-right">Order Reject</span>
					</div>
					 <div class="form-group">
						<span class="text-item-left">Transaction Id :</span>
						<span class="text-item-right">a8e3bf2d3014672d3623</span>
					 </div>
					 <div class="form-group text-center">
						<a href="https://www.oxiinc.in/Oxiinc_Reseller_Dashboard/order_invoice/2498/1" target="_blank"><button type="button" class="btn-style-01">Print Invoice</button></a>
					 </div>
					 <div class="clrfix"></div>
				  </form>
			   </div>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
	  
    </div>
  </body>
</html>