$(document).ready(function($){
	
	
//-- Main Wrapper Height	
	var contentheight = $(window).height() - $("header").height() - $("footer").height() + "px";
	$(".main-wrapper").css("min-height", contentheight);
	
	


//-- Go to Top Scroll
	var offset = 500,
		offset_opacity = 1200,
		scroll_top_duration = 700,
		$back_to_top = $('.cd-top');

	$(window).scroll(function(){
		( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
		if( $(this).scrollTop() > offset_opacity ) { 
			$back_to_top.addClass('cd-fade-out');
		}
	});

	$back_to_top.on('click', function(event){
		event.preventDefault();
		$('body,html').animate({
			scrollTop: 0 ,
			}, scroll_top_duration
		);
	});
	

//-- Anchor Scroll
$('.user-info-section-01 a').click(function(){
    $('html, body').animate({
        scrollTop: $( $(this).attr('href') ).offset().top
    }, 500);
    return false;
});
	



	

//-- Equal Height Col	
	equalheight = function(container){
		
		var currentTallest = 0,
		currentRowStart = 0,
		rowDivs = new Array(),
		$el,
		topPosition = 0;
		$(container).each(function() {
			
			$el = $(this);
			$($el).height('auto')
			topPostion = $el.position().top;
			
			if (currentRowStart != topPostion) {
				for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
					rowDivs[currentDiv].height(currentTallest);
				}
				rowDivs.length = 0; // empty the array
				currentRowStart = topPostion;
				currentTallest = $el.height();
				rowDivs.push($el);
				} else {
				rowDivs.push($el);
				currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
			}
			for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
				rowDivs[currentDiv].height(currentTallest);
			}
		});
	}
	
	$(window).load(function() {
		equalheight('.equal-height-col');
	});
	
	$(window).resize(function(){
		equalheight('.equal-height-col');
	});		
	
	
});


//---- File Upload Button
	const realFileBtn = document.getElementById("real-file");
	const customBtn = document.getElementById("upload-video-btn");
	const customTxt = document.getElementById("upload-video-text");

	customBtn.addEventListener("click", function() {
	  realFileBtn.click();
	});

	realFileBtn.addEventListener("change", function() {
	  if (realFileBtn.value) {
		customTxt.innerHTML = realFileBtn.value.match(
		  /[\/\\]([\w\d\s\.\-\(\)]+)$/
		)[1];
	  } else {
		customTxt.innerHTML = "No file chosen, yet.";
	  }
	});	



