<header>   
	<a href="index.php" class="logo-col"><img src="images/oxiinc-logo.png" alt=""/></a>
	<nav id='cssmenu' class="fwd">
	  <div id="head-mobile"></div>
	  <div class="button"></div>
	  <ul class="nav-main-ul">
		<li class='active'><a href='#'>Home</a></li>
		<li><a href='#'>Listings</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Inventory</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Orders</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Payments</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Growth</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Reports</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Bank Deposit Statement</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
		<li><a href='#'>Oxiinc Packing Material</a>
		   <ul>
			  <li><a href='#'>Option-1</a></li>
			  <li><a href='#'>Option-2</a></li>
			  <li><a href='#'>Option-3</a></li>
		   </ul>
		</li>
	  </ul>
	</nav>
	
	
	
			<div class="navbar navbar-default">
			    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				  <span class="sr-only">Toggle navigation</span>
				  <i class="fa fa-ellipsis-v fa-w-6"></i>
				</button>
			
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				  <ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/admin-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
					    <li>
						  <div class="login-user-detail">
						    <div class="login-user-img"></div>
						    <div class="login-user-info">
						      <span>Oxiinc Alam</span>
							  <span>username@gmail.com</span>
						    </div>
						  </div>
						  <div class="clrfix"></div>
						</li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-fw fa-user-circle"></i> Wallet <span class="wallet-amount">3,005</span></a></li>
						<li><a href="#" data-toggle="modal" data-target="#ProfileModal"><i class="fas fa-fw fa-user-circle"></i> Profile</a></li>
						<li><a href="#"><i class="fas fa-fw fa-user-circle"></i> Company Detail</a></li>
						<li><a href="#" data-toggle="modal" data-target="#BankDetailsModal"><i class="fas fa-fw fa-user-circle"></i> Bank Details</a></li>
						<li><a href="#" data-toggle="modal" data-target="#CancelledChequeModal"><i class="fas fa-fw fa-user-circle"></i> Cancelled Cheque</a></li>
						<li><a href="#"><i class="fas fa-fw fa-user-circle"></i> Billing</a></li>
						<li><a href="#"><i class="fas fa-fw fa-user-circle"></i> Director/Owner Derails</a></li>
						<li><a href="#"><i class="fas fa-fw fa-user-circle"></i> Guest</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-fw fa-user-circle"></i> Log out</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/bell-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
						<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-fw fa-star "></i> Somthing else here</a></li>
					  </ul>
					</li>
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><img src="images/grid-icon.png" alt=""/></a>
					  <ul class="dropdown-menu">
						<li><a href="#"><i class="fas fa-fw fa-edit"></i> Action</a></li>
						<li><a href="#"><i class="fas fa-fw fa-headphones-alt "></i> Another Action</a></li>
						<li role="separator" class="divider"></li>
						<li><a href="#"><i class="fas fa-fw fa-star "></i> Somthing else here</a></li>
					  </ul>
					</li>
				  </ul>
				</div>
			</div>
	
	
	
	
</header>
<div class="clrfix"></div>
