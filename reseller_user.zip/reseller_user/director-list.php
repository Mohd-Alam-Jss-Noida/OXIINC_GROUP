<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">

		<!-- Package Material Section -->
		<section class="order-status-section-01 package-material-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">Directors <span>List Table</span></h1>
			<form class="form-block">
			<div class="package-material-container form-content-block">
			  <div class="tbl-responsive">
			    <table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
				  <thead>
					<tr>
						<th>Sr No.</th>
						<th>Director Name</th>
						<th>Email</th>
						<th>Contact Number</th>
						<th>View Details</th>
					</tr>
				  </thead>
				  <tbody>
					<tr>
						<td>1</td>
						<td>vffd</td>
						<td>cvsd@gmail.com</td>
						<td>4545641455</td>
						<td><button type="button" class="status-done">View Details</button></td>
					</tr>
					<tr>
						<td>2</td>
						<td>vffd</td>
						<td>cvsd@gmail.com</td>
						<td>4545641455</td>
						<td><button type="button" class="status-done">View Details</button></td>
					</tr>
				  </tbody>
			    </table>
			  </div>
			</div>
			</form>
		  </div>
		</section>
		<div class="clrfix"></div>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>