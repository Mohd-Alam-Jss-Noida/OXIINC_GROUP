<div class="clrfix"></div>
<footer>
  <div class="foot-block-01 fwd">
  <div class="container">
    <div class="foot-links-col col-1 equal-height-col">
	  <h3>Services</h3>
	  <ul class="list-unstyled">
	    <li><a href="#">Fulfilment Services</a></li>
		<li><a href="#">Account Managemant</a></li>
		<li><a href="#">Partner Services</a></li>
		<li><a href="#">Packaging Services</a></li>
	  </ul>
	</div>
	<div class="foot-links-col col-2 equal-height-col">
	  <h3>Resources</h3>
	  <ul class="list-unstyled">
	    <li><a href="#">Online Selling Guide</a></li>
		<li><a href="#">Products In Demand</a></li>
		<li><a href="#">Success Stories</a></li>
		<li><a href="#">Seller Learning Center</a></li>
		<li><a href="#">News</a></li>
		<li><a href="#">API Documentation</a></li>
	  </ul>
	</div>
	<div class="foot-links-col col-3 equal-height-col">
	  <h3>FAQs</h3>
	  <ul class="list-unstyled">
	    <li><a href="#">Getting Started</a></li>
		<li><a href="#">Pricing And Payments</a></li>
		<li><a href="#">Listing And Catalog</a></li>
		<li><a href="#">Order Management And Shipping</a></li>
	  </ul>
	</div>
	<div class="foot-links-col col-4 equal-height-col">
	  <h3>Contact Us</h3>
	  <ul class="list-unstyled">
	    <li><a href="#">sell@oxiinc.in</a></li>
	  </ul>
	</div>
  </div>
  </div>
  
  <div class="foot-block-02 fwd">
    <div class="container">
	  © 2020. All Rights Reserved. Design by OXIINCGROUP.COM
	  <ul class="list-inline foot-social-media">
	    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
		<li><a href="#"><i class="fab fa-twitter"></i></a></li>
		<li><a href="#"><i class="fab fa-youtube"></i></a></li>
		<li><a href="#"><i class="fab fa-instagram"></i></a></li>
		<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
	  </ul>
	</div>
  </div>
</footer>
<div class="clrfix"></div>


<!-- Profile Modal -->
<div class="modal fade modal-block" id="ProfileModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <div class="modal-body">
		<form class="form-block">
		  <div class="form-block">
		      <h2 class="headding-01">Profile</h2>
			  <div class="form-group">
				<label for="InputFullName">Full Name</label>
				<input type="text" class="textbox" id="InputFullName" value="Pankaj Chalke">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group">
				<label for="InputEmail">E-mail</label>
				<input type="text" class="textbox" id="InputEmail" value="pankaj.chalke@oxiincgroup.com" readonly="">
			  </div>
			  <div class="form-group">
				<label for="InputMobileNumber">Mobile Number</label>
				<input type="text" class="textbox" id="InputMobileNumber" value="8390879096" readonly="">
			  </div>
			  <div class="form-group">
				<label for="InputStoreName">Store Name</label>
				<input type="text" class="textbox" id="InputStoreName" value="11">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>	
			  <div class="form-group">
				<label for="InputStoreInformation">Store Information</label>
				<textarea class="textbox textarea" rows="3"></textarea>
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>	
		  </div>
		  <div class="form-group text-center">
			<button type="submit" class="submit-btn">Save</button>
		  </div>
		</form>
		<div class="clrfix"></div>
      </div>
    </div>
  </div>
</div>


<!-- Bank Details Modal -->
<div class="modal fade modal-block" id="BankDetailsModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <div class="modal-body">
		<form class="form-block">
		  <div class="form-block">
		      <h2 class="headding-01">Bank Details</h2>
			  <div class="form-group">
				<label for="">Account Holder's Name</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group">
				<label for="InputEmail">Bank Account Number</label>
				<input type="text" class="textbox" id="InputEmail">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group">
				<label for="InputIFSC">Enter Your IFSC</label>
				<input type="text" class="textbox ifsc-feild" id="InputIFSC">
				<button type="submit" class="submit-btn IFSC-code-btn">Check IFSC</button>
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
		  </div>
		  <div class="form-group text-center">
			<button type="submit" class="submit-btn">Save</button>
		  </div>
		</form>
		<div class="clrfix"></div>
      </div>
    </div>
  </div>
</div>


<!-- Cancelled Cheque Modal -->
<div class="modal fade modal-block" id="CancelledChequeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <div class="modal-body">
		<form class="form-block">
		  <h2 class="headding-01">Cancelled Cheque</h2>
		  <p class="title-col">Please read the instructions and upload your document by clicking below:</p>
		  <div class="form-group">
			<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
			<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
			<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
			<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
		  </div>
		  <div class="form-group">
			<p class="title-col">Upload Instructions</p>
			<p>
			1.  Make sure that the document is visibly large and on a white background <br>
			2.  Allowed files png, jpg etc. <br>
			3.  Maximum img size should not exceed 100KB. <br> &nbsp;
			</p>
		  </div>
		  <div class="form-group no-margin">
			<p class="title-col">Example: <img src="images/cancelled-cheque-eg.jpg" alt="" class="eg-img-col"/></p>
		  </div>
	    </form>
		<div class="clrfix"></div>
      </div>
    </div>
  </div>
</div>


<!-- jQuery -->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Fontawesome -->
<script defer src="js/fontawesome/all.js"></script>
<script defer src="js/fontawesome/brands.js"></script>
<script defer src="js/fontawesome/solid.js"></script>
<script defer src="js/fontawesome/fontawesome.js"></script>
<script defer src="js/menu.js"></script>
<!-- Data Table -->
<script defer src="js/datatable/jquery.dataTables.min.js"></script>
<script defer src="js/datatable/dataTables.bootstrap4.min.js"></script>
<script defer src="js/datatable/dataTables.buttons.min.js"></script>
<script defer src="js/datatable/buttons.bootstrap4.min.js"></script>
<script defer src="js/datatable/jszip.min.js"></script>
<script defer src="js/datatable/pdfmake.min.js"></script>
<script defer src="js/datatable/vfs_fonts.js"></script>
<script defer src="js/datatable/buttons.html5.min.js"></script>
<script defer src="js/datatable/buttons.print.min.js"></script>
<script defer src="js/datatable/buttons.colVis.min.js"></script>
<script defer src="js/datatable/dataTables.responsive.min.js"></script>
<script defer src="js/datatable/responsive.bootstrap4.min.js"></script>
<!-- Datepicker -->
<script src="js/datepicker.js"></script>

 
<script src="js/custom-script.js"></script>

<!-- Data Table Script --> 
	<script>
		$(document).ready(function() {
			var table = $('#example').DataTable( {
				lengthChange: false,
				buttons: [ 'copy', 'excel', 'csv', 'pdf', 'print' ]
			} );
		 
			table.buttons().container()
				.appendTo( '#example_wrapper .col-md-6:eq(0)' );
		} );
    </script>
	
<!-- Datepicker Script --> 
	<script>
		$(function () {
		  $("#datepicker").datepicker({ 
				autoclose: true, 
				todayHighlight: true
		  }).datepicker('update', new Date());
		});
	</script>

