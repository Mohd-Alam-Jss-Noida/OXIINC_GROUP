<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">

		<!-- Company Details Section -->
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <h1 class="mainpage-headding">Bank Deposit <span>Statement</span></h1>
			
			<div class="package-material-container bank-statement-container form-content-block">
				<h3 class="headding-02">Digital Bank Details</h3>
				<div class="tbl-responsive">
					<table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
						<thead>
							<tr>
								<th>Name</th>
								<th>Bank Name</th>
								<th>Account No</th>
								<th>IFSC Code</th>
								<th>Address</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>EROCKETMALL ONLINE ASIA LIMITED</td>
								<td>HDFC BANK LTD</td>
								<td>50200038864387</td>
								<td>HDFC0009358</td>
								<td>HDFC BANK LTD, GROUND FLOOR OPUS CENTER 47 MIDC, OPP TUNGA HOTEL, ANDHERI EAST MUMBAI MAHARASHTRA 400093.</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div class="form-content-block">
			<form class="form-block">
			  <div class="form-block half-width fleft">
				  <div class="form-group">
				    <label for="InputDisplayName">Payment Mode</label>
				    <select class="textbox input-selectbox">
					  <option>NEFT</option>
					  <option>RTGS</option>
					  <option>IMPS</option>
					  <option>UPI</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Amount</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">Remark</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Branch Deposit Bank</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Payment Deposit Time</label>
					<input type="time" class="textbox" id="InputAccountHolderName" value="13:06:53">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-block half-width frite">
			      <div class="form-group">
				    <label for="InputDisplayName">Payee Bank</label>
				    <select class="textbox input-selectbox">
					  <option>HDFC Bank</option>
					  <option>ICIC Bank</option>
					  <option>AXIS Bank</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Images</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Transcation Number</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
				    <label for="InputAccountHolderName">Payment Deposit Date</label>
					<div id="datepicker" class="input-group date" data-date-format="mm-dd-yyyy">
						<input class="textbox" type="text" readonly />
						<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
					</div> 
					<div class="input-erroemsg" style="display:none;">Please select Date</div>
				  </div>
				  <div class="form-group">
				    <label for="InputDisplayName">Package</label>
				    <select class="textbox input-selectbox">
					  <option>Silver</option>
					  <option>Gold</option>
					  <option>Diamond</option>
					  <option>Reseller Club</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-group text-center">
			    <button type="submit" class="submit-btn">Send</button>
			  </div>
			</form>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>