<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">

		<!-- Company Details Section -->
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <h1 class="mainpage-headding">Company <span>Details</span></h1>
			<div class="form-content-block">
			<form class="form-block">
			  <div class="form-block half-width fleft">
				  <div class="form-group">
					<label for="InputAccountHolderName">Company Name</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				   <div class="form-group">
					<label for="InputAccountNumber">CIN No.</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">GST No.</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">PAN No.</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">Address</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">City</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">State</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Telephone Number</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Company Website</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-block half-width frite">
			      <div class="form-group">
					<label for="InputAccountHolderName">Company Email</label>
					<input type="email" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">CIN Certiticate</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">GST Certificate</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">PAN Card</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="pan-card-img">
					  <a href="https://www.oxiinc.in/reseller_files/reseller_documents/720422988.png" target="_blank">
					  <img src="https://www.oxiinc.in/reseller_files/reseller_documents/720422988.png" alt=""/></a>
					</div>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">District</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Pincode</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Mobile Number</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-group text-center">
			    <button type="submit" class="submit-btn">Update</button>
			  </div>
			</form>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>