<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
		<!-- User-info-section-01 Start -->
		<section class="user-info-section-01 fwd">
		  <div class="container-fluid">
		    <h3>You are almost ready to start selling!</h3>
		    <div class="update-info-col">
			  <div class="update-info-content">
			    <h4>Store Details</h4>
			    <h5>Not Provided</h5>
			    <a class="update-btn" href="#UpdateStoreDetails">Update Now</a>
			  </div>
			</div>
			
			<div class="update-info-col">
			  <div class="update-info-content">
			    <h4>Signature</h4>
			    <h5>Not Provided</h5>
			    <a class="update-btn" href="#UpdateSignature">Update Now</a>
			  </div>
			</div>
			
			<div class="update-info-col">
			  <div class="update-info-content">
			    <h4>Cancelled Cheque</h4>
			    <h5>Not Provided</h5>
			    <a class="update-btn" href="#UpdateCancelledCheque">Update Now</a>
			  </div>
			</div>
			
			<div class="update-info-col">
			  <div class="update-info-content">
			    <h4>Bank Details</h4>
			    <h5>Not Provided</h5>
			    <a class="update-btn" href="#UpdateBankDetails">Update Now</a>
			  </div>
			</div>
			
			<div class="update-info-col">
			  <div class="update-info-content">
			    <h4>Company Details</h4>
			    <h5>Not Provided</h5>
			    <a class="update-btn" href="#UpdateCompanyDetails">Update Now</a>
			  </div>
			</div>
			
			<div class="update-info-col">
			  <div class="update-info-content">
			    <h4>Director / Owner Details</h4>
			    <h5>Not Provided</h5>
			    <a class="update-btn" href="#UpdateDirectorDetails">Update Now</a>
			  </div>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Store Details Section -->
		<a name="UpdateStoreDetails" id="UpdateStoreDetails" class="section-slide"></a>
		<div class="container">
		  <div class="form-sucessmsg" style="display:none;">Sucessfully updated</div>
		</div>
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <h2 class="headding-01">Store Details</h2>
			<div class="form-content-block">
			  <form class="form-block half-width">
			      <p class="title-col">Your store details will be displayed to the buyers when they browse your products:</p>
				  <div class="form-group">
					<label for="InputDisplayName">Enter Your Display Name</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
				    <label for="InputDisplayName">Enter Your Display Name</label>
				    <select class="textbox input-selectbox">
					  <option>1</option>
					  <option>2</option>
					  <option>3</option>
					  <option>4</option>
					  <option>5</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputStoreLoaction">Enter Your Store Location</label>
					<textarea class="textbox textarea" rows="3"></textarea>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
					<div class="input-successmsg" style="display:none;">Sucessfully updated</div>
				  </div>
				  <button type="submit" class="submit-btn">Save</button>
				  <div class="form-errormsg" style="display:none;">Please enter valid text</div>
			  </form>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		
		<a name="UpdateSignature" id="UpdateSignature" class="section-slide"></a>
		<a name="UpdateCancelledCheque" id="UpdateCancelledCheque" class="section-slide"></a>
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <!-- Signature  Section -->
		    <div class="half-width-col fleft equal-height-col">
		        <h2 class="headding-01">Signature</h2>
				<div class="form-content-block">
				  <form class="form-block">
					  <p class="title-col">Please read the instructions and upload your document by clicking below:</p>
					  <div class="form-group">
						<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					    <button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
					    <span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
						<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group">
						<p class="title-col">Upload Instructions</p>
						<p>
						1.  Make sure that the document is visibly large and on a white background <br>
						2.  Allowed files png, jpg etc. <br>
						3.  Maximum img size should not exceed 20MB <br>
						4.  Seal on the signature not a requirement.
						</p>
					  </div>
					  <div class="form-group no-margin">
					    <p class="title-col">Example: <img src="images/signature-eg.jpg" alt="" class="eg-img-col"/></p>
					  </div>
				  </form>
				</div>
			</div>
			
			<!-- Cancelled Cheque Section -->
			<div class="half-width-col frite equal-height-col xs-margin-01 full-width-col">
		        <h2 class="headding-01">Cancelled Cheque</h2>
				<div class="form-content-block">
				  <form class="form-block">
					  <p class="title-col">Please read the instructions and upload your document by clicking below:</p>
					  <div class="form-group">
						<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					    <button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
					    <span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
						<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
					  </div>
					  <div class="form-group">
						<p class="title-col">Upload Instructions</p>
						<p>
						1.  Make sure that the document is visibly large and on a white background <br>
						2.  Allowed files png, jpg etc. <br>
						3.  Maximum img size should not exceed 100KB. <br> &nbsp;
						</p>
					  </div>
					  <div class="form-group no-margin">
					    <p class="title-col">Example: <img src="images/cancelled-cheque-eg.jpg" alt="" class="eg-img-col"/></p>
					  </div>
				  </form>
				</div>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		
		<!-- Bank Details Section -->
		<a name="UpdateBankDetails" id="UpdateBankDetails" class="section-slide"></a>
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <h2 class="headding-01">Bank Details</h2>
			<div class="form-content-block">
			  <form class="form-block half-width fleft">
			      <p class="title-col">This is where we will make your payments :</p>
				  <div class="form-group">
					<label for="InputAccountHolderName">Enter Account Holder’s Name</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">Bank Account Number</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputIFSC">Enter Your IFSC</label>
					<input type="text" class="textbox ifsc-feild" id="InputIFSC">
					<button type="submit" class="submit-btn IFSC-code-btn">Check IFSC</button>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <button type="submit" class="submit-btn">Save</button>
			  </form>
			  <div class="form-block half-width frite xs-margin-01">
			    <p class="title-col">Don't have a bank account in the name of your business?</p>
				<p>We can only transfer payments to accounts which are in the registered business name. Please open a new bank account with any bank in your registered business name</p> <br>
				<p class="title-col">Don't have a verification document?</p>
				<p>You can get a cheque book, or the statement of your account from your bank. If neither of these are available, you can also ask the bank to issue a letter with your account number, IFSC code and name mentioned on it.</p>
			  </div>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Company Details Section -->
		<a name="UpdateCompanyDetails" id="UpdateCompanyDetails" class="section-slide"></a>
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <h2 class="headding-01">Company Details</h2>
			<div class="form-content-block">
			<form class="form-block">
			  <div class="form-block half-width fleft">
				  <div class="form-group">
					<label for="InputAccountHolderName">Company Type</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Company Email</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">CIN Number</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Shop Establishment Reg No</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">PAN No. <span class="mandatory-feild">*</span></label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">GST No.</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">City</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">State</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Telephone number</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputIFSC">Website</label>
					<input type="text" class="textbox ifsc-feild" id="InputIFSC">
					<button type="submit" class="submit-btn IFSC-code-btn">Add</button>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-block half-width frite">
			      <div class="form-group">
					<label for="InputAccountHolderName">Company Name <span class="mandatory-feild">*</span></label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">CIN Certiticate</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Shop Establishment Reg No License</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">PAN card Copy <span class="mandatory-feild">*</span></label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">GST Certificate</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Address</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">District</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Pincode</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Mobile Number</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
			  <div class="form-group text-center">
			    <button type="submit" class="submit-btn">Save</button>
			  </div>
			</form>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Director / Owner Details Section -->
		<a name="UpdateDirectorDetails" id="UpdateDirectorDetails" class="section-slide"></a>
		<section class="user-info-section-02 fwd">
		  <div class="container">
		    <h2 class="headding-01">Director / Owner Details</h2>
			<div class="form-content-block">
			<form class="form-block">
			  <div class="form-block half-width fleft">		 
				  <div class="form-group">
					<label for="InputAccountHolderName">Your Name</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountNumber">PAN No</label>
					<input type="text" class="textbox" id="InputAccountNumber">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Aadhar No</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Director Email</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group owners-details">
					<button type="submit" class="submit-btn IFSC-code-btn">Add</button>
					<button type="submit" class="submit-btn IFSC-code-btn">Remove</button>
				  </div>
			  </div>
			  <div class="form-block half-width frite">
			      <div class="form-group">
					<label for="InputAccountHolderName">Mobile No</label>
					<input type="text" class="textbox" id="InputAccountHolderName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Pan Card Photo</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputAccountHolderName">Aadhar Photo</label>
					<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
					<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
					<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>	
				  <div class="form-group">
					<label for="InputAccountHolderName">Director Address</label>
					<textarea class="textbox textarea" rows="3"></textarea>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>	
			  </div>
			  <div class="form-group text-center">
			    <button type="submit" class="submit-btn">Save</button>
			  </div>
			</form>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>