<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc group</title>
	<style>
		h3 {
			font-size:15px;
			color:#222;
			font-weight:600;
			text-align:center;
	    }
		h3 a {
			color:#222;
			text-decoration:none;
	    }
	</style>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	
	  <!-- Start Container -->
	  <div class="main-wrapper" style="padding-top:30px;">
		
		  <h3><a href="dashboard.php">Dashboard</a></h3>
		  <h3><a href="index.php">Details</a></h3>
		  <h3><a href="data-table.php">Order</a></h3>
		  <h3><a href="order-confirm.php">Order Confirm</a></h3>
		  <h3><a href="view-order.php">View Order</a></h3>
		  <h3><a href="product-list.php">Product List</a></h3>
		  <h3><a href="packing_material_bank_deposit_statement.php">Packing Material Bank Deposit statement</a></h3>
		  <h3><a href="product-listing.php">Product Listing</a></h3>
		  <h3><a href="bank_deposit_statement.php">Bank Deposit Statement</a></h3>
		  <h3><a href="wallet-balance.php">Wallet Balance</a></h3>
		  <h3><a href="company-detail.php">Company Detail</a></h3>
		  <h3><a href="director-list.php">Director List</a></h3>
		  <h3><a href="director-detail.php">Director Detail</a></h3>
		  
	  </div>
	  <!-- End Container -->

	  
    </div>
  </body>
</html>