<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">

		<!-- Package Material Section -->
		<section class="order-status-section-01 package-material-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">Product <span>Listing</span></h1>
			<form class="form-block">
			<div class="container">
			  <div class="form-content-block">
				  <div class="form-group col-3-div">
					<select class="textbox input-selectbox">
					  <option>Select Category</option>
					  <option>Electronics</option>
					  <option>Home Furnishing & Kitchen</option>
					  <option>Womens</option>
					  <option>Mens</option>
					  <option>Baby & Kids</option>
					  <option>Stationery & More</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group col-3-div">
					<select class="textbox input-selectbox">
					  <option>Select Subcategory</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group col-3-div">
					<select class="textbox input-selectbox">
					  <option>Select Subcategory</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			  </div>
		    </div>
			<div class="clrfix"></div>
			
			
			<div class="package-material-container form-content-block">
			  <div class="form-block tbl-responsive">
			    <table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
				  <!--<thead>
					<tr>
						<th width="285px;">Product Images</th>
						<th>Product name</th>
						<th>Product MRP</th>
						<th>Product Price</th>
						<th>Shipping Charges</th>
						<th>Product Color</th>
						<th>GST Percentage</th>
						<th>Action</th>
					</tr>
				  </thead>-->
				  <tbody>
				    <tr>
					  <td style="padding:0;">
					  <table class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
					    <tr>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">Product Images</label>
								<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
								<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload</button>
								<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">Product name</label>
								<input type="text" class="textbox textbox-tbl-xs" id="InputAccountHolderName" placeholder="Product name">
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">Product MRP</label>
								<input type="text" class="textbox textbox-tbl-xs" id="InputAccountHolderName" placeholder="Product MRP">
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">Product Price</label>
								<input type="text" class="textbox textbox-tbl-xs" id="InputAccountHolderName" placeholder="Product Price">
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">Shipping Charges</label>
								<input type="text" class="textbox textbox-tbl-xs" id="InputAccountHolderName" placeholder="Shipping Charges">
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">Product Color</label>
								<input type="text" class="textbox textbox-tbl-xs" id="InputAccountHolderName" placeholder="Product Color">
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <div class="form-group">
								<label for="InputAccountHolderName">GST Percentage</label>
								<select class="textbox input-selectbox">
								  <option>0%</option>
								  <option>5%</option>
								  <option>12%</option>
								  <option>18%</option>
								  <option>28%</option>
								</select>
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td>
							  <label for="InputAccountHolderName">&nbsp;</label>
							  <button type="button" class="submit-btn delete-icon-btn"><i class="fa fa-trash" aria-hidden="true"></i></button>
							</td>
						</tr>
						<tr>
							<td colspan="2">
							  <div class="form-group">
								<label for="InputAccountHolderName">Short Info</label>
								<textarea class="textbox textarea" rows="3" placeholder="Short Description"></textarea>
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td colspan="2">
							  <div class="form-group">
								<label for="InputAccountHolderName">Long Info</label>
								<textarea class="textbox textarea" rows="3" placeholder="Long Description"></textarea>
								<span class="bar"></span>
								<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
							  </div>
							</td>
							<td colspan="3" class="product-listing-size-wise-stock">
							  <div class="form-group">
								<label for="InputAccountHolderName">Product Size & Size Wise Stock</label>
							  </div>
							  
							  <div class="form-group">
								<button type="button" class="submit-btn cancel-btn add-btn no-margin"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button>
							  </div>
							  <div class="add-col-01">
								  <div class="form-group col-1">
									<input type="text" class="textbox" id="InputAccountHolderName" placeholder="Product Size">
									<span class="bar"></span>
									<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
								  </div>
								  <div class="form-group col-1">
									<input type="text" class="textbox" id="InputAccountHolderName" placeholder="Size Wise Stock">
									<span class="bar"></span>
									<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
								  </div>
								  <div class="form-group col-2">
									<button type="button" class="submit-btn delete-icon-btn"><i class="fa fa-trash" aria-hidden="true"></i></button>
								  </div>
							  </div>
							  
							  <div class="add-col-01">
								  <div class="form-group col-1">
									<input type="text" class="textbox" id="InputAccountHolderName" placeholder="Product Size">
									<span class="bar"></span>
									<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
								  </div>
								  <div class="form-group col-1">
									<input type="text" class="textbox" id="InputAccountHolderName" placeholder="Size Wise Stock">
									<span class="bar"></span>
									<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
								  </div>
								  <div class="form-group col-2">
									<button type="button" class="submit-btn delete-icon-btn"><i class="fa fa-trash" aria-hidden="true"></i></button>
								  </div>
							  </div>
							</td>
						</tr> 
					  </table>
					  </td>
					</tr>
				  </tbody>
				  <tfoot>
					<tr>
					  <th colspan="8">
					    <div class="form-group">
					      <button type="button" class="submit-btn cancel-btn"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp; Add&nbsp;</button>
						</div>
					  </th>
					</tr>
					<tr>
					  <th colspan="8">
					    <div class="form-group text-center">
					      <button type="button" class="submit-btn">&nbsp;Upload&nbsp;</button>
						</div>
					  </th>
					</tr>
				  </tfoot>
			    </table>
			  </div>
			</div>
			</form>
		  </div>
		</section>
		<div class="clrfix"></div>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>