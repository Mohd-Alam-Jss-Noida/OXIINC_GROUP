<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	    <!-- Dashboard Section-01 Start -->
		<section class="dashboard-section-01 fwd">
		  <div class="container-fluid">
			<div class="dashboard-panel-01">
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Useful Links</h3>
			    <ul class="list-unstyled links-col">
				  <li><a href="#"><i class="fas fa-chalkboard-teacher"></i> Reseller Learning Center</a></li>
				  <li><a href="#"><i class="fas fa-user-friends"></i> Star Reseller Community</a></li>
				  <li><a href="#"><i class="fas fa-user"></i> Manage Your Profile</a></li>
				</ul>
			  </div>
			</div>
			
			<div class="dashboard-panel-02">
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Seller Fulfilled Orders</h3>
			    <ul class="list-inline order-list">
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">0</div>
					  <div class="order-title">Total Orders</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">5</div>
					  <div class="order-title">Urgent</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">2</div>
					  <div class="order-title">Delivered</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">1</div>
					  <div class="order-title">Reattempts</div>
				    </a>
				  </li>
				</ul>
			  </div>
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Returns and SPF Claims</h3>
			    <ul class="list-inline order-list">
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">0</div>
					  <div class="order-title">Total Returns</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">5</div>
					  <div class="order-title">Completed</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">2</div>
					  <div class="order-title">Delivered</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">1</div>
					  <div class="order-title">Settled Value</div>
				    </a>
				  </li>
				</ul>
			  </div>
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Listings</h3>
			    <ul class="list-inline order-list">
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">0</div>
					  <div class="order-title">Active</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">2</div>
					  <div class="order-title">Inactive</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">2</div>
					  <div class="order-title">Out of Stock</div>
				    </a>
				  </li>
				  <li>
				    <a href="#" class="order-info-content">
					  <div class="order-number">1</div>
					  <div class="order-title">Low Stock</div>
				    </a>
				  </li>
				</ul>
			  </div>
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Growth opportunities</h3>
			    <div class="title-col">Price recommendations to grow your sales</div>
				<div class="price-col">0</div>
			  </div>
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Payments</h3>
			    <div class="title-col">Next Payment <br> <span>Due on Nov 17,2020</span></div>
				<div class="price-col">0</div>
				<hr class="hrline-01">
				<div class="title-col"><span>Prepaid</span></div>
				<div class="price-col">0</div>
				<div class="title-col"><span>Postpaid/TDS</span></div>
				<div class="price-col">0</div>
			  </div>
			</div>

			<div class="dashboard-panel-03">
			  <div class="dashboard-content-block">
			    <h3 class="headding-01">Recent Promotions</h3>
			    <img src="images/adv-banner01.jpg" class="adv-banner-img" alt=""/>
			  </div>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Dashboard Section-01 Start -->
		<!--<section class="dashboard-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">Reseller <span>Dashboard</span></h1>
			<h2 class="headding-01">Order</h2>
		    <div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c1">
			    <div class="order-title">Total Order</div>
				<div class="order-number">5</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c2">
			    <div class="order-title">Order Confirm</div>
				<div class="order-number">4</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c3"> 
			    <div class="order-title">Order Packed Confirm</div>
				<div class="order-number">0</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c1">
			    <div class="order-title">Order Shipped Confirm</div>
				<div class="order-number">0</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c2">
			    <div class="order-title">Order In Transit Confirm</div>
				<div class="order-number">0</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c3">
			    <div class="order-title">Order Delivered confrim</div>
				<div class="order-number">1</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c1">
			    <div class="order-title">Order Delivered</div>
				<div class="order-number">0</div>
			  </a>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>
		
		<section class="dashboard-section-01 dashboard-section-02 fwd">
		  <div class="container-fluid">
			<h2 class="headding-01">Product</h2>
		    <div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c4">
			    <div class="order-title">Pending</div>
				<div class="order-number">0</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c5">
			    <div class="order-title">Approved</div>
				<div class="order-number">1</div>
			  </a>
			</div>
			<div class="order-col equal-height-col">
			  <a href="#" class="order-info-content color-c6">
			    <div class="order-title">Reject</div>
				<div class="order-number">0</div>
			  </a>
			</div>
		  </div>
		</section>
		<div class="clrfix"></div>-->
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>