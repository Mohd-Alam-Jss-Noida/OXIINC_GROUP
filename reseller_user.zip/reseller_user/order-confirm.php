<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	   
		<!-- Order Status Section-01 Start -->
		<section class="order-status-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">Order <span>confirm</span></h1>
			<div class="container">
			  <div class="form-content-block">
			    <form class="form-block">
				  <div class="form-group">
					<label for="InputDisplayName">Product Name</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputDisplayName">Customer Name</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputDisplayName">Product Price</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputDisplayName">Transaction Id</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			    </form>
			  </div>
		    </div>
			

		   
	<div class="data-table-block form-content-block">   
	  <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Sr.No</th>
                <th>Image</th>
				<th>Product</th>
				<th>Customer name</th>
				<th>Qty</th>
				<th>Size</th>
				<th>Purchased On</th>
				<th>Transaction Id#</th>
				<th>Order Packed Confirmation</th>
				<th>Print Invoice</th>
				<th>View Details</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
				<td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/939786637.png" alt="BJORK MENS PRINTED BLACK SHIRT" style="width: 100px;height: 100px"/></td>
                <td>BJORK MENS PRINTED BLACK SHIRT</td>
				<td>G</td>
				<td>1</td>
				<td>M</td>
				<td>03-10-2020 12:57:56</td>
				<td>a8e3bf2d3014672d3623</td>
				<td><button type="button" class="status-done">Order Packed Pending</button></td>
				<td><button type="button" class="status-done">Print Invoice</button></td>
				<td><button type="button" class="status-done">View Details</button></td>
            </tr>
			<tr>
                <td>2</td>
				<td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1915943758__Mr_khan_Oxiinc_h1.jpg" alt="Oxiinc Flat Knits T-shirt OX-08" style="width: 100px;height: 100px"></td>
                <td>Oxiinc Flat Knits T-shirt OX-08</td>
				<td>Oxiinc</td>
				<td>1</td>
				<td>M</td>
				<td>03-10-2020 12:57:56</td>
				<td>a8e3bf2d3014672d3623</td>
				<td><button type="button" class="status-done">Order Packed Pending</button></td>
				<td><button type="button" class="status-done">Print Invoice</button></td>
				<td><button type="button" class="status-done">View Details</button></td>
            </tr>
			<tr>
                <td>3</td>
				<td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/7631424462 (2).jpg" alt="Mens Black Slim Fit Jeans DV-0710" style="width: 100px;height: 100px"></td>
                <td>Mens Black Slim Fit Jeans DV-0710</td>
				<td>Oxiinc</td>
				<td>1</td>
				<td>M</td>
				<td>03-10-2020 12:57:56</td>
				<td>a8e3bf2d3014672d3623</td>
				<td><button type="button" class="status-done">Order Packed Pending</button></td>
				<td><button type="button" class="status-done">Print Invoice</button></td>
				<td><button type="button" class="status-done">View Details</button></td>
            </tr>
        </tbody>
      </table>
	</div>
			
			
			
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>