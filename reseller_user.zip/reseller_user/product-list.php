<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	   
		<!-- Order Status Section-01 Start -->
		<section class="order-status-section-01 fwd">
		  <div class="container-fluid">
		    <h1 class="mainpage-headding">All Product <span>Details</span></h1>
			<div class="container">
			  <div class="form-content-block">
			    <form class="form-block">
				  <div class="form-group">
					<label for="InputDisplayName">Product Name</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputDisplayName">Customer Name</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputDisplayName">Product Price</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputDisplayName">Transaction Id</label>
					<input type="text" class="textbox" id="InputDisplayName">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			    </form>
			  </div>
		    </div>
			

		   
	<div class="data-table-block form-content-block">   
	  <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Sr.No</th>
                <th>Product <br> Name</th>
				<th>Sub Category <br> Name</th>
				<th>Original <br> Price</th>
				<th>Price</th>
				<th>GST <br> Percentage</th>
				<th>Shipping <br> Charges</th>
				<th>Total <br> Stock</th>
				<th>Status</th>
				<th>Product <br> Status</th>
				<th>Remark</th>
				<th>Size Wise <br> Stock</th>
				<th>Add Stock <br> With Size</th>
				<th>Product <br> Image</th>
				<th>Upload <br> Image</th>
				<th>Edit</th>
				<th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
				<td>Testing 111</td>
                <td>Footwear</td>
				<td>1200</td>
				<td>999</td>
				<td>12</td>
				<td>100</td>
				<td>5</td>
				<td><span class="badge badge-danger">Rejected</span></td>
				<td><center><i class="fas fa-ban"></i></center></td>
				<td>&nbsp;</td>
				<td data-toggle="modal" data-target="#SizeWiseStock" class="cursor-p"><center><i class="fas fa-chart-pie"></i></center></td>
				<td data-toggle="modal" data-target="#AddStockWithSize" class="cursor-p"><center><i class="fab fa-stack-overflow"></i></center></td>	
				<td data-toggle="modal" data-target="#ProductImages" class="cursor-p"><center><i class="fas fa-image"></i></center></td>
				<td data-toggle="modal" data-target="#UploadImages" class="cursor-p"><center><i class="fas fa-upload"></i></center></td>
				<td data-toggle="modal" data-target="#EditModal" class="cursor-p"><center><i class="fas fa-edit"></i></center></td>
				<td class="cursor-p"><center><i class="fas fa-trash-alt"></i></center></td>
            </tr>
        </tbody>
      </table>
	</div>
			
			
			
		  </div>
		</section>
		<div class="clrfix"></div>
		
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
	  
	<!-- SizeWiseStock Modal -->
	<div class="modal fade modal-block" id="SizeWiseStock" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <div class="modal-body">
			<form class="form-block product-list-form-modal">
			  <h2 class="headding-01">Product Size With Stock</h2>
			  <div class="form-group half-width-col">
				<label for="">Product Size</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="InputEmail">Product Stock</label>
				<input type="text" class="textbox" id="InputEmail">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group btn-half-width-col">
				<label>&nbsp;</label>
				<button type="submit" class="submit-btn IFSC-code-btn">Delete</button>
			  </div>
			  <div class="form-group text-center">
				<button type="submit" class="submit-btn">Submit</button>
			  </div>
			</form>
			<div class="clrfix"></div>
		  </div>
		</div>
	  </div>
	</div>


	<!-- AddStockWithSize Modal -->
	<div class="modal fade modal-block" id="AddStockWithSize" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <div class="modal-body">
			<form class="form-block product-list-form-modal">
			  <h2 class="headding-01">Add Stock With Size</h2>
			  <div class="fwd">
				  <div class="form-group half-width-col">
					<label for="">Product Size</label>
					<input type="text" class="textbox" id="">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group half-width-col">
					<label for="InputEmail">Product Stock</label>
					<input type="text" class="textbox" id="InputEmail">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group btn-half-width-col">
					<label>&nbsp;</label>
					<button type="submit" class="submit-btn IFSC-code-btn">Delete</button>
				  </div>
			  </div>
			  <div class="form-group btn-half-width-col">
				<button type="submit" class="submit-btn IFSC-code-btn">Add</button>
			  </div>
			  <div class="form-group text-center">
				<button type="submit" class="submit-btn">Update</button>
				<button type="submit" class="cancel-btn">Close</button>
			  </div>
			</form>
			<div class="clrfix"></div>
		  </div>
		</div>
	  </div>
	</div>


	<!-- ProductImages Modal -->
	<div class="modal fade modal-block" id="ProductImages" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <div class="modal-body">
			<form class="form-block">
			  <h2 class="headding-01">Product Images</h2>
			  <div class="form-group">
				<div class="uploaded-image-col">
				  <img src="https://www.oxiinc.in/uploads/Multiple_Picture/916345201.jpeg" alt=""/>
				</div>
				<div class="uploaded-image-col">
				  <img src="https://www.oxiinc.in/uploads/Multiple_Picture/642969226.jpg" alt=""/>
				</div>
				<div class="uploaded-image-col">
				  <img src="https://www.oxiinc.in/uploads/Multiple_Picture/1401339485.png" alt=""/>
				</div>
			  </div>
			</form>
			<div class="clrfix"></div>
		  </div>
		</div>
	  </div>
	</div>


	<!-- UploadImages Modal -->
	<div class="modal fade modal-block" id="UploadImages" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <div class="modal-body">
			<form class="form-block">
			  <h2 class="headding-01">Upload your images</h2>
			  <div class="form-group">
				<input type="file" id="real-file" hidden="hidden" onchange="uploadFile()"/>
				<button type="button" id="upload-video-btn" class="cust-channel-btn upload-btn"><i class="fa fa-upload"></i> Upload Image</button>
				<span id="upload-video-text" class="upload-text">No file chosen, yet.</span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group">
				<div class="uploaded-image-col">
				  <img src="https://www.oxiinc.in/uploads/Multiple_Picture/642969226.jpg" alt=""/>
				</div>
				<div class="uploaded-image-col">
				  <img src="https://www.oxiinc.in/uploads/Multiple_Picture/1401339485.png" alt=""/>
				</div>
			  </div>
			</form>
			<div class="clrfix"></div>
		  </div>
		</div>
	  </div>
	</div>


	<!-- EditModal Modal -->
	<div class="modal fade modal-block" id="EditModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	  <div class="modal-dialog md-top-space" role="document">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		  <div class="modal-body">
			<form class="form-block edit-profile-details-block">
			  <h2 class="headding-01">Edit Product Details</h2>
			  <div class="form-group half-width-col">
				<label for="">Product Stock</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="">Original Price</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="">Price</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="">GST Percentage</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="">Shipping Charges</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="">Product Color</label>
				<input type="text" class="textbox" id="">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="InputAccountHolderName">Short Information</label>
				<textarea class="textbox textarea" rows="3"></textarea>
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width-col">
				<label for="InputAccountHolderName">Long Information</label>
				<textarea class="textbox textarea" rows="3"></textarea>
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group text-center">
				<button type="submit" class="submit-btn">Save Changes</button>
				<button type="submit" class="cancel-btn">Cancel</button>
			  </div>
			</form>
			<div class="clrfix"></div>
		  </div>
		</div>
	  </div>
	</div>

    </div>
  </body>
</html>