<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Group</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	   
		<!-- Order Status Section-01 Start -->
		<section class="order-status-section-01 package-material-section-01 fwd">
		  <div class="container-fluid">
		    <div class="fwd text-center">
			  <h2 class="headding-02 wallet-balance">Your Wallet Balance Amount : <span>₹ 10,000</span> </h2>
			</div>
		    <h1 class="mainpage-headding">Payout <span>Request</span></h1>
			<form class="form-block">
			<div class="container">
			  <div class="form-content-block">
				  <div class="form-group col-3-div">
					<select class="textbox input-selectbox">
					  <option>Select Transfer Type</option>
					  <option>Bank Account</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group col-3-div">
					<input type="text" class="textbox" id="InputAccountHolderName" placeholder="Amount">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group col-3-div">
					<input type="text" class="textbox" id="InputAccountHolderName" placeholder="Remark">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="fwd text-center">
				    <button type="button" class="submit-btn">&nbsp;Request Payout&nbsp;</button>
					<button type="button" class="submit-btn cancel-btn">&nbsp;Reset&nbsp;</button>
				  </div>
			  </div>
		    </div>
			<div class="clrfix"></div>
			
			<div class="data-table-block form-content-block">   
			  <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
				<thead>
					<tr>
						<th>No.</th>
						<th>Account Name</th>
						<th>Account Number</th>
						<th>Request Amount</th>
						<th>Remarks</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>1</td>
						<td>Pankaj Singh</td>
						<td>541558452</td>
						<td>500</td>
						<td>Personal</td>
						<td>Done</td>
					</tr>
				</tbody>
			  </table>
			</div>
			</form>
		  </div>
		</section>
		<div class="clrfix"></div>
		
	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>