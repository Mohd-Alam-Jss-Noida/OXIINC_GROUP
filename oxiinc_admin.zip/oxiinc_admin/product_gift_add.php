<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Add Product</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Product Gift</a>
                    </li>
                    <li class="breadcrumb-item active">Add Product
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <form class="form form-horizontal">
                        <div class="form-body">
                          <div class="row">
                            <div class="col-md-4">
                              <label class="lbl_hr">Category</label>
                            </div>
                            <fieldset class="col-md-8 form-group">
                              <select class="form-control" id="basicSelect">
                                <option>Select Gift Category</option>
                                <option>Offer Zone</option>
                                <option>Electronics</option>
                                <option>Womens</option>
                                <option>Mens</option>
                                <option>Sports</option>
                                <option>Grocery</option>
                              </select>
                            </fieldset>
                            <div class="col-md-4">
                              <label class="lbl_hr">Sub Gift Category</label>
                            </div>
                            <fieldset class="col-md-8 form-group">
                              <select class="form-control" id="basicSelect">
                                <option>Select Sub Category</option>
                                <option>Offer Zone</option>
                                <option>Electronics</option>
                                <option>Womens</option>
                                <option>Mens</option>
                                <option>Sports</option>
                                <option>Grocery</option>
                              </select>
                            </fieldset>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="Product_Gift_Name">Product Gift Name</label>
                            </div>
                            <div class="col-md-8 form-group">
                              <input type="text" id="Product_Gift_Name" class="form-control" name="Product_Gift_Name" placeholder="Product Gift Name">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="Gift_Short_Name">Gift Short Name</label>
                            </div>
                            <div class="col-md-8 form-group">
                              <input type="text" id="Gift_Short_Name" class="form-control" name="Gift_Short_Name" placeholder="Gift Short Name">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="2019_Down_Payment_Price">2019 Down Payment Price</label>
                            </div>
                            <div class="col-md-8 form-group">
                              <input type="text" id="2019_Down_Payment_Price" class="form-control" name="2019_Down_Payment_Price" placeholder="2019 Down Payment Price">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="2018_Down_Payment_Price">2018 Down Payment Price</label>
                            </div>
                            <div class="col-md-8 form-group">
                              <input type="text" id="2018_Down_Payment_Price" class="form-control" name="2018_Down_Payment_Price" placeholder="2018 Down Payment Price">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="Gift_Image">Gift Image</label>
                            </div>
                            <div class="col-md-8 form-label-group">
                              <input type="file" id="Gift_Image" class="form-control" name="Gift Image">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="Brochore">Brochore</label>
                            </div>
                            <div class="col-md-8 form-label-group">
                              <input type="file" id="Brochore" class="form-control" name="Brochore">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr" for="Long_Description">Long Description</label>
                            </div>
                            <div class="col-md-8">
                              <fieldset class="form-group">
                                <textarea class="form-control" id="basicTextarea" rows="2" placeholder="Long Description"></textarea>
                              </fieldset>
                            </div>
                            <div class="col-12 d-flex justify-content-end">
                              <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                              <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		    </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>