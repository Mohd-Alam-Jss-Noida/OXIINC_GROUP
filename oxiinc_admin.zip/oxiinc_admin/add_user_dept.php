<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Add Department</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Create Department</a>
                    </li>
                    <li class="breadcrumb-item active">Add Department
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <!-- <div class="card-header">
                    <h4 class="card-title">Add Department</h4>
                  </div> -->
                  <div class="card-content">
                    <div class="card-body">
                      <form class="form">
                        <div class="form-body">
                          <div class="row">
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Employee_name" class="form-control" placeholder="Enter Employee name" name="Enter_Employee_name">
                                <label for="Enter_Employee_name">Enter Employee name</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="password" id="Enter_Employee_Password" class="form-control" placeholder="Enter Employee Password" name="Enter_Employee_Password">
                                <label for="Enter_Employee_Password">Enter Employee Password</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Employee_Email" class="form-control" placeholder="Enter Employee Email" name="Enter_Employee_Email">
                                <label for="Enter_Employee_Email">Enter Employee Email</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="number" id="Employee_Contact_Number" class="form-control" name="Employee_Contact_Number" placeholder="Employee Contact Number">
                                <label for="Employee_Contact_Number">Employee Contact Number</label>
                              </div>
                            </div>
                            <div class="col-md-12 col-12">
                              <fieldset class="form-label-group">
                                <textarea class="form-control" id="Employee_Address" rows="2" placeholder="Employee Address"></textarea>
                                <label for="Employee_Address">Employee Address</label>
                              </fieldset>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="number" id="Enter_Employee_Aadhar_Number" class="form-control" name="Enter_Employee_Aadhar_Number" placeholder="Enter Employee Aadhar Number">
                                <label for="Enter_Employee_Aadhar_Number">Enter Employee Aadhar Number</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Employee_Pan_Number" class="form-control" name="Enter_Employee_Pan_Number" placeholder="Enter Employee Pan Number">
                                <label for="Enter_Employee_Pan_Number">Enter Employee Pan Number</label>
                              </div>
                            </div>
                            <div class="col-12 d-flex justify-content-end">
                              <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                              <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		    </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>