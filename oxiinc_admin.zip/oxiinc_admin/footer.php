<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
  <p class="clearfix mb-0"><span class="float-left d-inline-block">2020 &copy; <a class="text-uppercase" href="https://www.oxiincgroup.com/" target="_blank">Oxiincgroup.com</a></span>
    <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="fa fa-arrow-up" aria-hidden="true"></i></button>
  </p>
</footer>
<!-- END: Footer-->


<!-- BEGIN: Vendor JS-->
<script src="app-assets/vendors/js/vendors.min.js"></script>
<script src="app-assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.min.js"></script>
<script src="app-assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.min.js"></script>
<script src="app-assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="app-assets/vendors/js/charts/apexcharts.min.js"></script>
<script src="app-assets/vendors/js/extensions/swiper.min.js"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="app-assets/js/scripts/configs/vertical-menu-dark.min.js"></script>
<script src="app-assets/js/core/app-menu.min.js"></script>
<script src="app-assets/js/core/app.min.js"></script>
<script src="app-assets/js/scripts/components.min.js"></script>
<script src="app-assets/js/scripts/footer.min.js"></script>
<script src="app-assets/js/scripts/customizer.min.js"></script>
<!-- END: Theme JS-->

<!-- datatable JS-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.6/js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.4/js/buttons.print.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
    var table = $('#example').DataTable( {
      lengthChange: false,
      buttons: [ 'copy', 'pdf', 'excel' ]
    } );

    table.buttons().container()
    .appendTo( '#example_wrapper .col-md-6:eq(0)' );
  } );
</script>

<!-- date time picker js -->
<script src="app-assets/vendors/js/pickers/pickadate/picker.js"></script>
<script src="app-assets/vendors/js/pickers/pickadate/picker.date.js"></script>
<script src="app-assets/vendors/js/pickers/pickadate/picker.time.js"></script>
<script src="app-assets/vendors/js/pickers/pickadate/legacy.js"></script>
<script src="app-assets/vendors/js/pickers/daterange/moment.min.js"></script>
<script src="app-assets/vendors/js/pickers/daterange/daterangepicker.js"></script>



<!-- END: Page Vendor JS-->

<!-- BEGIN: Page JS-->
<script src="app-assets/js/scripts/pickers/dateTime/pick-a-datetime.min.js"></script>
<script src="app-assets/js/scripts/navs/navs.min.js"></script>
<script src="app-assets/js/scripts/pages/dashboard-ecommerce.min.js"></script>
<!-- END: Page JS-->

<!-- Add user role modal -->
<div class="modal fade" id="add_user_role_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Information</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="alert alert-info alert-dismissible mb-2" role="alert">
          <div class="d-flex align-items-center">
            <i class="fa fa-info-circle" aria-hidden="true" style="font-size: 30px;"></i>
            <span>
              Sir Are you Sure You Want To add A Role to this User.
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary ml-1">
          <span class="d-none d-sm-block"><a class="btn_link_clr" href="add_user_role_by_department.php">Add User Role</a></span>
        </button>
      </div>
    </div>
  </div>
</div>

<!-- List Of department -->
<div class="modal fade" id="list_of_dept_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit Department</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_User_Name" class="form-control" placeholder="Enter User Name" name="Enter_User_Name">
                  <label for="Enter_User_Name">Enter User Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_User_ID" class="form-control" placeholder="Enter User ID" name="Enter_User_ID">
                  <label for="Enter_User_ID">Enter User ID</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="email" id="Enter_User_Email" class="form-control" placeholder="Enter User Email" name="Enter_User_Email">
                  <label for="Enter_User_Email">Enter User Email</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Enter_Contact_Number" class="form-control" name="Enter_Contact_Number" placeholder="Enter Contact Number">
                  <label for="Enter_Contact_Number">Enter Contact Number</label>
                </div>
              </div>
              <div class="col-md-12 col-12">
                <fieldset class="form-label-group">
                  <textarea class="form-control" id="User_Address" rows="2" placeholder="User Address"></textarea>
                  <label for="User_Address">User Address</label>
                </fieldset>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Enter_Aadhar_Number" class="form-control" name="Enter_Aadhar_Number" placeholder="Enter Aadhar Number">
                  <label for="Enter_Aadhar_Number">Enter Aadhar Number</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Pan_Number" class="form-control" name="Enter_Pan_Number" placeholder="Enter Pan Number">
                  <label for="Enter_Pan_Number">Enter Pan Number</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- List Of department -->
<div class="modal fade" id="pan_info_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">PAN Information</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Customer_Pan_Name" class="form-control" placeholder="Customer Pan Name" name="Customer_Pan_Name">
                  <label for="Customer_Pan_Name">Customer Pan Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Customer_Pan_Number" class="form-control" name="Customer_Pan_Number" placeholder="Customer Pan Number">
                  <label for="Customer_Pan_Number">Customer Pan Number</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <img src="https://www.oxiinc.in/uploads/Customer_pan/layerw12.jpg">
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="file" id="Customer_Pan_Photo" class="form-control" placeholder="Customer Pan Photo" name="Customer_Pan_Photo">
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="customer_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Customer Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Customer_name" class="form-control" placeholder="Enter Customer name" name="Enter_Customer_name">
                  <label for="Enter_Customer_name">Enter Customer name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Customer_Last_Name" class="form-control" name="Enter_Customer_Last_Name" placeholder="Enter Customer Last Name">
                  <label for="Enter_Customer_Last_Name">Enter Customer Last Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="email" id="Enter_Customer_Email_ID" class="form-control" name="Enter_Customer_Email_ID" placeholder="Enter Customer Email ID">
                  <label for="Enter_Customer_Email_ID">Enter Customer Email ID</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Enter_Customer_Contact_Number" class="form-control" name="Enter_Customer_Contact_Number" placeholder="Enter Customer Contact Number">
                  <label for="Enter_Customer_Contact_Number">Enter Customer Contact Number</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- deal Of the week -->
<div class="modal fade" id="deal_week_image_view" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">View</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-content">
            <img src="https://www.oxiinc.in/uploads/new_admin/samsung-galaxy-s8-smartphone-telephone-png-favpng-QDsR45iStNs0mP3gC5WHqUc5f.jpg" class="card-img-top img-fluid" alt="singleminded">
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Name:-   Mobile</li>
                <li class="list-group-item">Type:-  SmartPhones</li>
                <li class="list-group-item">Brand:-  Samsung</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="deal_week_image_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <img src="https://www.oxiinc.in/uploads/new_admin/samsung-galaxy-s8-smartphone-telephone-png-favpng-QDsR45iStNs0mP3gC5WHqUc5f.jpg" class="card-img-top img-fluid" alt="singleminded">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="file" id="picture" class="form-control" placeholder="picture" name="picture">
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Name" class="form-control" name="Name" placeholder="Name">
                  <label for="Name">Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="type" class="form-control" name="type" placeholder="Type">
                  <label for="type">Type</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Brand" class="form-control" name="Brand" placeholder="Brand">
                  <label for="Brand">Brand</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Price" class="form-control" name="Price" placeholder="Price">
                  <label for="Price">Price</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Product Markup List -->
<div class="modal fade" id="product_markup_list" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Product Markup</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-12">
                <div class="form-label-group">
                  <input type="number" id="Product_Markup" class="form-control" name="Product Markup" placeholder="Product Markup">
                  <label for="Product Markup">Product Markup</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Gift Category -->
<div class="modal fade" id="edit_gift_category" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Edit Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-12">
                <div class="form-label-group">
                  <input type="file" id="Enter_category_picture" class="form-control" name="Product Markup" placeholder="Enter category picture">
                  <label for="Enter category picture"></label>
                </div>
              </div>
              <div class="col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Category_Name" class="form-control" name="Enter_Category_Name" placeholder="Enter Category Name">
                  <label for="Enter_Category_Name">Enter Category Name</label>
                </div>
              </div>
              <div class="col-12">
                <fieldset class="form-label-group">
                  <h6>Status</h6>
                  <select class="form-control" id="basicSelect">
                    <option>Active</option>
                    <option>De-Active</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Gift Sub Category -->
<div class="modal fade" id="edit_gift_sub_category" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Edit Sub Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-12">
                <div class="form-label-group">
                  <input type="file" id="Enter_category_picture" class="form-control" name="Product Markup" placeholder="Enter category picture">
                  <label for="Enter category picture"></label>
                </div>
              </div>
              <div class="col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Category_Name" class="form-control" name="Enter_Category_Name" placeholder="Enter Category Name">
                  <label for="Enter_Category_Name">Enter Category Name</label>
                </div>
              </div>
              <div class="col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Sub_Category_Name" class="form-control" name="Enter_Sub_Category_Name" placeholder="Enter Sub Category Name">
                  <label for="Enter_Sub_Category_Name">Enter Sub Category Name</label>
                </div>
              </div>
              <div class="col-12">
                <fieldset class="form-label-group">
                  <h6>Status</h6>
                  <select class="form-control" id="basicSelect">
                    <option>Active</option>
                    <option>De-Active</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Gift Product -->
<div class="modal fade" id="edit_gift_product" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Edit Gift Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form form-horizontal">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4">
                <label class="lbl_hr">Category</label>
              </div>
              <fieldset class="col-md-8 form-group">
                <select class="form-control" id="basicSelect">
                  <option>Select Gift Category</option>
                  <option>Offer Zone</option>
                  <option>Electronics</option>
                  <option>Womens</option>
                  <option>Mens</option>
                  <option>Sports</option>
                  <option>Grocery</option>
                </select>
              </fieldset>
              <div class="col-md-4">
                <label class="lbl_hr">Sub Gift Category</label>
              </div>
              <fieldset class="col-md-8 form-group">
                <select class="form-control" id="basicSelect">
                  <option>Select Sub Category</option>
                  <option>Offer Zone</option>
                  <option>Electronics</option>
                  <option>Womens</option>
                  <option>Mens</option>
                  <option>Sports</option>
                  <option>Grocery</option>
                </select>
              </fieldset>
              <div class="col-md-4">
                <label class="lbl_hr" for="Product_Gift_Name">Product Gift Name</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="text" id="Product_Gift_Name" class="form-control" name="Product_Gift_Name" placeholder="Product Gift Name">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr" for="Gift_Short_Name">Gift Short Name</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="text" id="Gift_Short_Name" class="form-control" name="Gift_Short_Name" placeholder="Gift Short Name">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr" for="2019_Down_Payment_Price">2019 Down Payment Price</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="text" id="2019_Down_Payment_Price" class="form-control" name="2019_Down_Payment_Price" placeholder="2019 Down Payment Price">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr" for="2018_Down_Payment_Price">2018 Down Payment Price</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="text" id="2018_Down_Payment_Price" class="form-control" name="2018_Down_Payment_Price" placeholder="2018 Down Payment Price">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr" for="Gift_Image">Gift Image</label>
              </div>
              <div class="col-md-8 form-label-group">
                <input type="file" id="Gift_Image" class="form-control" name="Gift Image">
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Stock Management In Stock Product -->
<div class="modal fade" id="stock_management_in_stock" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">In Stock Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form form-horizontal">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4">
                <label class="lbl_hr" for="Stock_Status">Stock Status</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="number" id="Stock_Status" class="form-control" name="Stock_Status" placeholder="Stock Status">
              </div>

              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Add Promo Code -->
<div class="modal fade" id="add_promo_code" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Add Promo Code</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form form-horizontal">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4">
                <label class="lbl_hr" for="Enter_Promo_Code">Enter Promo Code</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="text" id="Enter_Promo_Code" class="form-control" name="Enter_Promo_Code" placeholder="Enter Promo Code">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr" for="Enter_Promo_Amount">Enter Promo Amount</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="number" id="Enter_Promo_Amount" class="form-control" name="Enter_Promo_Amount" placeholder="Enter Promo Amount">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr" for="Enter_Minimum_Amount">Enter Minimum Amount</label>
              </div>
              <div class="col-md-8 form-group">
                <input type="number" id="Enter_Minimum_Amount" class="form-control" name="Enter_Minimum_Amount" placeholder="Enter Minimum Amount">
              </div>
              <div class="col-md-4">
                <label class="lbl_hr">Enter Expiry date</label>
              </div>
              <div class="col-md-8">
                <fieldset class="form-label-group position-relative has-icon-left">
                  <input type="text" class="form-control pickadate-months-year" placeholder="Select Date">
                  <div class="form-control-position">
                    <i class='bx bx-calendar'></i>
                  </div>
                </fieldset>
              </div>

              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- list of promo code -->
<div class="modal fade" id="list_of_promo_code" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Edit Promo Code</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Promo_Code" class="form-control" name="Enter_Promo_Code" placeholder="Enter Promo Code">
                  <label for="Enter_Promo_Code">Enter Promo Code</label>
                </div>
              </div>
              <div class="col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Promo_Percentage" class="form-control" name="Enter_Promo_Percentage" placeholder="Enter Promo Percentage">
                  <label for="Enter_Promo_Percentage">Enter Promo Percentage</label>
                </div>
              </div>
              <div class="col-12">
                <div class="form-label-group">
                  <input type="number" id="Enter_Minimum_Amount" class="form-control" name="Enter_Minimum_Amount" placeholder="Enter Minimum Amount">
                  <label for="Enter_Minimum_Amount">Enter Minimum Amount</label>
                </div>
              </div>
              <div class="col-12">
                <fieldset class="form-label-group">
                  <h6>Active Promo Status</h6>
                  <select class="form-control" id="basicSelect">
                    <option>Active Promo Status</option>
                    <option>Promo Active</option>
                    <option>Promo De-Active</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- enpay txn history -->
<div class="modal fade" id="enpay_txn_history" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Enpay Trasaction History</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <center><h4>Rs. 0</h4></center>
        <center>TRANSACTION HISTORY</center><br>
        <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
          <thead>
            <tr>
              <th>Date</th>
              <th>Credit Amount</th>
              <th>Debit Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>SHAKTIKUMAR</td>
              <td>RKGOTEAM@GMAIL.COM</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Credits enpay -->
<div class="modal fade" id="enpay_credits" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Add Credits Enpay Amount</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <center><h4>Rs. 0</h4></center>
        <center>Customer Enpay Balance</center><br>
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Customer_Name" class="form-control" placeholder="Customer Name" name="Customer_Name">
                  <label for="Customer_Name">Customer Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="email" id="Customer_Email" class="form-control" placeholder="Customer Email" name="Customer_Email">
                  <label for="Customer_Email">Customer Email</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Customer_enapy_Balance" class="form-control" placeholder="Customer enapy Balance" name="Customer_enapy_Balance">
                  <label for="Customer_enapy_Balance">Customer enapy Balance</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Credit_Enpay_Amount" class="form-control" name="Credit_Enpay_Amount" placeholder="Credit Enpay Amount">
                  <label for="Credit_Enpay_Amount">Credit Enpay Amount</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Credits enpay -->
<div class="modal fade" id="enpay_debits" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Add Debits Enpay Amount</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <center><h4>Rs. 0</h4></center>
        <center>Customer Enpay Balance</center><br>
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Customer_Name" class="form-control" placeholder="Customer Name" name="Customer_Name">
                  <label for="Customer_Name">Customer Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="email" id="Customer_Email" class="form-control" placeholder="Customer Email" name="Customer_Email">
                  <label for="Customer_Email">Customer Email</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Customer_enapy_Balance" class="form-control" placeholder="Customer enapy Balance" name="Customer_enapy_Balance">
                  <label for="Customer_enapy_Balance">Customer enapy Balance</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Debit_Enpay_Amount" class="form-control" name="Debit_Enpay_Amount" placeholder="Debit Enpay Amount">
                  <label for="Debit_Enpay_Amount">Debit Enpay Amount</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Header banner -->
<div class="modal fade" id="header_banner_image_view" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">View</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-content">
            <img src="https://www.oxiinc.in/uploads/images/2.jpg" class="card-img-top img-fluid" alt="singleminded">
            <div class="card-body">
              <ul class="list-group list-group-flush">
                <li class="list-group-item">Picture Name:- banner</li>
                <li class="list-group-item">Label 1:- Success Is the</li>
                <li class="list-group-item">Label 2:- maximum utilization of</li>
                <li class="list-group-item">Label 3:- the ability that you have</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="header_banner_image_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <img src="https://www.oxiinc.in/uploads/images/2.jpg" class="card-img-top img-fluid" alt="singleminded">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="file" id="picture" class="form-control" placeholder="picture" name="picture">
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Picture_Name" class="form-control" name="Picture_Name" placeholder="Picture Name:">
                  <label for="Picture_Name">Picture Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Label_1" class="form-control" name="Label_1" placeholder="Label 1">
                  <label for="Label_1">Label 1</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Label_2" class="form-control" name="Label_2" placeholder="Label 2">
                  <label for="Label_2">Label 2</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="number" id="Label_3" class="form-control" name="Label_3" placeholder="Label 1">
                  <label for="Label_3">Label 1</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Product Category Banner -->
<div class="modal fade" id="product_category_banner_image_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <img src="https://www.oxiinc.in/uploads/banner/mobil%20and%20accesoris.jpg" class="card-img-top img-fluid" alt="singleminded">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="file" id="picture" class="form-control" placeholder="picture" name="picture">
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Picture_Name" class="form-control" name="Picture_Name" placeholder="Picture Name:">
                  <label for="Picture_Name">Picture Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Product Sub Category Banner -->
<div class="modal fade" id="product_Sub_category_banner_image_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <img src="https://www.oxiinc.in/uploads/banner/mobil%20and%20accesoris.jpg" class="card-img-top img-fluid" alt="singleminded">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="file" id="picture" class="form-control" placeholder="picture" name="picture">
                </div>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Picture_Name" class="form-control" name="Picture_Name" placeholder="Picture Name:">
                  <label for="Picture_Name">Picture Name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Advertisement Banner -->
<div class="modal fade" id="advertisement_banner_image_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <img src="https://www.oxiinc.in/uploads/Advertisement/1.jpg" class="card-img-top img-fluid" alt="singleminded">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="file" id="picture" class="form-control" placeholder="picture" name="picture">
                </div>
              </div>
              <div class="col-md-6 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Category</option>
                    <option>Mens</option>
                    <option>Womens</option>
                    <option>Electronics</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-md-6 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Sub Category</option>
                    <option>Mens</option>
                    <option>Womens</option>
                    <option>Electronics</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Picture_Name" class="form-control" name="Picture_Name" placeholder="Picture Name:">
                  <label for="Picture_Name">Adveritisement banner Name</label>
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Advertisement Banner -->
<div class="modal fade" id="short_category_name_list" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-6 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Url_Append_name" class="form-control" name="Enter_Url_Append_name" placeholder="Enter Url Append name">
                  <label for="Enter_Url_Append_name">Enter Url Append name</label>
                </div>
              </div>
              <div class="col-md-6 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- add header product category list -->
<div class="modal fade" id="add_header_category_list" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Category Name</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_Category_Name" class="form-control"  placeholder="Enter Category Name">
                </div>
              </div>
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Sub Category Name</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_sub_Category_Name" class="form-control"  placeholder="Enter Sub Category Name">
                </div>
              </div>
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Sub Category Name</label>
              </div>
              <div class="col-md-8 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Sub product category list -->
<div class="modal fade" id="sub_category_list" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter SubCategory Name</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="text" id="Enter_subCategory_Name" class="form-control"  placeholder="Enter SubCategory Name">
                </div>
              </div>
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Sub Category Name</label>
              </div>
              <div class="col-md-8 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- product category list -->
<div class="modal fade" id="product_category_list" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Product Sub Category Name</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="text" id="Product_Sub_Category_Name" class="form-control"  placeholder="Product Sub Category Name">
                </div>
              </div>
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Sub Category Name</label>
              </div>
              <div class="col-md-8 col-12">
                <fieldset class="form-label-group">
                  <select class="form-control" id="basicSelect">
                    <option>Status</option>
                    <option>Active</option>
                    <option>Inactive</option>
                  </select>
                </fieldset>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- oxiinc product upload list -->
<div class="modal fade" id="oxiinc_product_upload" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Upload Product Picture</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Product Picture</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="file" id="Product_Sub_Category_Name" class="form-control"  placeholder="Product Sub Category Name">
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Add Size wise stock -->
<div class="modal fade" id="Add_Size_Stock" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Add Size Wise Stock</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="table-responsive">
          <table class="table dt-responsive nowrap" style="width:100%">
            <tbody id="TextBoxContainer">
              <tr>
                <td>
                  <div class="form-label-group">
                    <input type="text" id="first-name-floating" class="form-control" placeholder="Enter Your Size" name="fname-floating">
                  </div>
                </td>
                <td>
                  <div class="form-label-group">
                    <input type="text" id="first-name-floating" class="form-control" placeholder="Enter Your Stock" name="fname-floating">
                  </div>
                </td>
                <td>
                  <button id="btnAdd" type="button" class="btn btn-primary" data-toggle="tooltip"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Add&nbsp;</button>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th colspan="3">
                  <button  type="submit" class="btn btn-primary">&nbsp; Submit&nbsp;</button>
                </th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  $(function () {
    $("#btnAdd").on("click", function () {
      var div = $("<tr />");
      div.html(GetDynamicTextBox(""));
      $("#TextBoxContainer").append(div);
    });
    $("body").on("click", ".remove", function () {
      $(this).closest("tr").remove();
    });
  });

  function GetDynamicTextBox(value) {
    return '<td><div class="form-label-group"><input type="text" id="first-name-floating" class="form-control" placeholder="Enter Your Size" name="fname-floating"></div></td>'+'<td><div class="form-label-group"><input type="text" id="first-name-floating" class="form-control" placeholder="Enter Your Stock" name="fname-floating"></div></td>'+'<td><button type="button" class="btn btn-danger remove">Remove</button></td>';
  }
</script>
<!-- End Add Size wise stock -->

<!-- Oxiinc single product upload --product and upload section -->
 <script>
  $(function () {
    $("#btnAdd").on("click", function () {
      var div = $("<tr />");
      div.html(Product_pictureBox(""));
      $("#Product_picture").append(div);
    });
    $("body").on("click", ".remove", function () {
      $(this).closest("tr").remove();
    });
  });

  function Product_pictureBox(value) {
    return '<td><div class="col-md-12 form-group"><input type="file" id="" class="form-control"></div></td>'+'<td><div class="col-md-12 form-group"><input type="text" id="Size" class="form-control" placeholder="Size"></div></td>'+'<td><button type="button" class="btn btn-danger remove">Remove</button></td>';
  }
</script>

<!-- Oxiinc single product upload --attribute section -->
 <script>
  $(function () {
    $("#AttributeAdd").on("click", function () {
      var div = $("<tr />");
      div.html(AttributeBox(""));
      $("#Attribute").append(div);
    });
    $("body").on("click", ".remove", function () {
      $(this).closest("tr").remove();
    });
  });

  function AttributeBox(value) {
    return '<td><div class="col-md-12"><label class="lbl_hr">Size</label></div></td>'+'<td><div class="col-md-12 form-group"><input type="text" id="Size" class="form-control" placeholder="Size"></div></td>'+'<td><button type="button" class="btn btn-danger remove">Remove</button></td>';
  }
</script>

<!-- Oxiinc single product upload --Size Manage section -->
 <script>
  $(function () {
    $("#SizeManageAdd").on("click", function () {
      var div = $("<tr />");
      div.html(SizeManageBox(""));
      $("#SizeManage").append(div);
    });
    $("body").on("click", ".remove", function () {
      $(this).closest("tr").remove();
    });
  });

  function SizeManageBox(value) {
    return '<td><div class="col-md-12 form-group"><input type="text" id="Product_Size" class="form-control" placeholder="Product Size"></div></td>'+'<td><div class="col-md-12 form-group"><input type="text" id="Product_Stock" class="form-control" placeholder="Product Stock"></div></td>'+'<td><button type="button" class="btn btn-danger remove">Remove</button></td>';
  }
</script>

<!-- Oxiinc Bulk product upload  -->
 <script>
  $(function () {
    $("#bulkproductAdd").on("click", function () {
      var div = $("<tr />");
      div.html(bulkproductBox(""));
      $("#bulkproduct").append(div);
    });
    $("body").on("click", ".remove", function () {
      $(this).closest("tr").remove();
    });
  });

  function bulkproductBox(value) {
    return '<td><div class="col-md-12 form-group"><input type="text" id="Product_Size" class="form-control" placeholder="Product Size"></div></td>'+'<td><div class="col-md-12 form-group"><input type="text" id="Size_Wise_Stock" class="form-control" placeholder="Size Wise Stock"></div></td>'+'<td><button type="button" class="btn btn-icon rounded-circle btn-light-danger btn_add_del remove mr-1 mb-1"><i class="fa fa-trash" aria-hidden="true"></i></button></td>';
  }
</script>


<!-- Oxiinc Bulk product upload Big Table -->
<script>
  $(function () {
    $("#mainbulkproductAdd").on("click", function () {
      var div = $("<tr />");
      div.html(mainbulkproductBox(""));
      $("#mainbulkproduct").append(div);
    });
    $("body").on("click", ".remove", function () {
      $(this).closest("tr").remove();
    });
  });

  function mainbulkproductBox(value) {
    return '<td><input type="file"></td>'+'<td><input type="text" id="Product_Name" class="form-control" placeholder="Product Name"></td>'+'<td><input type="number" id="Product_MRP" class="form-control" placeholder="Product MRP"></td>'+'<td><input type="number" id="Price" class="form-control" placeholder="Price"></td>'+'<td><textarea class="form-control" id="label-textarea" rows="2" placeholder="Short Info"></textarea></td>'+'<td><textarea class="form-control" id="label-textarea" rows="2" placeholder="Long Info"></textarea></td>'+'<td><input type="text" id="GST_Percentage" class="form-control" placeholder="GST Percentage"></td>'+'<td><input type="text" id="Shipping_Charges" class="form-control" placeholder="Shipping Charges"></td>'+'<td>'+'<fieldset><select class="form-control" id="basicSelect"><option>Select Category </option><option>Mens</option><option>Womens</option><option>Electronics</option></select></fieldset></td>'+'<td><table class="table bulkproduct_upload"><tbody id="bulkproduct"><tr><td><input type="text" id="Product_Size" class="form-control" placeholder="Product Size"></td><td><input type="text" id="Size_Wise_Stock" class="form-control" placeholder="Size Wise Stock"></td><td><button type="button" id="bulkproductAdd" class="btn btn-icon rounded-circle btn-light-primary btn_add_del mr-1 mb-1"><i class="fa fa-plus" aria-hidden="true"></i></button></td></tr></tbody></table></td>'+'<td><button type="button" class="btn btn-icon rounded-circle btn-light-danger btn_add_del remove mr-1 mb-1"><i class="fa fa-trash" aria-hidden="true"></i></button></td>';
  }
</script>

<!-- Reseller Product list Image View -->
<div class="modal fade" id="reseller_product_image_view" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">View</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-content">
            <img src="https://www.oxiinc.in/uploads/images/2.jpg" class="card-img-top img-fluid" alt="singleminded">
            <div class="card-body">
              <center><button type="button" class="btn btn-danger shadow mr-1 mb-1">Delete</button></center>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- reseller product upload list -->
<div class="modal fade" id="reseller_product_upload" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Upload Product Picture</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Enter Product Picture</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="file" id="Product_Sub_Category_Name" class="form-control"  placeholder="Product Sub Category Name">
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- reseller Edit product -- Size Stock -->
<div class="modal fade" id="reseller_size_stock" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalCenterTitle">Size Stock</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="bx bx-x"></i>
        </button>
      </div>
      <div class="modal-body">
        <form class="form">
          <div class="form-body">
            <div class="row">
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Size</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="text" id="Size" class="form-control"  placeholder="Size">
                </div>
              </div>
              <div class="col-md-4 col-12">
                <label class="lbl_hr">Stock</label>
              </div>
              <div class="col-md-8 col-12">
                <div class="form-label-group">
                  <input type="number" id="Stock" class="form-control"  placeholder="Stock">
                </div>
              </div>
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

</body>
<!-- END: Body-->
</html>