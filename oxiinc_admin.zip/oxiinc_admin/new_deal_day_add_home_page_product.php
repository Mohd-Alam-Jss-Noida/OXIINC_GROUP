<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Home Page Product</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Product Home Page</a>
                    </li>
                    <li class="breadcrumb-item active">Home Page Product
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
                        <li class="nav-item current">
                          <a class="nav-link active" id="home-tab-fill" data-toggle="tab" href="#home-fill" role="tab" aria-controls="home-fill" aria-selected="true">
                            Product Specification
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="Description-tab-fill" data-toggle="tab" href="#Description-fill" role="tab" aria-controls="Description-fill" aria-selected="false">
                            Description
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="profile-tab-fill" data-toggle="tab" href="#profile-fill" role="tab" aria-controls="profile-fill" aria-selected="false">
                            Product Picture & Verified
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="Product_HighlightsSevices-tab-fill" data-toggle="tab" href="#Product_HighlightsSevices-fill" role="tab" aria-controls="Product_HighlightsSevices-fill" aria-selected="false">
                            Product Highlights & Sevices
                          </a>
                        </li>
                      </ul>
                      <div class="tab-content pt-1">
                        <div class="tab-pane active" id="home-fill" role="tabpanel" aria-labelledby="home-tab-fill">
                          <form class="form form-horizontal">
                            <div class="form-body">
                              <div class="row">
                                <div class="col-md-4">
                                  <label class="lbl_hr">Upend Heading</label>
                                </div>
                                <div class="col-md-8 form-label-group">
                                  <fieldset class="form-label-group">
                                    <select class="form-control" id="basicSelect">
                                      <option>Select Category </option>
                                      <option>Deal Of The Day</option>
                                    </select>
                                  </fieldset>
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Name</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Name" class="form-control" name="Product_Name" placeholder="Product Name">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">MRP Price</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="MRP_Price" class="form-control" name="MRP_Price" placeholder="MRP Price">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Offer Price</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Offer_Price" class="form-control" placeholder="Offer Price">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Terms Conditions</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Terms_Conditions" class="form-control" placeholder="Terms Conditions">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Type</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Type" class="form-control" placeholder="Product Type">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Company Name</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Company_Name" class="form-control" placeholder="Company Name">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Pack Size</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Pack_Size" class="form-control" placeholder="Pack Size">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Unit</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Unit" class="form-control" placeholder="Unit">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Hsn Code</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Hsn_Code" class="form-control" placeholder="Hsn Code">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Stock Status</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Stock_Status" class="form-control" placeholder="Stock Status">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Offer</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Offer" class="form-control" placeholder="Product Offer">
                                </div>
                                <div class="col-sm-12 d-flex justify-content-end">
                                  <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                                  <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Clear Form</button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="tab-pane" id="Description-fill" role="tabpanel" aria-labelledby="Description-tab-fill">
                          <form class="form form-horizontal">
                            <div class="form-body">
                              <div class="row">
                                <div class="col-md-4">
                                  <label class="lbl_hr">Short Description</label>
                                </div>
                                <div class="col-md-8 form-label-group">
                                  <fieldset class="form-label-group">
                                    <textarea class="form-control" id="label-textarea" rows="3" placeholder="Short Description"></textarea>
                                    <label for="label-textarea">Short Description</label>
                                  </fieldset>
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">large Description</label>
                                </div>
                                <div class="col-md-8 form-label-group">
                                  <fieldset class="form-label-group">
                                    <textarea class="form-control" id="label-textarea123" rows="3" placeholder="large Description"></textarea>
                                    <label for="label-textarea123">large Description</label>
                                  </fieldset>
                                </div>
                                <div class="col-sm-12 d-flex justify-content-end">
                                  <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                                  <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Clear Form</button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="tab-pane" id="profile-fill" role="tabpanel" aria-labelledby="profile-tab-fill">
                          <form class="form form-horizontal">
                            <div class="form-body">
                              <div class="row">
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Picture</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="file" id="Product_Picture" class="form-control" name="Product_Picture" placeholder="Product Picture">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Verified</label>
                                </div>
                                <div class="col-md-8 form-label-group">
                                  <fieldset class="form-label-group">
                                    <select class="form-control" id="basicSelect">
                                      <option>Select Verified </option>
                                      <option>Verified</option>
                                      <option>Not Verified</option>
                                    </select>
                                  </fieldset>
                                </div>
                                <div class="col-sm-12 d-flex justify-content-end">
                                  <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                                  <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Clear Form</button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                        <div class="tab-pane" id="Product_HighlightsSevices-fill" role="tabpanel" aria-labelledby="Product_HighlightsSevices-tab-fill">
                          <form class="form form-horizontal">
                            <div class="form-body">
                              <div class="row">
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Highlights Lable 1</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Picture" class="form-control" placeholder="Product Highlights Lable 1">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Highlights Lable 2</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Picture" class="form-control" placeholder="Product Highlights Lable 2">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Warranty</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Picture" class="form-control" placeholder="Product Warranty">
                                </div>
                                <div class="col-md-4">
                                  <label class="lbl_hr">Product Return Policy</label>
                                </div>
                                <div class="col-md-8 form-group">
                                  <input type="text" id="Product_Picture" class="form-control" placeholder="Product Return Policy">
                                </div>
                                <div class="col-sm-12 d-flex justify-content-end">
                                  <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                                  <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Clear Form</button>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>

                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		    </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>