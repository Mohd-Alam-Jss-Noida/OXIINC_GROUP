<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">User Role By Department</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Create Department</a>
                    </li>
                    <li class="breadcrumb-item"><a href="add_user_role.php">Add User Role</a>
                    </li>
                    <li class="breadcrumb-item active">User Role By Department
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="nav-tabs-centered">
            <div class="row">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <ul class="nav nav-tabs justify-content-center" role="tablist">
                        <li class="nav-item current">
                          <a class="nav-link active" id="module-name-tab-center" data-toggle="tab" href="#module-name-center" aria-controls="module-name-center" role="tab" aria-selected="true">
                            MODULE NAME
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="sub-module-name-tab-center" data-toggle="tab" href="#sub-module-name-center" aria-controls="sub-module-name-center" role="tab" aria-selected="false">SUB MODULE NAME </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="access-level-tab-center" data-toggle="tab" href="#access-level-center" aria-controls="access-level-center" role="tab" aria-selected="false">
                            ACCESS LEVEL
                          </a>
                        </li>
                      </ul>
                      <div class="tab-content">
                        <div class="tab-pane active" id="module-name-center" aria-labelledby="module-name-tab-center" role="tabpanel">
                          <div class="table-responsive">
                            <table class="table mb-0">
                              <thead class="thead-dark">
                                <tr>
                                  <th>Module Name</th>
                                  <th>Authentication</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td class="text-bold-500">Create Department</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Create Customer</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Chart</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Total Order's</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Order Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Order Packed Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Shipping Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">In Transit Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Out For Delivered Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Delivered Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Cancel Product</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Return Product</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Seminar</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">GST Report</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Promo Code</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Enpay</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Wishlist</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Home Page Header</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Product Home Page</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">New Deal of The Day</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Category</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Product</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <div class="tab-pane" id="sub-module-name-center" aria-labelledby="sub-module-name-tab-center" role="tabpanel">
                          <div class="table-responsive">
                            <table class="table mb-0">
                              <thead class="thead-dark">
                                <tr>
                                  <th>Sub Module Name</th>
                                  <th>Authentication</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td class="text-bold-500">Add User Department</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Add User Role</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Department</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Add New Customer</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Customer</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Order/Cancel Report Chart</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Total order confirmation</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Order Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Order Packed Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Shipped Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of In Transit Confirm</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Out for Delivered confrim</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Delivered confrim</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Cancel Product</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Return Product</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Seminar Information List</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Ticket Book Customer</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Total GST Report</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Add Promo Code</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Promo Code</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List of Customer For Enpay</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">List Of Wishlist</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Add Product</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Product List</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <div class="tab-pane" id="access-level-center" aria-labelledby="access-level-tab-center" role="tabpanel">
                          <div class="table-responsive">
                            <table class="table mb-0">
                              <thead class="thead-dark">
                                <tr>
                                  <th>Access Level Name</th>
                                  <th>Authentication</th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td class="text-bold-500">View</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Update</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                                <tr>
                                  <td class="text-bold-500">Delete</td>
                                  <td><div class="custom-control custom-switch custom-switch-success mr-2 mb-1">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch11">
                                        <label class="custom-control-label" for="customSwitch11">
                                          <span class="switch-icon-left"><i class="fa fa-check" aria-hidden="true"></i></span>
                                          <span class="switch-icon-right"><i class="fa fa-check" aria-hidden="true"></i></span>
                                        </label>
                                      </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>    
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

<script src="app-assets/js/scripts/navs/navs.min.js"></script>
<?php include 'footer.php';?>