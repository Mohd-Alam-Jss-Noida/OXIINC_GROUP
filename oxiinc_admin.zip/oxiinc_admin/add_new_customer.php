<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Add Customer</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Create Customer</a>
                    </li>
                    <li class="breadcrumb-item active">Add Customer
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <form class="form">
                        <div class="form-body">
                          <div class="row">
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Customer_name" class="form-control" placeholder="Enter Customer name" name="Enter_Customer_name">
                                <label for="Enter_Customer_name">Enter Customer name</label>
                              </div>
                            </div>  
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Customer_last_name" class="form-control" placeholder="Enter Customer Last name" name="Enter_Customer_last_name">
                                <label for="Enter_Customer_last_name">Enter Customer Last name</label>
                              </div>
                            </div>  
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Customer_Email_ID" class="form-control" placeholder="Enter Customer Email ID" name="Enter_Customer_Email_ID">
                                <label for="Enter_Customer_Email_ID">Enter Customer Email ID </label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="number" id="Enter_Customer_Contact_Number" class="form-control" name="Enter_Customer_Contact_Number" placeholder="Enter Customer Contact Number">
                                <label for="Enter_Customer_Contact_Number">Enter Customer Contact Number</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="password" id="Enter_Customer_Password" class="form-control" placeholder="Enter Customer Password" name="Enter_Customer_Password">
                                <label for="Enter_Customer_Password">Enter Customer Password</label>
                              </div>
                            </div>
                            <!-- <div class="col-md-12 col-12">
                              <fieldset class="form-label-group">
                                <textarea class="form-control" id="Employee_Address" rows="2" placeholder="Employee Address"></textarea>
                                <label for="Employee_Address">Employee Address</label>
                              </fieldset>
                            </div> -->
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Customer_Pan_Name" class="form-control" name="Enter_Customer_Pan_Name" placeholder="Enter Customer Pan Name">
                                <label for="Enter_Customer_Pan_Name">Enter Customer Pan Name</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Enter_Customer_Pan_Number" class="form-control" name="Enter_Customer_Pan_Number" placeholder="Enter Customer Pan Number">
                                <label for="Enter_Customer_Pan_Number">Enter Customer Pan Number</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="file" id="Enter_Customer_Pan_Photo" class="form-control" name="Enter_Customer_Pan_Photo">
                              </div>
                            </div>
                            <div class="col-12 d-flex justify-content-end">
                              <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                              <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>