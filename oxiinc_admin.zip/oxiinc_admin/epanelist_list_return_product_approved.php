<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">List Of Return Product</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Epanelist Customer Tracking</a>
                    </li>
                    <li class="breadcrumb-item active">List Of Return Product
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Customer Name</th>
                                <th>Contact Number</th>
                                <th>Product Name</th>
                                <th>Prices</th>
                                <th>Product Txn ID</th>
                                <th>Return Address</th>
                                <th>Payment Method</th>
                                <th>Status</th>
                                <th>Return Date</th>
                                <th>Order Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td>1</td>
                              <td>oxiinc</td>
                              <td>1234567</td>
                              <td>Mens Black Slim Fit Jeans DV-0710</td>
                              <td>2810</td>
                              <td>c0bcf5db890997dbc4d7</td>
                              <td>bhihar india, gg/Mumbai-400000, Mumbai-400000</td>
                              <td>DIGITAL WALLET</td>
                              <td>Approved</td>
                              <td>2020-11-28 15:12:40</td>
                              <td><button class="btn btn-info">Order Status</button></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>