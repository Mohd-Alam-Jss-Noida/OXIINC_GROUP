<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Short Category Name List</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Product Home Page</a>
                    </li>
                    <li class="breadcrumb-item active">Short Category Name List
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Product Picture</th>
                                <th>Product Offer</th>
                                <th>Product Short Name</th>
                                <th>Status</th>
                                <th>Action(View)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Laptops</td>
                                <td><img src="https://www.oxiinc.in/uploads/append/Laptop.jpg" width="135"></td>
                                <td>Upto 15% Off</td>
                                <td>HP, Dell, Lenovo, Acer</td>
                                <td><span class="badge">Active</span></td>
                                <td><a href="add_home_page_product.php" target="_blank"><i class="fa fa-pencil fa_icon_size" aria-hidden="true"></i></a> &nbsp;&nbsp; <i class="fa fa-trash fa_icon_size" aria-hidden="true"></i></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>