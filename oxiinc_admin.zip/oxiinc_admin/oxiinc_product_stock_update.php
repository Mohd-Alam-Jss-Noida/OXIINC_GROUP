<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0"> Product Stock Update</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Oxiinc Product</a>
                    </li>
                    <li class="breadcrumb-item active">Product Stock Update
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr No</th>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Total Stock</th>
                                <th>Status</th>
                                <th>Multiple Images</th>
                                <th>Size</th>
                                <th>Stock</th>
                                <th>Total Stock</th>
                              </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>
                                  <fieldset>
                                    <div class="checkbox">
                                      <input type="checkbox" class="checkbox-input" id="checkbox2">
                                      <label for="checkbox2">2548</label>
                                    </div>
                                  </fieldset>
                                </td>
                                <td>Slopper Hide & City Trousers 6006/6</td>
                                <td>10</td>
                                <td><span class="badge">Active</span></td>
                                <td><input type="file" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="number" class="form-control"></td>
                                <td><input type="number" class="form-control"></td>
                              </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>