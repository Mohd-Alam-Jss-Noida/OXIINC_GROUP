<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Orders Table</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Normal Customer Tracking</a>
                    </li>
                    <li class="breadcrumb-item active">Orders Table
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Category Id</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Conatct No.</th>
                                <th>Product Name</th>
                                <th>Shipping Address</th>
                                <th>Tracking Id</th>
                                <th>Order Confirmation</th>
                                <th>Dispatchment Confirmation</th>
                                <th>Shipping Confirmation</th>
                                <th>Order Delivered</th>
                                <th>Promo Code</th>
                                <th>MRP Price</th>
                                <th>Sale Price</th>
                                <th>Qty</th>
                                <th>GST Price</th>
                                <th>Shipping Charges</th>
                                <th>Order Date Time</th>
                                <th>Payment Method</th>
                                <th>Action</th>
                                <th>Dispatchment_confirmation_info</th>
                                <th>Shipping_Confirmation_info</th>
                                <th>Intransist_confirmation_info</th>
                                <th>Out_for_delivery_confirmation_info</th>
                                <th>Delivered_confirmation_info</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td>1</td>
                              <td>227</td>
                              <td>PAWAN</td>
                              <td>MEENAPAWANPM@GMAIL.COM</td>
                              <td>9584646718</td>
                              <td>Strips Top OX-168</td>
                              <td>38-31-134 2nd floor Green garden,Near photostudio,Visakhapatnam-530018,Andhra Pradesh</td>
                              <td>2057bd4cfe698ed6ae4c</td>
                              <td><span class="badge badge-success">Confirm</span></td>
                              <td><span class="badge badge-success">Confirm</span></td>
                              <td><span class="badge badge-secondary">Un-Confirm</span></td>
                              <td><span class="badge badge-secondary">UnConfirm</span></td>
                              <td>0</td>
                              <td>2150</td>
                              <td>1850</td>
                              <td>1</td>
                              <td>222</td>
                              <td>55</td>
                              <td>2019-May-01</td>
                              <td>enpay</td>
                              <td><button class="btn btn-danger">Delete</button></td>
                              <td>Your order has been packed confirm</td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>