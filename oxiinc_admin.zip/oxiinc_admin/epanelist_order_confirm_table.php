<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Order Confirm Table</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Epanelist Customer Tracking</a>
                    </li>
                    <li class="breadcrumb-item active">Order Confirm Table
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Category Id</th>
                                <th>Customer Name</th>
                                <th>Contact Number</th>
                                <th>Product Name</th>
                                <th>Tracking Id</th>
                                <th>Hold</th>
                                <th>Prices</th>
                                <th>Order Date Time</th>
                                <th>Order Confirmation</th>
                                <th>Payment Method</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>