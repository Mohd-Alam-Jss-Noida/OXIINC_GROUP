<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">View Multiple Images</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Oxiinc Product</a>
                    </li>
                    <li class="breadcrumb-item active">View Multiple Images
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="row">
                    <div class="col-sm-3">
                      <div class="card-content">
                        <a href="#"><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1629206975.png" alt="Card image cap" width="100%" height="300px"></a>
                        <div class="card-body">
                          <center><button class="btn btn-primary block">Delete</button></center>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="card-content">
                        <a href="#"><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1530504864.png" alt="Card image cap" width="100%" height="300px"></a>
                        <div class="card-body">
                          <center><button class="btn btn-primary block">Delete</button></center>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		    </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>