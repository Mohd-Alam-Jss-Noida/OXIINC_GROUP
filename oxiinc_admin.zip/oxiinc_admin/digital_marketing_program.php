<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Digital Marketing Program</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Digital Marketing Program</a>
                    </li>
                    <li class="breadcrumb-item active">Product List
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Checkbox For Allow</th>
                                <th>Product Name</th>
                                <th>Product Picture</th>
                                <th>Sub Category Name</th>
                                <th>Original Price</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1877</td>
                                <td><fieldset>
                                    <div class="checkbox">
                                        <input type="checkbox" class="checkbox-input" id="checkbox1">
                                        <label for="checkbox1"></label>
                                    </div>
                                    </fieldset>
                                </td>
                                <td>Mystica Tray 3 pcs Set ( Cello )</td>
                                <td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1539898750.png" width="135"></td>
                                <td>Kitchen Appliances</td>
                                <td>699</td>
                                <td>629</td>
                                <td>In Stock</td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                            <tr>
                                <td>1877</td>
                                <td><fieldset>
                                    <div class="checkbox">
                                        <input type="checkbox" class="checkbox-input" id="checkbox2">
                                        <label for="checkbox2"></label>
                                    </div>
                                    </fieldset>
                                </td>
                                <td>Mystica Tray 3 pcs Set ( Cello )</td>
                                <td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1539898750.png" width="135"></td>
                                <td>Kitchen Appliances</td>
                                <td>699</td>
                                <td>629</td>
                                <td>In Stock</td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                            <tr>
                                <td>1877</td>
                                <td><fieldset>
                                    <div class="checkbox">
                                        <input type="checkbox" class="checkbox-input" id="checkbox3">
                                        <label for="checkbox3"></label>
                                    </div>
                                    </fieldset>
                                </td>
                                <td>Mystica Tray 3 pcs Set ( Cello )</td>
                                <td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1539898750.png" width="135"></td>
                                <td>Kitchen Appliances</td>
                                <td>699</td>
                                <td>629</td>
                                <td>In Stock</td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                            <tr>
                                <td>1877</td>
                                <td><fieldset>
                                    <div class="checkbox">
                                        <input type="checkbox" class="checkbox-input" id="checkbox4">
                                        <label for="checkbox4"></label>
                                    </div>
                                    </fieldset>
                                </td>
                                <td>Mystica Tray 3 pcs Set ( Cello )</td>
                                <td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1539898750.png" width="135"></td>
                                <td>Kitchen Appliances</td>
                                <td>699</td>
                                <td>629</td>
                                <td>In Stock</td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                            <tr>
                                <td>1877</td>
                                <td><fieldset>
                                    <div class="checkbox">
                                        <input type="checkbox" class="checkbox-input" id="checkbox5">
                                        <label for="checkbox5"></label>
                                    </div>
                                    </fieldset>
                                </td>
                                <td>Mystica Tray 3 pcs Set ( Cello )</td>
                                <td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1539898750.png" width="135"></td>
                                <td>Kitchen Appliances</td>
                                <td>699</td>
                                <td>629</td>
                                <td>In Stock</td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                            <tr>
                                <td>1877</td>
                                <td><fieldset>
                                    <div class="checkbox">
                                        <input type="checkbox" class="checkbox-input" id="checkbox6">
                                        <label for="checkbox6"></label>
                                    </div>
                                    </fieldset>
                                </td>
                                <td>Mystica Tray 3 pcs Set ( Cello )</td>
                                <td><img src="https://www.oxiinc.in/uploads/Multiple_Picture/1539898750.png" width="135"></td>
                                <td>Kitchen Appliances</td>
                                <td>699</td>
                                <td>629</td>
                                <td>In Stock</td>
                                <td><span class="badge badge-success">Active</span></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>new