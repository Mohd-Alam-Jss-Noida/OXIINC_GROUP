<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Out Stock Products</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Stock Management</a>
                    </li>
                    <li class="breadcrumb-item active">Out Stock Products
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Sub Category Name</th>
                                <th>Original Prices</th>
                                <th>Prices</th>
                                <th>Stock</th>
                                <th>Total Stock</th>
                                <th>Status</th>
                                <th>Action(View)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                              <td>1</td>
                              <td>2527</td>
                              <td>Banarasi Kanjivaram Silk Saree</td>
                              <td>Ethnic Wear</td>
                              <td>2499</td>
                              <td>1899</td>
                              <td>In Stock</td>
                              <td>5</td>
                              <td><span class="badge badge-success">Active</span></td>
                              <td><button type="button" class="btn btn-outline-success round mr-1 mb-1" data-toggle="modal" data-target="#stock_management_in_stock">Edit</button></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>