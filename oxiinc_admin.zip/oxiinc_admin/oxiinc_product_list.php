<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Oxiinc Group Product List</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Oxiinc Product</a>
                    </li>
                    <li class="breadcrumb-item active">Oxiinc Group Product List
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr No</th>
                                <th>Product Id</th>
                                <th>Product Name</th>
                                <th>Sub Category Name</th>
                                <th>Original Price</th>
                                <th>Price</th>
                                <th>GST %</th>
                                <th>Shipping Charges</th>
                                <th>Stock</th>
                                <th>Total Stock</th>
                                <th>Rack No.</th>
                                <th>Status</th>
                                <th>Action(View)</th>
                                <th>Action(Upload)</th>
                                <th>Action(Edit)</th>
                                <th>Action(Delete)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>
                                  <fieldset>
                                    <div class="checkbox">
                                      <input type="checkbox" class="checkbox-input" id="checkbox2">
                                      <label for="checkbox2">2548</label>
                                    </div>
                                  </fieldset>
                                </td>
                                <td>Slopper Hide & City Trousers 6006/6</td>
                                <td>Top wear</td>
                                <td>2310</td>
                                <td>2310</td>
                                <td>0</td>
                                <td>0</td>
                                <td>In Stock</td>
                                <td>4</td>
                                <td>0</td>
                                <td><span class="badge">Active</span></td>
                                <td><a href="oxiinc_view_multiple_img.php"><i class="fa fa-eye fa_icon_size" aria-hidden="true">View Image</i></a></td>
                                <td><i class="fa fa-upload fa_icon_size" aria-hidden="true" data-toggle="modal" data-target="#oxiinc_product_upload">Upload Image</i></td>
                                <td><a href="oxiinc_product_details.php"><i class="fa fa-pencil fa_icon_size" aria-hidden="true"></i></a></td>
                                <td><i class="fa fa-trash fa_icon_size" aria-hidden="true"></i></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>