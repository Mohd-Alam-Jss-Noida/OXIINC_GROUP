<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Product Information</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Epanelist Customer Tracking</a>
                    </li>
                     <li class="breadcrumb-item"><a href="epanelist_total_ddc_order.php">Total DDC Orders</a>
                    </li>
                    <li class="breadcrumb-item active">Product Information
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                        <ul class="nav nav-tabs nav-justified" id="myTab2" role="tablist">
                            <li class="nav-item current">
                                <a class="nav-link active" id="dispatchment_confirm_justified" data-toggle="tab" href="#dispatchment_confirm" role="tab" aria-controls="dispatchment_confirm" aria-selected="false">Dispatchment Confirm</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="shipping_confirm_justified" data-toggle="tab" href="#shipping_confirm" role="tab" aria-controls="shipping_confirm" aria-selected="true">Shipping Confirm</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="order_intransist_justified" data-toggle="tab" href="#order_intransist" role="tab" aria-controls="order_intransist" aria-selected="false">Order Intransist</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="ddc_recieved_justified" data-toggle="tab" href="#ddc_recieved" role="tab" aria-controls="ddc_recieved" aria-selected="false">DDC Received</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="delivered_justified" data-toggle="tab" href="#delivered" role="tab" aria-controls="delivered" aria-selected="false">Delivered</a>
                            </li>
                        </ul>
                        
                        <div class="tab-content pt-1">
                          <div class="tab-pane active" id="dispatchment_confirm" role="tabpanel" aria-labelledby="dispatchment_confirm_justified">
                            <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Category Id</th>
                                        <th>Customer Name</th>
                                        <th>Contact Number</th>
                                        <th>Product Name</th>
                                        <th>Tracking Id</th>
                                        <th>Prices</th>
                                        <th>Quantity</th>
                                        <th>Size</th>
                                        <th>Shopping Wallet</th>
                                        <th>Shopping Address</th>
                                        <th>Shopping City</th>
                                        <th>Shopping State</th>
                                        <th>Shopping Pincode</th>
                                        <th>Order Date Time</th>
                                        <th>Order Confirmation</th>
                                        <th>Order Packed Confirmation</th>
                                        <th>Shipped Confirmation</th>
                                        <th>Intransist Confirmation</th>
                                        <th>Status</th>
                                        <th>Delete</th>
                                        <th>Payment Method</th>
                                        <th>Dispatchmnt_confirmation_info</th>
                                        <th>Shipping_confirmation_info</th>
                                        <th>Intransist_confirmation_info</th>
                                        <th>Out_for_delivery_confirmation_info</th>
                                        <th>Delivered_confirmation_info</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <td>1</td>
                                    <td>2630</td>
                                    <td>Sonu Kumar</td>
                                    <td>9113729494</td>
                                    <td>Vande Mataram Saree OX-4808</td>
                                    <td><a href="#">8f889573d0744bf556c9</a></td>
                                    <td>716</td>
                                    <td>1</td>
                                    <td>Free_Size</td>
                                    <td>150.36</td>
                                    <td>Begampur</td>
                                    <td>Nalnda</td>
                                    <td>Bihar</td>
                                    <td>803111</td>
                                    <td>2020-Oct-21</td>
                                    <td><span class="badge">Order Confirm</span></td>
                                    <td>Dispatchment Confirm</td>
                                    <td>Shipped Confirm</td>
                                    <td>In Transit Confirm</td>
                                    <td><a href="#">Active</a></td>
                                    <td><button class="btn btn-danger">Delete Order</button></td>
                                    <td>DIGITAL WALLET</td>
                                    <td>"Dear Customer, Today, Your order has been packed."</td>
                                    <td>"Dear Customer, Your order has been shipped via DTDC Courier on 22-10-2020."</td>
                                    <td>"Dear Customer, Your order status is 'In Transit' on DTDC Courier on 26-10-2020."</td>
                                    <td>"Dear Customer, Your order status is in 'Out for Delivery' on DTDC Courier on 27-10-2020."</td>
                                    <td>"Dear Customer, Your order has been delivered to you via DTDC Courier on 27-10-2020."</td>
                                </tbody>
                            </table>
                          </div>
                          <div class="tab-pane" id="shipping_confirm" role="tabpanel" aria-labelledby="shipping_confirm_justified">
                            <table id="example1" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Sr.No</th>
                                        <th>Category Id</th>
                                        <th>Customer Name</th>
                                        <th>Contact Number</th>
                                        <th>Product Name</th>
                                        <th>Tracking Id</th>
                                        <th>Prices</th>
                                        <th>Quantity</th>
                                        <th>Size</th>
                                        <th>Shopping Wallet</th>
                                        <th>Shopping Address</th>
                                        <th>Shopping City</th>
                                        <th>Shopping State</th>
                                        <th>Shopping Pincode</th>
                                        <th>Order Date Time</th>
                                        <th>Order Confirmation</th>
                                        <th>Order Packed Confirmation</th>
                                        <th>Shipped Confirmation</th>
                                        <th>Intransist Confirmation</th>
                                        <th>Status</th>
                                        <th>Delete</th>
                                        <th>Payment Method</th>
                                        <th>Dispatchmnt_confirmation_info</th>
                                        <th>Shipping_confirmation_info</th>
                                        <th>Intransist_confirmation_info</th>
                                        <th>Out_for_delivery_confirmation_info</th>
                                        <th>Delivered_confirmation_info</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <td>1</td>
                                    <td>2630</td>
                                    <td>Sonu Kumar</td>
                                    <td>9113729494</td>
                                    <td>Vande Mataram Saree OX-4808</td>
                                    <td><a href="#">8f889573d0744bf556c9</a></td>
                                    <td>716</td>
                                    <td>1</td>
                                    <td>Free_Size</td>
                                    <td>150.36</td>
                                    <td>Begampur</td>
                                    <td>Nalnda</td>
                                    <td>Bihar</td>
                                    <td>803111</td>
                                    <td>2020-Oct-21</td>
                                    <td><span class="badge">Order Confirm</span></td>
                                    <td>Dispatchment Confirm</td>
                                    <td>Shipped Confirm</td>
                                    <td>In Transit Confirm</td>
                                    <td><a href="#">Active</a></td>
                                    <td><button class="btn btn-danger">Delete Order</button></td>
                                    <td>DIGITAL WALLET</td>
                                    <td>"Dear Customer, Today, Your order has been packed."</td>
                                    <td>"Dear Customer, Your order has been shipped via DTDC Courier on 22-10-2020."</td>
                                    <td>"Dear Customer, Your order status is 'In Transit' on DTDC Courier on 26-10-2020."</td>
                                    <td>"Dear Customer, Your order status is in 'Out for Delivery' on DTDC Courier on 27-10-2020."</td>
                                    <td>"Dear Customer, Your order has been delivered to you via DTDC Courier on 27-10-2020."</td>
                                </tbody>
                            </table>
                          </div>
                          <div class="tab-pane" id="order_intransist" role="tabpanel" aria-labelledby="order_intransist_justified">
                            <p></p>
                          </div>
                          <div class="tab-pane" id="ddc_recieved" role="tabpanel" aria-labelledby="ddc_recieved_justified">
                            <p> </p>
                          </div>
                          <div class="tab-pane" id="delivered" role="tabpanel" aria-labelledby="delivered_justified">
                            <p></p>
                          </div>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

   

<?php include 'footer.php';?>