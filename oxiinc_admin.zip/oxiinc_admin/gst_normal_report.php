<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Total GST Report</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">GST Report</a>
                    </li>
                    <li class="breadcrumb-item active">Total GST Report
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
           <div class="row" id="table-responsive">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4 class="card-title">Total Order Table</h4>
                  </div>
                  <div class="card-content">
                    <div class="card-body">
                        <form class="form">
                          <div class="form-body">
                            <div class="row">
                              <div class="col-12 col-md-2"></div>
                              <div class="col-12 col-md-3">
                                <fieldset class="form-label-group position-relative has-icon-left">
                                    <input type="text" class="form-control pickadate-months-year" placeholder="Select Date">
                                    <div class="form-control-position">
                                      <i class='bx bx-calendar'></i>
                                    </div>
                                  </fieldset>    
                               </div>
                               <div class="col-12 col-md-3">
                                <fieldset class="form-label-group position-relative has-icon-left">
                                    <input type="text" class="form-control pickadate-months-year" placeholder="Select Date">
                                    <div class="form-control-position">
                                      <i class='bx bx-calendar'></i>
                                    </div>
                                  </fieldset>    
                               </div>
                               <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <button type="button" class="btn btn-outline-light mr-1 mb-1">Search</button>
                                </div>
                              </div>
                              <div class="col-12 col-md-2"></div>
                            </div>
                          </div>
                        </form>
                    </div>
                    <table class="table table-responsive mb-0 table-bordered">
                      <thead>
                        <tr>
                          <th scope="col">Sr No</th>
                          <th scope="col">Customer Name</th>
                          <th scope="col">Customer Contact No.</th>
                          <th scope="col">Invoice No</th>
                          <th scope="col">Tracking Id</th>
                          <th scope="col">Taxable Amount</th>
                          <th scope="col">SGST Percentage</th>
                          <th scope="col">SGST Amt(rs) Rate</th>
                          <th scope="col">CGST Percentage</th>
                          <th scope="col">CGST Amt(rs) Rate</th>
                          <th scope="col">IGST Percentage</th>
                          <th scope="col">IGST Amt(rs) Rate</th>
                          <th scope="col">GST(in Rs)</th>
                          <th scope="col">Amt (Inc.Tax)</th>
                          <th scope="col">State</th>
                          <th scope="col">Created Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>NAGENDRA</td>
                          <td>9807814899</td>
                          <td>d4583529d6989ef0aa8a</td>
                          <td>3100</td>
                          <td>6%</td>
                          <td>232.5</td>
                          <td>6%</td>
                          <td>518.7</td>
                          <td>0%</td>
                          <td>0</td>
                          <td>219</td>
                          <td>50</td>
                          <td>3565</td>
                          <td>Maharashtra</td>
                          <td>2020-Nov-09</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>