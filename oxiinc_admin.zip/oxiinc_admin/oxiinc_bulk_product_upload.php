<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Bulk Product Upload</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Oxiinc Product</a>
                    </li>
                    <li class="breadcrumb-item active">Bulk Product Upload
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row table-responsive">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table class="table dt-responsive nowrap" style="width:100%">
                        <tbody>
                          <tr>
                            <td>
                              <div class="col-md-12 form-group">
                                <fieldset class="form-label-group">
                                  <select class="form-control" id="basicSelect">
                                    <option>Select Category </option>
                                    <option>Mens</option>
                                    <option>Womens</option>
                                    <option>Electronics</option>
                                  </select>
                                </fieldset>
                              </div>
                            </td> 
                            <td>
                              <div class="col-md-12 form-group">
                                <fieldset class="form-label-group">
                                  <select class="form-control" id="basicSelect">
                                    <option>Select SubCategory </option>
                                    <option>Mens</option>
                                    <option>Womens</option>
                                    <option>Electronics</option>
                                  </select>
                                </fieldset>
                              </div>
                            </td>
                            <td>
                              <div class="col-md-12 form-group">
                                <fieldset class="form-label-group">
                                  <select class="form-control" id="basicSelect">
                                    <option>Select SubCategory </option>
                                    <option>Mens</option>
                                    <option>Womens</option>
                                    <option>Electronics</option>
                                  </select>
                                </fieldset>
                              </div>
                            </td>
                          </tr> 
                        </tbody>
                      </table>
                      <table class="table table-striped table-bordered table-responsive mb-0 nowrap bulkproduct_upload" style="width:100%">
                        <thead>
                            <tr>
                                <th>Product Images</th>
                                <th>Product Name</th>
                                <th>Product MRP</th>
                                <th>Product Price</th>
                                <th>Short Info</th>
                                <th>Long Info</th>
                                <th>GST Percentage</th>
                                <th>Shipping Charges</th>
                                <th>Product Size & Size Wise Stock</th>
                                <th>Action</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody id="mainbulkproduct">
                            <tr>
                              <td>
                                <input type="file">
                              </td>
                              <td><input type="text" id="Product_Name" class="form-control" placeholder="Product Name"></td>
                              <td><input type="number" id="Product_MRP" class="form-control" placeholder="Product MRP"></td>
                              <td><input type="number" id="Price" class="form-control" placeholder="Price"></td>
                              <td><textarea class="form-control" id="label-textarea" rows="2" placeholder="Short Info"></textarea></td>
                              <td><textarea class="form-control" id="label-textarea" rows="2" placeholder="Long Info"></textarea></td>
                              <td><input type="text" id="GST_Percentage" class="form-control" placeholder="GST Percentage"></td>
                              <td><input type="text" id="Shipping_Charges" class="form-control" placeholder="Shipping Charges"></td>
                              <td>
                                <fieldset>
                                  <select class="form-control" id="basicSelect">
                                    <option>Select Category </option>
                                    <option>Mens</option>
                                    <option>Womens</option>
                                    <option>Electronics</option>
                                  </select>
                                </fieldset>
                              </td>
                              <td>
                                <table class="table bulkproduct_upload">
                                  <tbody id="bulkproduct">
                                    <tr>
                                      <td><input type="text" id="Product_Size" class="form-control" placeholder="Product Size"></td> 
                                      <td><input type="text" id="Size_Wise_Stock" class="form-control" placeholder="Size Wise Stock"></td>
                                      <td><button type="button" id="bulkproductAdd" class="btn btn-icon rounded-circle btn-light-primary btn_add_del mr-1 mb-1"><i class="fa fa-plus" aria-hidden="true"></i></button></td>
                                    </tr> 
                                  </tbody>
                                </table>
                              </td>
                              <td><button type="button" id="mainbulkproductAdd" class="btn btn-icon rounded-circle btn-light-primary btn_add_del mr-1 mb-1"><i class="fa fa-plus" aria-hidden="true"></i></button>
                              </td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>