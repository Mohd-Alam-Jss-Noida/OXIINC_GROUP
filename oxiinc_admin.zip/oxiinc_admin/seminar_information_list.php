<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Seminar Information List</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Seminar</a>
                    </li>
                    <li class="breadcrumb-item active">Seminar Information List
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <form class="form">
                        <div class="form-body">
                          <div class="row">
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Seminar_Name" class="form-control" placeholder="Seminar Name" name="Seminar_Name">
                                <label for="Seminar_Name">Seminar Name</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <fieldset class="form-label-group">
                                <textarea class="form-control" id="Seminar_address" rows="2" placeholder="Seminar address"></textarea>
                                <label for="Seminar_address">Seminar address</label>
                              </fieldset>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="number" id="Seminar_Price" class="form-control" placeholder="Seminar Price" name="Seminar_Price">
                                <label for="Seminar_Price">Seminar Price</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <input type="text" id="Seminar_City" class="form-control" placeholder="Seminar City" name="Seminar_City">
                                <label for="Seminar_City">Seminar City</label>
                              </div>
                            </div>
                            <div class="col-md-6 col-12">
                              <div class="form-label-group">
                                <fieldset class="form-group position-relative has-icon-left">
                                  <input type="text" class="form-control pickadate-months-year" placeholder="Select Date">
                                  <div class="form-control-position">
                                    <i class='bx bx-calendar'></i>
                                  </div>
                                </fieldset>
                              </div>
                            </div>
                            <div class="col-12 d-flex justify-content-end">
                              <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                              <button type="reset" class="btn btn-danger mr-1 mb-1">Clear Form</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>