<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0"> Epanelist Post Data</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Epanelist Data</a>
                    </li>
                    <li class="breadcrumb-item active">Epanelist Post Data
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Sr No.</th>
                                <th>Dispatch Date</th>
                                <th>User Name</th>
                                <th>Name</th>
                                <th>Mobile No</th>
                                <th>Panel QTY</th>
                                <th>Product Name</th>
                                <th>Product AMT</th>
                                <th>Total AMT</th>
                                <th>Size</th>
                                <th>Product QTY</th>
                                <th>Tracking No</th>
                                <th>Delivery Date</th>
                                <th>Charges Bill AMT</th>
                              </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>2020-Nov-28</td>
                            <td>32758898</td>
                            <td>Binod Debbarma</td>
                            <td>8837287629</td>
                            <td>NA</td>
                            <td>Men Checkered Casual Regular Shirt OX-1071-B</td>
                            <td>960</td>
                            <td>1105.2</td>
                            <td>M</td>
                            <td>1</td>
                            <td></td>
                            <td></td>
                            <td></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>