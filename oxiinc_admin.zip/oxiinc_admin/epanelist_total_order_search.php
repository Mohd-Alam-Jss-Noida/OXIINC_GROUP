<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">List / Information of Customer</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Epanelist Customer Tracking</a>
                    </li>
                    <li class="breadcrumb-item active">List / Information of Customer
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
           <div class="row" id="table-responsive">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4 class="card-title">List / Information of Customer</h4>
                  </div>
                  <div class="card-content">
                    <div class="card-body">
                        <form class="form">
                          <div class="form-body">
                            <div class="row">
                              <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="text" id="Enter_Customer_Name" class="form-control" placeholder="Enter Customer Name">
                                  <label for="Enter_Customer_Name">Enter Customer Name</label>
                                </div>
                              </div>
                              <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="text" id="Enter_City" class="form-control" placeholder="Enter City">
                                  <label for="Enter_City">Enter City</label>
                                </div>
                              </div>
                              <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="text" id="Enter_State" class="form-control" placeholder="Enter State">
                                  <label for="Enter_State">Enter State</label>
                                </div>
                              </div>
                              <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="number" id="Enter_Pincode" class="form-control" placeholder="Enter Pincode">
                                  <label for="Enter_Pincode">Enter Pincode</label>
                                </div>
                              </div>
                              <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="text" id="Enter_Product_Name" class="form-control" placeholder="Enter Product Name">
                                  <label for="Enter_Product_Name">Enter Product Name</label>
                                </div>
                              </div>
                              <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="text" id="Enter_Trasaction_Id" class="form-control" placeholder="Enter Trasaction Id">
                                  <label for="Enter_Trasaction_Id">Enter Trasaction Id</label>
                                </div>
                              </div>
                              <div class="col-12 col-md-3">
                                <fieldset class="form-label-group position-relative has-icon-left">
                                    <input type="text" class="form-control pickadate-months-year" placeholder="Select Date">
                                    <div class="form-control-position">
                                      <i class='bx bx-calendar'></i>
                                    </div>
                                  </fieldset>    
                               </div>
                               <div class="col-12 col-md-3">
                                <fieldset class="form-label-group position-relative has-icon-left">
                                    <input type="text" class="form-control pickadate-months-year" placeholder="Select Date">
                                    <div class="form-control-position">
                                      <i class='bx bx-calendar'></i>
                                    </div>
                                  </fieldset>    
                               </div>
                               <div class="col-12 col-md-2">
                                <div class="form-label-group">
                                  <input type="number" id="Quantity" class="form-control" placeholder="Quantity">
                                  <label for="Quantity">Quantity</label>
                                </div>
                              </div>
                            </div>
                          </div>
                        </form>
                       <!--  <h5 class="card-title mt-2">List / Information of Customer</h5> -->
                    </div>
                    <table class="table table-responsive mb-0">
                      <thead>
                        <tr>
                          <th scope="col">Sr No</th>
                          <th scope="col">Category Id</th>
                          <th scope="col">Customer Name</th>
                          <th scope="col">Customer Contact No.</th>
                          <th scope="col">Product Name</th>
                          <th scope="col">Tracking Id</th>
                          <th scope="col">Prices</th>
                          <th scope="col">Quantity</th>
                          <th scope="col">Size</th>
                          <th scope="col">Shopping Wallet</th>
                          <th scope="col">Shopping Address</th>
                          <th scope="col">Shopping City</th>
                          <th scope="col">Shopping State</th>
                          <th scope="col">Shopping Pincode</th>
                          <th scope="col">Order Date Time</th>
                          <th scope="col">Order Confirmation</th>
                          <th scope="col">Order Packed Confirmation</th>
                          <th scope="col">Shipped Confirmation</th>
                          <th scope="col">In Transist Confirmation</th>
                          <th scope="col">Status</th>
                          <th scope="col">Delete</th>
                          <th scope="col">Payment Method</th>
                          <th scope="col">Dispatchment Confirmation Info</th>
                          <th scope="col">Shipping_confirmation_info</th>
                          <th scope="col">In Transist Confirmation Info</th>
                          <th scope="col">Out For Delivery Confirmation Info</th>
                          <th scope="col">Dleiverd Confirmation Info</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>3174</td>
                          <td>Suman Chauhan </td>
                          <td>9807814899</td>
                          <td>Dvaio EXILITY CL463 MADDY BASS UNIVERSAL QUALITY EARPHONE Wired Headset (Black, In the Ear)</td>
                          <td><a href="#">7d18e25afa1a377d9d9e</a></td>
                          <td>518.7</td>
                          <td>1</td>
                          <td>BLACK</td>
                          <td>219.872</td>
                          <td>Ramleela maidan Near smriti stambh Krishna Technical Institute deoria</td>
                          <td>Deoria</td>
                          <td>Uttar Pradesh</td>
                          <td>274001</td>
                          <td>2020-Nov-09</td>
                          <td><span class="badge">Order Confirm</span></td>
                          <td>Dispatchment Confirm</td>
                          <td>Shipped Confirm</td>
                          <td>In Transit Confirm</td>
                          <td><a href="#">Active</a></td>
                          <td><i class="fa fa-trash fa_icon_size" aria-hidden="true"></i></td>
                          <td>DIGITAL WALLET</td>
                          <td><a href="#">order packed</a></td>
                          <td><a href="#">your order ship through dtdc express ltd https://www.dtdc.in/tracking/tracking_results.asp tracking code: K26023391</a></td>
                          <td><a href="#">in transit</a></td>
                          <td><a href="#">out for delivery</a></td>
                          <td><a href="#">"Dear Customer, Your order has been delivered to you via Trackon Courier [Tracking ID = 500118178580] on 13-11-2020."</a></td>
                        </tr>
                    </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>