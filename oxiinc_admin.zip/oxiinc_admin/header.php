<!-- BEGIN: Header-->
    <div class="header-navbar-shadow"></div>
    <nav class="header-navbar main-header-navbar navbar-expand-lg navbar navbar-with-menu fixed-top ">
      <div class="navbar-wrapper">
        <div class="navbar-container content">
          <div class="navbar-collapse" id="navbar-mobile">
            <div class="mr-auto float-left bookmark-wrapper d-flex align-items-center">
              <ul class="nav navbar-nav">
                <li class="nav-item mobile-menu d-xl-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="fa fa-bars" aria-hidden="true"></i></a></li>
              </ul>
              
            </div>
            <ul class="nav navbar-nav float-right">
              <li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                  <div class="user-nav d-sm-flex d-none"><span class="user-name">Pankaj Chalke</span><!-- <span class="user-status text-muted">Available</span> --></div><span><img class="round" src="app-assets/images/portrait/small/avatar-s-11.jpg" alt="avatar" height="40" width="40"></span></a>
                <div class="dropdown-menu dropdown-menu-right pb-0"><a class="dropdown-item" href="edit_profile.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i>&nbsp;&nbsp; Edit Profile</a>
                  <div class="dropdown-divider mb-0"></div><a class="dropdown-item" href="#"><i class="fa fa-sign-out" aria-hidden="true"></i>&nbsp;&nbsp; Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
    <!-- END: Header-->


    <!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
      <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
          <li class="nav-item mr-auto"><a class="navbar-brand" href="index.php">
              <div class="brand-logo"><center><img class="logo" src="app-assets/images/logo/logo.png"/></center></div>
              <!-- <h2 class="brand-text mb-0">Frest</h2> --></a></li>
          <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle" data-toggle="collapse"><i class="bx bx-x d-block d-xl-none font-medium-4 primary"></i><i class="toggle-icon bx bx-disc font-medium-4 d-none d-xl-block primary" data-ticon="bx-disc"></i></a></li>
        </ul>
      </div>
      <div class="shadow-bottom"></div>
      <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation" data-icon-style="lines">
          <li class=" navigation-header"><span>Menus</span></li>
          <li class=" nav-item"><a href="index.php"><i class="fa fa-desktop" aria-hidden="true"></i><span class="menu-title" data-i18n="Dashboard">Dashboard</span></a></li>

          <li class=" nav-item"><a href="add_user_dept.php"><i class="fa fa-building-o" aria-hidden="true"></i><span class="menu-title">Create Department</span></a>
            <ul class="menu-content">
              <li><a href="add_user_dept.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add user Department</span></a>
              </li>
              <li><a href="add_user_role.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add User Role</span></a>
              </li>
              <li><a href="list_of_dept.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Departments</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user" aria-hidden="true"></i><span class="menu-title">Create Customer</span></a>
            <ul class="menu-content">
              <li><a href="add_new_customer.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add New Customer</span></a>
              </li>
              <li><a href="list_of_customer.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Customer</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user" aria-hidden="true"></i><span class="menu-title">User Tracking Info</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of User Tracking Info</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-cog" aria-hidden="true"></i><span class="menu-title">Home Page Setting</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Deal Of The week</span></a>
                <ul class="menu-content">
                  <li><a href="deal_of_week_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add</span></a>
                  </li>
                  <li><a href="deal_of_week_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Top Categories</span></a>
                <ul class="menu-content">
                  <li><a href="top_category_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add</span></a>
                  </li>
                  <li><a href="top_category_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">New Arrivals</span></a>
                <ul class="menu-content">
                  <li><a href="new_arrivals_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add</span></a>
                  </li>
                  <li><a href="new_arrivals_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Latest Items</span></a>
                <ul class="menu-content">
                  <li><a href="latest_items_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add</span></a>
                  </li>
                  <li><a href="latest_items_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Best Sellers</span></a>
                <ul class="menu-content">
                  <li><a href="best_sellers_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add</span></a>
                  </li>
                  <li><a href="best_sellers_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user" aria-hidden="true"></i><span class="menu-title">Reseller Admin</span></a>
            <ul class="menu-content">
              <li><a href="https://www.oxiinc.in/Slider/reseller_dashboard"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Reseller Admin</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-industry" aria-hidden="true"></i><span class="menu-title">Reseller</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Reseller Account Approval</span></a>
                <ul class="menu-content">
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Pending Reseller</span></a>
                  </li>
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Approved Reseller</span></a>
                  </li>
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Rejected Reseller</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Reseller Product Approval</span></a>
                <ul class="menu-content">
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Pending Reseller</span></a>
                  </li>
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Approved Reseller</span></a>
                  </li>
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Rejected Reseller</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Reseller Payment</span></a>
                <ul class="menu-content">
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Pending Payout</span></a>
                  </li>
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Approved Payout</span></a>
                  </li>
                  <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Rejected Payout</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-product-hunt" aria-hidden="true"></i><span class="menu-title">Product Markup</span></a>
            <ul class="menu-content">
              <li><a href="product_markup_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Product markup</span></a>
              </li>
              <li><a href="product_markup_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Product markup</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-area-chart" aria-hidden="true"></i><span class="menu-title">Chart</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Order/Cancel Report Chart</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-credit-card" aria-hidden="true"></i><span class="menu-title">Payzen Payment Gateway</span></a>
            <ul class="menu-content">
              <li><a href="payzen_payment_verification.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Payzen Payment Gateway Order Status</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span class="menu-title">Digital Marketing Program</span></a>
            <ul class="menu-content">
              <li><a href="digital_marketing_program.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Digital Marketing Program</span></a>
              </li>
              <li><a href="list_allow_digital_marketing_program.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Allow Product For Digital Marketing</span></a>
              </li>
              <li><a href="replace_system.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Replace System</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-gift" aria-hidden="true"></i><span class="menu-title">Gift</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Gift Category</span></a>
                <ul class="menu-content">
                  <li><a href="add_gift_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Gift Category</span></a>
                  </li>
                  <li><a href="list_gift_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Gift Category</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Gift Sub-Category</span></a>
                <ul class="menu-content">
                  <li><a href="add_gift_sub_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Sub-Gift Category</span></a>
                  </li>
                  <li><a href="list_gift_sub_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Sub-Gift Category</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product Gift</span></a>
                <ul class="menu-content">
                  <li><a href="product_gift_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Gift Product</span></a>
                  </li>
                  <li><a href="product_gift_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Product's in Gift</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-car" aria-hidden="true"></i><span class="menu-title">Car</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Car Report</span></a>
                <ul class="menu-content">
                  <li><a href="car_report.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Car Report</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-life-ring" aria-hidden="true"></i><span class="menu-title">Epanelist Customer Tracking</span></a>
            <ul class="menu-content">
              <li><a href="epanelist_total_order_search.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Total Order Search<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
              </li>
              <li><a href="epanelist_total_order_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Total Order<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a></li>
              <li><a href="epanelist_total_ddc_order.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Total DDC Orders</span></a>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Order Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_total_ddc_order_dispatchment.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Order Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Order Packed Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_total_order_pack_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Order Packed Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Shipped Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_shipped_confirm_table.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Shipped Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">In Transist Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_intransist_confirm_table.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of In Transist Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Out For Deliverd Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_out_for_delivered_confirm_table.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Out For Deliverd Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Deliverd Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_delivered_table.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Deliverd Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">On Hold<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_order_confirm_table.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of On Hold</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Remain Data<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_list_of_remain_data.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Remain Data</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Return Order<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="epanelist_list_return_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Return Order</span></a>
                  </li>
                  <li><a href="epanelist_list_return_product_approved.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Return Ordered Approved</span></a>
                  </li>
                  <li><a href="epanelist_list_return_product_rejected.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Return Ordered Rejected</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-houzz" aria-hidden="true"></i><span class="menu-title">Stock Management</span></a>
            <ul class="menu-content">
              <li><a href="stock_management_in_stock_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">In Stock Product</span></a>
              </li>
              <li><a href="stock_management_out_stock_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Out Stock Product</span></a>
              </li>
              <li><a href="stock_management_stock_order_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Stock And Order</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user-circle-o" aria-hidden="true"></i><span class="menu-title">Normal Customer Tracking</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Total Order<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_total_order.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Total Orders Confirmation</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Order Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_order_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Order Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Order Packed Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_order_packed_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Order Packed Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Shipped Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_shipped_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Shipped Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">In Transist Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_intransist_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of In Transist Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Out For Delivered Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_out_delivered_confirm.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Out For Delivered Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Delivered Confirm<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_delivered.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Delivered Confirm</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Cancel Product<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_list_cancel_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Cancel Product</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Return Product<div class="badge badge-pill badge-success mr-1 mb-1">300</div></span></a>
                <ul class="menu-content">
                  <li><a href="normal_customer_list_return.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Return Product</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-tasks" aria-hidden="true"></i><span class="menu-title">Seminar</span></a>
            <ul class="menu-content">
              <li><a href="seminar_information_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Seminar Information List</span></a>
              </li>
              <li><a href="seminar_list_tikit_book_customer.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Ticket Book Customer</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-file" aria-hidden="true"></i><span class="menu-title">GST Report</span></a>
            <ul class="menu-content">
              <li><a href="gst_normal_report.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Total GST Normal Report</span></a>
              </li>
              <li><a href="gst_epanelist_report.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Total GST Epanelist Report</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-tag" aria-hidden="true"></i><span class="menu-title">Promo Code</span></a>
            <ul class="menu-content">
              <li><a href="add_promo_code.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Promo Code</span></a>
              </li>
              <li><a href="list_promo_code.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Promo Code</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-paypal" aria-hidden="true"></i><span class="menu-title">Enpay</span></a>
            <ul class="menu-content">
              <li><a href="list_customer_enpay.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Customer For Enpay</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-heart" aria-hidden="true"></i><span class="menu-title">Wishlist</span></a>
            <ul class="menu-content">
              <li><a href="wishlist.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Wishlist</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-area-chart" aria-hidden="true"></i><span class="menu-title">Home Page Header</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Header Banner</span></a>
                <ul class="menu-content">
                  <li><a href="header_banner_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Header Banner</span></a>
                  </li>
                  <li><a href="header_banner_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Header Banner</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product Category Banner</span></a>
                <ul class="menu-content">
                  <li><a href="product_category_banner_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Product Category</span></a>
                  </li>
                  <li><a href="product_category_banner_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Product Category</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product Sub Category Banner</span></a>
                <ul class="menu-content">
                  <li><a href="product_sub_category_banner_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Product Sub Category</span></a>
                  </li>
                  <li><a href="product_sub_category_banner_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Product Sub Category</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Header Advertise Banner</span></a>
                <ul class="menu-content">
                  <li><a href="advertisement_banner_add.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Header Advertise Banner</span></a>
                  </li>
                  <li><a href="advertisement_banner_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Header Advertise Banner</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-area-chart" aria-hidden="true"></i><span class="menu-title">Product Home Page</span></a>
            <ul class="menu-content">
              <li><a href="short_category_name.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Short Category Name</span></a>
              </li>
              <li><a href="add_home_page_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Home Page Product</span></a>
              </li>
              <li><a href="short_category_name_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Short Category Name List</span></a>
              </li>
              <li><a href="home_page_products_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Home Page Product List</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-handshake-o" aria-hidden="true"></i><span class="menu-title">New Deal Of The Day</span></a>
            <ul class="menu-content">
              <li><a href="new_deal_day_short_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Short Category Name</span></a>
              </li>
              <li><a href="new_deal_day_add_home_page_product.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Home Page Product</span></a>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Short Category Name List</span></a>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Home Page Product List</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-list-alt" aria-hidden="true"></i><span class="menu-title">Category</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Header Product Category</span></a>
                <ul class="menu-content">
                  <li><a href="add_header_product_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Header Product Category</span></a>
                  </li>
                  <li><a href="list_header_product_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Header Product Category List</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Sub Category</span></a>
                <ul class="menu-content">
                  <li><a href="add_sub_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Sub Category</span></a>
                  </li>
                  <li><a href="list_sub_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Sub Category</span></a>
                  </li>
                </ul>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product  Category </span></a>
                <ul class="menu-content">
                  <li><a href="add_product_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Add Product Category</span></a>
                  </li>
                  <li><a href="list_product_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Product Category</span></a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-product-hunt" aria-hidden="true"></i><span class="menu-title">Oxiinc Product</span></a>
            <ul class="menu-content">
              <li><a href="oxiinc_product_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Oxiinc Product List</span></a>
              </li>
               <li><a href="oxiinc_single_product_upload.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Single Product Upload</span></a>
              </li>
               <li><a href="oxiinc_bulk_product_upload.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Bulk Product Upload</span></a>
              </li>
               <li><a href="oxiinc_excel_bulk_product_upload.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Excel Bulk Product Upload</span></a>
              </li>
              <li><a href="oxiinc_product_price_update.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product Price Update</span></a>
              </li>
              <li><a href="oxiinc_product_stock_update.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product Stock Update</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-product-hunt" aria-hidden="true"></i><span class="menu-title">Reseller Product</span></a>
            <ul class="menu-content">
              <li><a href="reseller_product_list.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Reseller Product List</span></a></li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-product-hunt" aria-hidden="true"></i><span class="menu-title">Product Allow To Normal Of Epanelist</span></a>
            <ul class="menu-content">
              <li><a href="transfer_product_any_normal_category.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Transfer a Product To Any Other Category By Bulk</span></a>
              </li>
               <li><a href="define_product_normal_epanelist.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Define Product as a Epanelist Or Normal</span></a>
              </li>
               <li><a href="transfer_product_normal_epanelist.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Transfer Product To Normal Category Or Epanelist </span></a>
              </li>
               <li><a href="define_product_epanelist.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Define Product As a Epanelist</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-first-order" aria-hidden="true"></i><span class="menu-title">Orders</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Billing Order</span></a>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Product List</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user-plus" aria-hidden="true"></i><span class="menu-title">Members</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Create New Members</span></a>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">List Of Members</span></a>
              </li>
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Members Documents</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user-circle-o" aria-hidden="true"></i><span class="menu-title">My Account</span></a>
            <ul class="menu-content">
              <li><a href="#"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Wallet</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-database" aria-hidden="true"></i><span class="menu-title">Epanelist Data</span></a>
            <ul class="menu-content">
              <li><a href="epanelist_post_data.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Epanelist Data</span></a>
              </li>
              <li><a href="epanelist_post_office_data.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Epanelist Post Office Data</span></a>
              </li>
            </ul>
          </li>
          <li class=" nav-item"><a href="#"><i class="fa fa-user-plus" aria-hidden="true"></i><span class="menu-title">Normal User Data</span></a>
            <ul class="menu-content">
              <li><a href="normal_user_data.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Normal Data</span></a>
              </li>
              <li><a href="normal_user_post_office_data.php"><i class="bx bx-right-arrow-alt"></i><span class="menu-item">Normal Post Office Data</span></a>
              </li>
            </ul>
          </li>

          
        </ul>
      </div>
    </div>
    <!-- END: Main Menu-->