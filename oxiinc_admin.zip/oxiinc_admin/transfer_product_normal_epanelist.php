<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0"> Transfer A Product As a E-Panelist Or Normal</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Product Allow To Normal Epanelist</a>
                    </li>
                    <li class="breadcrumb-item active">Transfer A Product As a E-Panelist Or Normal
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Product Id</th>
                                <th>Allow Id</th>
                                <th>Category Name</th>
                                <th>Sub Category Name</th>
                                <th>Product Category Name</th>
                                <th>Product Name</th>
                                <th>Original Price</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                              </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>71</td>
                            <td><fieldset>
                                  <div class="checkbox">
                                    <input type="checkbox" class="checkbox-input" id="checkbox2">
                                    <label for="checkbox2">2548</label>
                                  </div>
                                </fieldset>
                            </td>
                            <td>Mens</td>
                            <td>Footwear</td>
                            <td>MEN</td>
                            <td>Casual Shoes</td>
                            <td>8125</td>
                            <td>7625</td>
                            <td>Out of Stock</td>
                            <td><span class="badge">Active</span></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
    <!-- END: Content-->

    

<?php include 'footer.php';?>