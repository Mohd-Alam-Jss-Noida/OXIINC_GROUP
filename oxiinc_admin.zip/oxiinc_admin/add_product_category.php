<?php include 'head.php';?>

<?php include 'header.php';?>

<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-12 mb-2 mt-1">
            <div class="row breadcrumbs-top">
              <div class="col-12">
                <h3 class="content-header-title float-left pr-1 mb-0">Sub Category Add</h3>
                <div class="breadcrumb-wrapper col-12">
                  <ol class="breadcrumb p-0 mb-0">
                    <li class="breadcrumb-item"><a href="index.php"><i class="fa fa-home" aria-hidden="true" style="font-size: 20px;"></i></a>
                    </li>
                    <li class="breadcrumb-item"><a href="#">Category</a>
                    </li>
                    <li class="breadcrumb-item active">Sub Category Add
                    </li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="content-body">
          <section id="multiple-column-form">
            <div class="row match-height">
              <div class="col-12">
                <div class="card">
                  <div class="card-content">
                    <div class="card-body">
                      <form class="form form-horizontal">
                        <div class="form-body">
                          <div class="row">
                            <div class="col-md-4">
                              <label class="lbl_hr">Category</label>
                            </div>
                            <div class="col-md-8">
                              <fieldset class="form-group">
                                <select class="form-control" id="basicSelect">
                                  <option>Select category</option>
                                  <option>Offer Zone</option>
                                  <option>Mens</option>
                                </select>
                              </fieldset>
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr">Sub Category</label>
                            </div>
                            <div class="col-md-8">
                              <fieldset class="form-group">
                                <select class="form-control" id="basicSelect">
                                  <option>Sub Select category</option>
                                  <option>Offer Zone</option>
                                  <option>Mens</option>
                                </select>
                              </fieldset>
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr">Product Sub Category Name</label>
                            </div>
                            <div class="col-md-8 form-group">
                              <input type="text" id="Product_Sub_Category_Name" class="form-control"  placeholder="Product Sub Category Name">
                            </div>
                            <div class="col-md-4">
                              <label class="lbl_hr">Seo Product Sub Category Name</label>
                            </div>
                            <div class="col-md-8 form-group">
                              <input type="text" id="Seo_Product_Sub_Category_Name" class="form-control"  placeholder="Seo Product Sub Category Name">
                            </div>
                            <div class="col-sm-12 d-flex justify-content-end">
                              <button type="submit" class="btn btn-primary mr-1 mb-1">Add</button>
                              <button type="reset" class="btn btn-light-secondary mr-1 mb-1">Clear Form</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
		    </div>
      </div>
    </div>
    <!-- END: Content-->

<?php include 'footer.php';?>