<div class="clrfix"></div>
<footer>
  <div class="foot-block-01 fwd">
    <div class="container">
	  <div class="foot-default-col foot-col-01">
	    <a href="index.php" class="foot-logo"><img src="images/foot-logo.png" class="img-responsive" alt="Enewsmedia"/></a>
	    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
		<p>Any questions? Call us on(+1)96 761 6879</p>
		<div class="social-media-col">
	      <ul class="list-inline top-social-media">
			<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
			<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
			<li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
			<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
			<li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
          </ul>
	    </div>
	  </div>
	  <div class="foot-default-col foot-col-02">
	    <h2>Popular Post</h2>
		<ul class="list-unstyled">
		  <li>
		    <div class="item-col">
			  <div class="img-col">
			    <img src="images/foot-post-img.jpg" class="img-responsive" alt=""/>
			  </div>
			  <div class="containt-col">
			    <h3><a href="#">Lorem Ipsum is simply dummy text of the printing</a></h3>
				<div class="date-txt">Feb 15</div>
			  </div>
			</div>
		  </li>
		  <li>
		    <div class="item-col">
			  <div class="img-col">
			    <img src="images/foot-post-img.jpg" class="img-responsive" alt=""/>
			  </div>
			  <div class="containt-col">
			    <h3><a href="#">Lorem Ipsum is simply dummy text of the printing</a></h3>
				<div class="date-txt">Feb 15</div>
			  </div>
			</div>
		  </li>
		  <li>
		    <div class="item-col">
			  <div class="img-col">
			    <img src="images/foot-post-img.jpg" class="img-responsive" alt=""/>
			  </div>
			  <div class="containt-col">
			    <h3><a href="#">Lorem Ipsum is simply dummy text of the printing</a></h3>
				<div class="date-txt">Feb 15</div>
			  </div>
			</div>
		  </li>
		</ul>
	  </div>
	  <div class="foot-default-col foot-col-03">
	    <h2>Category</h2>
		<ul class="list-unstyled links-col">
		  <li><a href="#">Fashion (22)</a></li>
		  <li><a href="#">Technology (29)</a></li>
		  <li><a href="#">Steet Style (15)</a></li>
		  <li><a href="#">Life Style (28)</a></li>
		  <li><a href="#">Diy & Crafts (16)</a></li>
		</ul>
	  </div>
	</div>
  </div>
  <div class="foot-block-02 fwd">
    <div class="container">
	  <div class="copy-right-txt">
	    &copy; Design and Developed by <a href="#">Oxiincgroup.com</a>
	  </div>
	</div>
  </div>
</footer>
<div class="clrfix"></div>

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Fontawesome -->
<script defer src="js/fontawesome/all.js"></script>
<script defer src="js/fontawesome/brands.js"></script>
<script defer src="js/fontawesome/solid.js"></script>
<script defer src="js/fontawesome/fontawesome.js"></script>
<script defer src="js/menu.js"></script>
<!-- Owlcarousel -->
<script src="js/owlcarousel/owl.carousel.js"></script>

<script src="js/custom-script.js"></script>
