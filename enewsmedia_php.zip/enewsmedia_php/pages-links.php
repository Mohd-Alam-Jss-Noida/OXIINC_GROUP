<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Enewsmedia</title>
	<style>
		h3 {
			font-size:15px;
			color:#222;
			font-weight:600;
			text-align:center;
	    }
		h3 a {
			color:#222;
			text-decoration:none;
	    }
	</style>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	
	  <!-- Start Container -->
	  <div class="main-wrapper" style="padding-top:30px;">
		
		  <h3><a href="index.php" target="_blank">Home Page</a></h3>
		  <h3><a href="news-list.php" target="_blank">News List Page</a></h3>
		  <h3><a href="news-detail.php" target="_blank">News Detail Page</a></h3>
		  
	  </div>
	  <!-- End Container -->

	  
    </div>
  </body>
</html>