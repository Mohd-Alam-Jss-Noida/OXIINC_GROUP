<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Oxiinc Reseller</title>
	<?Php include_once( 'head.php') ?>
</head>

<body>
	<div id="main-page-wrapper">
		<!-- Start Header -->
		<?Php include_once( 'header.php') ?>
		<!-- End Header -->
		<!-- Start Container -->
		<div class="main-wrapper">
			<!-- Services Section-03 -->
			<section class="faq-section-01 section-space fwd">
				<div class="container">
					<h2 class="headding-01 wow fadeInUp" data-wow-delay=".25s">FAQ's</h2>
					<p class="paraha-txt wow fadeInUp" data-wow-delay=".25s">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
					<div class="faq-tabination">
						<div class="tab-group rates-page-tabs">
							<ul class="nav nav-tabs responsive" role="tablist">
								<li class="nav-item active"> <a class="nav-link" data-toggle="tab" href="#exampleTabsAnimateSlideLeftOne" aria-controls="exampleTabsAnimateSlideLeftOne" role="tab" aria-expanded="true">Getting Started</a>
								</li>
								<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#exampleTabsAnimateSlideLeftTwo" aria-controls="exampleTabsAnimateSlideLeftTwo" role="tab" aria-expanded="false">Pricing and Payments</a>
								</li>
								<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#exampleTabsAnimateSlideLeftThree" aria-controls="exampleTabsAnimateSlideLeftThree" role="tab" aria-expanded="true">Listings and Catalog</a>
								</li>
								<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#exampleTabsAnimateSlideLeftFour" aria-controls="exampleTabsAnimateSlideLeftFour" role="tab" aria-expanded="true">Order Management and Shipping</a>
								</li>
							</ul>
							<div class="tab-content responsive">
								<div class="tab-pane active animation-slide-left" id="exampleTabsAnimateSlideLeftOne" role="tabpanel">
									<div class="panel-group panel-group-continuous" id="exampleAccordionContinuous" aria-multiselectable="true" role="tablist">
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousOne" role="tab"> <a class="panel-title" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousOne" aria-controls="exampleCollapseContinuousOne" aria-expanded="true">
                      Why Should I sell on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse in" id="exampleCollapseContinuousOne" aria-labelledby="exampleHeadingContinuousOne" role="tabpanel">
												<div class="panel-body">Oxiinc is the leader in Indian e-commerce with maximum online reach and highest credibility. With more than 10 crore registered customers, 10 million daily page visits and the lowest cost of doing business, we are the strongest partner to take your products to customers all over India. We have sale events that give each seller an equal opportunity to grow their business online.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwo" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousTwo" aria-controls="exampleCollapseContinuousTwo" aria-expanded="false">
                      Who can sell on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwo" aria-labelledby="exampleHeadingContinuousTwo" role="tabpanel">
												<div class="panel-body">Anyone selling new and genuine products is welcome. In order to start selling, you need to have :
													<br>1.GSTIN
													<br>2.Cancelled Cheque
													<br>3.Sample Signatures</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousThree" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousThree" aria-controls="exampleCollapseContinuousThree" aria-expanded="false">
                      How do I sell on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousThree" aria-labelledby="exampleHeadingContinuousThree" role="tabpanel">
												<div class="panel-body">To sell on Oxiinc:
													<br>1.Register yourself at <a href="https://www.oxiinc.in/oxiinc_reseller/"> oxiinc.in/oxiinc_reseller</a>
													<br>2.List your products under specific product categories.
													<br>3.On receiving an order, pack the product and mark it as ‘Ready to Dispatch’. Our logistics partner will pick up the product and deliver it to the customer.
													<br>4.After your order is successfully dispatched, Oxiinc will settle your payment within 7-15 business days based on your seller tier.
													<br>Can I offer both products and services on Oxiinc?</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousFour" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousFour" aria-controls="exampleCollapseContinuousFour" aria-expanded="false">
                      Can I offer both products and services on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousFour" aria-labelledby="exampleHeadingContinuousFour" role="tabpanel">
												<div class="panel-body">Currently, you can only sell products and not services on Oxiinc.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousFive" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousFive" aria-controls="exampleCollapseContinuousFive" aria-expanded="false">
                      Do I need to courier my products to Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousFive" aria-labelledby="exampleHeadingContinuousFive" role="tabpanel">
												<div class="panel-body">No, Oxiinc will handle shipping of your products. All you need to do is pack the product and keep it ready for dispatch. Our logistics partner will pick up the product from you and deliver it to the customer.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousSix" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousSix" aria-controls="exampleCollapseContinuousSix" aria-expanded="false">
                      What are the documents required to register as a seller on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousSix" aria-labelledby="exampleHeadingContinuousSix" role="tabpanel">
												<div class="panel-body">You are required to have the following documents:
													<br>1.GSTIN
													<br>2.Cancelled cheque
													<br>3.Sample signatures <a href="#"> Learn More</a>
												</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousSeven" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousSeven" aria-controls="exampleCollapseContinuousSeven" aria-expanded="false">
                      Who decides the price of the products?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousSeven" aria-labelledby="exampleHeadingContinuousSeven" role="tabpanel">
												<div class="panel-body">As a seller, you will set the price of your products.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousEight" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousEight" aria-controls="exampleCollapseContinuousEight" aria-expanded="false">
                      Will I get charged for listing products on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousEight" aria-labelledby="exampleHeadingContinuousEight" role="tabpanel">
												<div class="panel-body">No. Listing your products on Oxiinc.in is absolutely free. Oxiinc does not charge anything for listing your catalogue online. You only pay a small commission for what you sell.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousNine" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousNine" aria-controls="exampleCollapseContinuousNine" aria-expanded="false">
                      Who takes care of the delivery of my products?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousNine" aria-labelledby="exampleHeadingContinuousNine" role="tabpanel">
												<div class="panel-body">Our logistics partner will pick up the product from you and deliver it to the customer. All you need to do is keep it packed and ready for dispatch.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTen" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousTen" aria-controls="exampleCollapseContinuousTen" aria-expanded="false">
                      How and when will I get paid?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTen" aria-labelledby="exampleHeadingContinuousTen" role="tabpanel">
												<div class="panel-body">The payment will be made directly to your bank account through NEFT transactions. Oxiinc will settle your payments within 7-15 business days based on your seller tier.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousEleven" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousEleven" aria-controls="exampleCollapseContinuousEleven" aria-expanded="false">
                      When can I start selling?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousEleven" aria-labelledby="exampleHeadingContinuousEleven" role="tabpanel">
												<div class="panel-body">After all the required documents have been verified and your seller profile is complete, you can start listing your products and start selling.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwelve" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuous" data-toggle="collapse" href="#exampleCollapseContinuousTwelve" aria-controls="exampleCollapseContinuousTwelve" aria-expanded="false">
                     How many listings are required to start selling?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwelve" aria-labelledby="exampleHeadingContinuousTwelve" role="tabpanel">
												<div class="panel-body">You are required to have a minimum of 1 listings(unique products) to start selling on Oxiinc.</div>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane animation-slide-left" id="exampleTabsAnimateSlideLeftTwo" role="tabpanel">
									<div class="panel-group panel-group-continuous" id="exampleAccordionContinuousone" aria-multiselectable="true" role="tablist">
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousThirteen" role="tab"> <a class="panel-title" data-parent="#exampleAccordionContinuousone" data-toggle="collapse" href="#exampleCollapseContinuousThirteen" aria-controls="exampleCollapseContinuousThirteen" aria-expanded="true">
                      Who decides the price of the product?
                    </a>
											</div>
											<div class="panel-collapse collapse in" id="exampleCollapseContinuousThirteen" aria-labelledby="exampleHeadingContinuousThirteen" role="tabpanel">
												<div class="panel-body">As a seller, you will set the price of your products.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousFourteen" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousone" data-toggle="collapse" href="#exampleCollapseContinuousFourteen" aria-controls="exampleCollapseContinuousFourteen" aria-expanded="false">
                      What are the fees charged?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousFourteen" aria-labelledby="exampleHeadingContinuousFourteen" role="tabpanel">
												<div class="panel-body">The following deductions are made from the order item value:
													<br>1.Commission fee: A percentage of the order item value based on vertical/sub-category.
													<br>2.Shipping fee: Calculated on the basis of the product weight and shipping location
													<br>3.Collection fee: This will vary based on order item value and customer payment mode (Prepaid/Cash on Delivery)
													<br>4.Fixed fee: A slab wise Fixed fee. This varies based on Order item value
													<br>
												</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousFifteen" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousone" data-toggle="collapse" href="#exampleCollapseContinuousFifteen" aria-controls="exampleCollapseContinuousFifteen" aria-expanded="false">
                      What is Commission fee and how much commission is charged?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousFifteen" aria-labelledby="exampleHeadingContinuousFifteen" role="tabpanel">
												<div class="panel-body">Commission fee is a certain percentage of the order item value of your product. It differs across categories and vertical/sub-categories.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousSixteen" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousone" data-toggle="collapse" href="#exampleCollapseContinuousSixteen" aria-controls="exampleCollapseContinuousSixteen" aria-expanded="false">
                     Please give an example to show the cost calculation.
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousSixteen" aria-labelledby="exampleHeadingContinuousSixteen" role="tabpanel">
												<div class="panel-body">Here’s an easy example, which illustrates a sample for the above calculation</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousSeventeen" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousone" data-toggle="collapse" href="#exampleCollapseContinuousSeventeen" aria-controls="exampleCollapseContinuousSeventeen" aria-expanded="false">
                     How and when do I get paid?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousSeventeen" aria-labelledby="exampleHeadingContinuousSeventeen" role="tabpanel">
												<div class="panel-body">All payments are made through NEFT transactions (online banking). The payment is made directly to your bank account within the next 7-15 business days from the date of order dispatch. It's 7 business days for Gold Sellers, 10 business days for Silver Sellers and 15 business days for Bronze sellers.</div>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane animation-slide-left" id="exampleTabsAnimateSlideLeftThree" role="tabpanel">
									<div class="panel-group panel-group-continuous" id="exampleAccordionContinuoustwo" aria-multiselectable="true" role="tablist">
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousEighteen" role="tab"> <a class="panel-title" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousEighteen" aria-controls="exampleCollapseContinuousEighteen" aria-expanded="true">
                      What is listing?
                    </a>
											</div>
											<div class="panel-collapse collapse in" id="exampleCollapseContinuousEighteen" aria-labelledby="exampleHeadingContinuousEighteen" role="tabpanel">
												<div class="panel-body">Listing a product refers to filling out all the necessary information and adding images of the product so that a customer can make an informed buying decision.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousNineteen" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousNineteen" aria-controls="exampleCollapseContinuousNineteen" aria-expanded="false">
                      How many products do I need to list to start selling?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousNineteen" aria-labelledby="exampleHeadingContinuousNineteen" role="tabpanel">
												<div class="panel-body">You are required to have a minimum of 1 listings to start selling on Oxiinc.com</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwenty" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousTwenty" aria-controls="exampleCollapseContinuousTwenty" aria-expanded="false">
                      How do I list my products on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwenty" aria-labelledby="exampleHeadingContinuousTwenty" role="tabpanel">
												<div class="panel-body">We give you a step-by-step process of how to list your products on our website. It is important to choose the most suitable category to list your product as it will help customers find your products faster. Based on the category you choose, you'll be asked to include product details such as size, model, color, etc.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentyone" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousTwentyone" aria-controls="exampleCollapseContinuousTwentyone" aria-expanded="false">
                      Can I get help for the development of the catalog (product images, description, etc.)?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentyone" aria-labelledby="exampleHeadingContinuousTwentyone" role="tabpanel">
												<div class="panel-body">Yes, we are happy to help you at every stage while doing business with us. We help you connect with industry experts for the development of your catalogs. With the help of our catalog partners across India, you can have attractive images and crisp content developed at unbeatable prices.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwenttwo" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousTwentytwo" aria-controls="exampleCollapseContinuousTwentytwo" aria-expanded="false">
                      How does a catalog partner help me?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentytwo" aria-labelledby="exampleHeadingContinuousTwenttwo" role="tabpanel">
												<div class="panel-body">Our catalog partners develop high-quality photographs of your products and crisp product descriptions for your product catalog. A good catalog gives your customers a better understanding of your products and helps boost your sales. List of cataloging partners here.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentthree" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousTwentythree" aria-controls="exampleCollapseContinuousTwentythree" aria-expanded="false">
                      How do I price my products?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentythree" aria-labelledby="exampleHeadingContinuousTwentthree" role="tabpanel">
												<div class="panel-body">When pricing products on oxiinc, please account for the applicable Marketplace Fee and include a suitable margin to arrive at the Selling Price. For ease of calculation, you can use our Commission Calculator widget once onboarded.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentfour" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuoustwo" data-toggle="collapse" href="#exampleCollapseContinuousTwentyfour" aria-controls="exampleCollapseContinuousTwentyfour" aria-expanded="false">
                      Will I get charged for listing products on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentyfour" aria-labelledby="exampleHeadingContinuousTwentfour" role="tabpanel">
												<div class="panel-body">No. Listing of products on Oxiinc.in is absolutely free. Oxiinc does not charge anything to you for listing your catalogue online. You only pay a small commission for what you sell.</div>
											</div>
										</div>
									</div>
								</div>
								<div class="tab-pane animation-slide-left" id="exampleTabsAnimateSlideLeftFour" role="tabpanel">
									<div class="panel-group panel-group-continuous" id="exampleAccordionContinuousthree" aria-multiselectable="true" role="tablist">
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentyfive" role="tab"> <a class="panel-title" data-parent="#exampleAccordionContinuousthree" data-toggle="collapse" href="#exampleCollapseContinuousTwentyfive" aria-controls="exampleCollapseContinuousTwentyfive" aria-expanded="true">
                      Who takes care of the delivery of my products?
                    </a>
											</div>
											<div class="panel-collapse collapse in" id="exampleCollapseContinuousTwentyfive" aria-labelledby="exampleHeadingContinuousTwentyfive" role="tabpanel">
												<div class="panel-body">Our logistics partner will pick up the product from you and deliver it to the customer. All you need to do is keep it packed and ready for dispatch</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentysix" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousthree" data-toggle="collapse" href="#exampleCollapseContinuousTwentysix" aria-controls="exampleCollapseContinuousTwentysix" aria-expanded="false">
                      What should I do if my area is not serviceable by Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentysix" aria-labelledby="exampleHeadingContinuousTwentysix" role="tabpanel">
												<div class="panel-body">During registration, save the details of your pin code and click on the Continue button. You will be notified via e-mail when your pin code becomes serviceable.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentyseven" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousthree" data-toggle="collapse" href="#exampleCollapseContinuousTwentyseven" aria-controls="exampleCollapseContinuousTwentyseven" aria-expanded="false">
                      How do I manage my orders on Oxiinc?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentyseven" aria-labelledby="exampleHeadingContinuousTwentyseven" role="tabpanel">
												<div class="panel-body">Through our seller dashboard, we make it really easy for you to manage your orders. Whenever a customer places an order, we will send you an e-mail alert. You need to pack the order and keep it ready for dispatch within the time frame provided by you and inform us through the seller portal. This will alert our logistics partner to pick up the product from you.</div>
											</div>
										</div>
										<div class="panel">
											<div class="panel-heading" id="exampleHeadingContinuousTwentyeight" role="tab"> <a class="panel-title collapsed" data-parent="#exampleAccordionContinuousthree" data-toggle="collapse" href="#exampleCollapseContinuousTwentyeight" aria-controls="exampleCollapseContinuousTwentyeight" aria-expanded="false">
                      Does Oxiinc provide packaging material?
                    </a>
											</div>
											<div class="panel-collapse collapse" id="exampleCollapseContinuousTwentyeight" aria-labelledby="exampleHeadingContinuousTwentyeight" role="tabpanel">
												<div class="panel-body">We have a strong network of best packaging material providers in the industry. We can connect you with them to get good quality packaging material which impresses the customers and ensures your products remain undamaged.</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div class="clrfix"></div>
		</div>
		<!-- End Container -->
		<!-- Start Footer -->
		<?Php include_once( 'footer.php') ?>
		<script>
			(function($) {
				$(window).load(function() {
					$("header nav li.faqs-active").addClass('active');
				});
			})(jQuery);
		</script>
		<!-- End Footer -->
	</div>
</body>

</html>