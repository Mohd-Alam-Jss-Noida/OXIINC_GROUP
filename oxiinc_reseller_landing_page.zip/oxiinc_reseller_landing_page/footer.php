<div class="clrfix"></div>
<footer>
  <div class="container">
    <div class="foot-block-01 fwd">
		<div class="foot-links-col col-1 equal-height-col">
		  <h3>Address</h3>
		  <ul class="list-unstyled">
			<li>
			<strong class="fwd" style="margin-bottom:10px;">EROCKETMALL ONLINE ASIA LIMITED</strong> <br>
			CIN - U74999MH2014PLC257236 <br>
			S6-2, Pinnacle Business Park,<br> Mahakali Caves Rd, <br>
			Shanti Nagar, Andheri East, Mumbai, Maharashtra - 400093. <br><br>

			Email: sell@oxiinc.in <br><br>

			Contact No : +91 022 68732700
			</li>
		  </ul>
		</div>
		<div class="foot-links-col col-2 equal-height-col">
		  <h3>Services</h3>
		  <ul class="list-unstyled">
			<li><a href="#">Fulfilment Services</a></li>
			<li><a href="#">Account Managemant</a></li>
			<li><a href="#">Partner Services</a></li>
			<li><a href="#">Packaging Services</a></li>
		  </ul>
		</div>
		<div class="foot-links-col col-3 equal-height-col">
		  <h3>Resources</h3>
		  <ul class="list-unstyled">
			<li><a href="#">Online Selling Guide</a></li>
			<li><a href="#">Products In Demand</a></li>
			<li><a href="#">Success Stories</a></li>
			<li><a href="#">Seller Learning Center</a></li>
			<li><a href="#">News</a></li>
			<li><a href="#">API Documentation</a></li>
		  </ul>
		</div>
		<div class="foot-links-col col-4 equal-height-col">
		  <h3>FAQs</h3>
		  <ul class="list-unstyled">
			<li><a href="#">Getting Started</a></li>
			<li><a href="#">Pricing And Payments</a></li>
			<li><a href="#">Listing And Catalog</a></li>
			<li><a href="#">Order Management And Shipping</a></li>
		  </ul>
		</div>
	</div>
	
	<div class="foot-block-02 fwd">
	  &copy; 2020. All Rights Reserved. Design by <a href="#">OXIINCGROUP.COM</a>
    </div>
  </div>
</footer>
<div class="clrfix"></div>


<!-- Login Modal -->
<div class="modal fade modal-block" id="ProfileModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <div class="modal-body">
		<form class="form-block">
		  <div class="fwd">
		      <h2 class="headding-01">Sign in to continue </h2>
			  <div class="form-group">
				<label for="InputEmail">E-mail</label>
				<input type="email" class="textbox" id="InputEmail">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group">
				<label for="InputFullName">Full Name</label>
				<input type="password" class="textbox" id="InputFullName" >
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
			  <div class="form-group half-width checkbox">
				<label>
				  <input type="checkbox"> Remember me
				</label>
			  </div>
			  <div class="form-group half-width">
				<label class="align-right"><a href="#" data-dismiss="modal" data-toggle="modal" data-target="#ForgotPassModal">Forgot Password?</a></label>
			  </div>
		  </div>
		  <div class="form-group text-center">
			<button type="submit" class="submit-btn">Sign in</button>
		  </div>
		</form>
		<div class="clrfix"></div>
      </div>
    </div>
  </div>
</div>

<!-- Forgot Password Modal -->
<div class="modal fade modal-block" id="ForgotPassModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      <div class="modal-body">
		<form class="form-block">
		  <div class="fwd">
		      <h2 class="headding-01">Forgot Password </h2>
			  <div class="form-group">
				<label for="InputEmail">E-mail</label>
				<input type="email" class="textbox" id="InputEmail">
				<span class="bar"></span>
				<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
			  </div>
		  </div>
		  <div class="form-group text-center">
			<button type="submit" class="submit-btn">Submit</button>
		  </div>
		</form>
		<div class="clrfix"></div>
      </div>
    </div>
  </div>
</div>


<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- Fontawesome -->
<script defer src="js/fontawesome/all.js"></script>
<script defer src="js/fontawesome/brands.js"></script>
<script defer src="js/fontawesome/solid.js"></script>
<script defer src="js/fontawesome/fontawesome.js"></script>

<!-- Animation -->
<script>
  if (screen && screen.width > 767) {
	document.write('<script type="text/javascript" src="js/animation/wow.js"><\/script>');
  }
</script>

<!-- Navigation -->
<script defer src="js/menu.js"></script>
<script defer src="js/tab-accordian.js"></script>

<script src="js/custom-script.js"></script>
