<!-- Css -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet"> 
<!-- Fontawesome -->
<link href="css/fontawesome/all.css" rel="stylesheet">
<link href="css/fontawesome/fontawesome.css" rel="stylesheet">
<link href="css/fontawesome/brands.css" rel="stylesheet">
<link href="css/fontawesome/solid.css" rel="stylesheet">
<!--<link href="css/animate.css" rel="stylesheet">-->
<!-- Animation -->
<link href="css/animation/animate.css" rel="stylesheet">

<!-- Navigation -->
<link href="css/menu.css" rel="stylesheet">

<link href="css/custom-style.css" rel="stylesheet">
<link href="css/custom-responsive.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->