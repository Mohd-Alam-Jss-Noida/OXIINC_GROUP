<header>
	<div class="top-head fwd">
		<div class="container">
			<div class="search-col">
				<input type="text" class="input-search" id="InputSearch" placeholder="Enter Your Keyword">
				<button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
			</div>
			<ul class="list-inline head-social-media">
				<li><a href="https://www.facebook.com/myoxiinc/" target="blank"><i class="fab fa-facebook-f"></i></a></li>
				<li><a href="https://twitter.com/myoxiinc" target="blank"><i class="fab fa-twitter"></i></a></li>
				<li><a href="https://www.linkedin.com/in/oxiinc-health-care-company-pvt-ltd-b00720117/" target="blank"><i class="fab fa-linkedin-in"></i></a></li>
				<li><a href="https://www.instagram.com/myoxiinc/" target="blank"><i class="fab fa-instagram"></i></a></li>
				<li><a href="https://www.youtube.com/channel/UCim_GlgyKZ2aJF7KhUEE3Gw/" target="blank"><i class="fab fa-youtube"></i></a></li>
			</ul>
		</div>
	</div>
	<div class="container">
		<div class="navigation-col fwd">
			<a href="index.php" class="logo-col"><img src="images/oxiinc-logo.png" alt=""/></a>
			<a href="#" class="existing-seller-login-btn" data-toggle="modal" data-target="#ProfileModal"><i class="fa fa-user-circle"></i> <span>Existing Sellers</span></a>
			<div class="xs-search-btn"><i class="fa fa-search"></i></div>
			<nav id='cssmenu' class="fwd">
				<div id="head-mobile"></div>
				<div class="button"></div>
				<ul class="nav-main-ul">
					<li class='fee-structure-active'><a href='fee-structure.php'>Fee Structure</a></li>
					<li class="service-active"><a href='services.php'>Services</a></li>
					<li class="resources-active"><a href='resources.php'>Resources</a></li>
					<li class="faqs-active"><a href='faqs.php'>FAQs</a></li>
					<li><a href='#'>Oxiinc.in</a></li>
				</ul>
			</nav>
		</div>
	</div>
</header>
<div class="clrfix"></div>

