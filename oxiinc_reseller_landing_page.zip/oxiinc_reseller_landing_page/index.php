<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Reseller</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	  
		<!-- Banner Section -->
		<section class="banners-section fwd">
		  <div class="container">
		    <div class="banner-left-img">
			  <img src="images/banner-img-01.png" alt="" class="img-responsive wow pulse" data-wow-delay="300ms" data-wow-iteration="2" data-wow-duration="2s"/>
			</div>
			<div class="banner-form-col wow bounceInRight" data-wow-delay=".25s" data-wow-duration="1.25s"> 
			  <h3>Become a seller on India's BIGGEST E-commerce platform</h3>
			  <form>
				  <div class="form-group">
					<input type="email" class="input-textbox" id="exampleInputEmail1" placeholder="E-Mail Id">
				  </div>
				  <div class="form-group">
					<input type="text" class="input-textbox" id="exampleInputPassword1" placeholder="Phone Number">
				  </div>
				  <div class="form-group fwd btn-form-group align-center">
				    <a href="registration.php"><button type="button" class="register-btn">Register Now</button></a>
				  </div>
			  </form>
			</div>
		  </div>  
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Home Section-01 -->
		<section class="home-section-01 section-space fwd">
		  <div class="container">
		    <h2 class="headding-01 wow fadeInDown" data-wow-delay=".25s">The lowest cost of doing business in the industry</h2>
			<p class="paraha-txt wow fadeInDown" data-wow-delay=".25s">With the most competitive rate card in the industry, transparent delivery charges based on the weight and dimensions of your products and a small fixed fee, selling on Oxiinc is highly cost-efficient.</p>
			<ul class="list-inline reseller-plans-list">
			  <li class="equal-height-col wow fadeInDown" data-wow-delay=".50s">
			    <div class="reseller-plan-col">
				  <div class="plan-info">
				    <span class="plan-name">Trial</span>
					<span class="plan-amount">₹0</span>
				  </div>
				  <h4>15 Days To 45 Days and Guaranteed sell of <strong>₹10,000</strong> to <strong>₹50,000*</strong></h4>
				  <ul class="list-unstyled">
					<li>10% Service charge on all payments.</li>
				  </ul>
				  <a href="#" class="register-btn">Register Now</a>
				</div>
			  </li>
			  
			  <li class="equal-height-col wow fadeInDown" data-wow-delay=".75s">
			    <div class="reseller-plan-col">
				  <div class="plan-info">
				    <span class="plan-name">Silver</span>
					<span class="plan-amount">₹10,000</span>
				  </div>
				  <h4>30 Days To 90 Days and Guaranteed sell of Up To <strong>₹1,00,000*</strong></h4>
				  <ul class="list-unstyled">
					<li>5% Service charge on all payments.</li>
				  </ul>
				  <a href="#" class="register-btn">Register Now</a>
				</div>
			  </li>
			  <li class="equal-height-col wow fadeInDown" data-wow-delay="1s">
			    <div class="reseller-plan-col">
				  <div class="plan-info">
				    <span class="plan-name">Gold</span>
					<span class="plan-amount">₹25,000</span>
				  </div>
				  <h4>90 Days To 180 Days and Guaranteed sell of Up To <strong>₹3,00,000*</strong></h4>
				  <ul class="list-unstyled">
					<li>5% Service charge on all payments.</li>
					<li>5Days Advertise Pack</li>
					<li>Oxiinc Packaging Pouches - 10 pc.</li>
					<li>Oxiinc Cello Tape 2</li>
				  </ul>
				  <a href="#" class="register-btn">Register Now</a>
				</div>
			  </li>
			  <li class="equal-height-col wow fadeInDown" data-wow-delay="1.25s">
			    <div class="reseller-plan-col">
				  <div class="plan-info">
				    <span class="plan-name">Platinum</span>
					<span class="plan-amount">₹50,000</span>
				  </div>
				  <h4>180 Days To 270 Days and Guaranteed sell of Up To <strong>₹6,00,000*</strong></h4>
				  <ul class="list-unstyled">
					<li>5% Service charge on all payments.</li>
					<li>15Days Advertise Pack</li>
					<li>Oxiinc Packaging Pouches - 25 pc.</li>
					<li>Oxiinc Cello Tape 3 pc</li>
				  </ul>
				  <a href="#" class="register-btn">Register Now</a>
				</div>
			  </li>
			  <li class="equal-height-col wow fadeInDown" data-wow-delay="1.50s">
			    <div class="reseller-plan-col">
				  <div class="plan-info">
				    <span class="plan-name">Reseller Club</span>
					<span class="plan-amount">₹,1,00,000</span>
				  </div>
				  <h4>365 Days and Guaranteed sell of Up To <strong>₹12,00,000*</strong></h4>
				  <ul class="list-unstyled">
					<li>5% Service charge on all payments.</li>
					<li>One Month Advertise Pack</li>
					<li>Oxiinc Packaging Pouches 50 pc.</li>
					<li>Oxiinc Cello Tape 5 pc.</li>
					<li>Oxiinc Reseller Banner</li>
				  </ul>
				  <a href="#" class="register-btn">Register Now</a>
				</div>
			  </li>
			</ul>
		  </div>  
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Home Section-02 -->
		<section class="home-section-02 section-space fwd">
		  <div class="container">
		    <div class="left-col">
			  <img src="images/register-process-img.png" alt="" class="img-responsive wow fadeInLeftBig" data-wow-delay=".25s"/>
			</div>
			<div class="right-col">
			  <h2 class="headding-01 wow fadeInDown" data-wow-delay=".25s">How to Register</h2>
			  <p class="paraha-txt wow fadeInDown" data-wow-delay=".25s">You need just 3 things to become a Oxiinc Seller.</p>
			  <ul class="list-unstyled register-steps-list">
				<li class="wow fadeInDown" data-wow-delay=".25s">
				  <div class="icon-col">
				    <img src="images/product-sell-icon.png" alt=""/>
				  </div>
				  <span class="fwd title-col">At least 1 product to sell</span>
				  <span class="fwd desc-col">All you need is a minimum of 1 unique product to start selling on Oxiinc.</span>
				</li>
				<li class="wow fadeInDown" data-wow-delay=".50s">
				  <div class="icon-col">
					<img src="images/GSTIN-detail-icon.png" alt=""/>
				  </div>
				  <span class="fwd title-col">GSTIN details</span>
				  <span class="fwd desc-col">You are required to furnish the details of your GSTIN to sell your products online.</span>
				</li>
				<li class="wow fadeInDown" data-wow-delay=".75s">
				  <div class="icon-col">
					<img src="images/cancelled-cheque-icon.png" alt=""/>
				  </div>
				  <span class="fwd title-col">Cancelled cheque</span>
				  <span class="fwd desc-col">A copy of the cancelled cheque of your bank account is mandatory of registering.</span>
				</li>
			  </ul>
			</div>
		  </div>  
		</section>
		<div class="clrfix"></div>
		
		
		<!-- Home Section-03 -->
		<section class="home-section-03 section-space fwd">
		  <div class="container">
		    <h2 class="headding-01 wow fadeInUp" data-wow-delay=".25s">Latest News</h2>
			<p class="paraha-txt wow fadeInUp" data-wow-delay=".25s">Oxiinc Marketplace is India’s leading platform for selling online. Be it a manufacturer, vendor or supplier, simply sell your products online on Oxiinc and become a top e-commerce player with minimum investment.</p>
			<ul class="list-inline latest-news-list">
			  <li class="equal-height-col wow fadeInUp" data-wow-delay=".50s">
			    <div class="latest-news-col">
				  <img src="images/news-01.jpg" class="news-img-col" alt=""/>
				  <div class="news-detail-col">
				    <span class="news-date">10<sup>th</sup> Jul, 2019</span>
				    <span class="fwd news-title">Metrics-Track And Improve Your Performance</span>
					<span class="fwd news-desc">As a seller, making sure that your products are dispatched on time is an absolute necessity.</span>
					<a href="#" class="read-more-btn">Read More <i class="fa fa-arrow-right"></i></a>
				  </div>
				</div>
			  </li>
			  <li class="equal-height-col wow fadeInUp" data-wow-delay=".75s">
			    <div class="latest-news-col">
				  <img src="images/news-02.jpg" class="news-img-col" alt=""/>
				  <div class="news-detail-col">
				    <span class="news-date">13<sup>th</sup> Jun, 2019</span>
				    <span class="fwd news-title">Tips to improve your seller performance</span>
					<span class="fwd news-desc">The key to consistently improve profits is by being aware of your shortcomings as a business deliver and trying to overcome them.</span>
					<a href="#" class="read-more-btn">Read More <i class="fa fa-arrow-right"></i></a>
				  </div>
				</div>
			  </li>
			  <li class="equal-height-col wow fadeInUp" data-wow-delay="1s">
			    <div class="latest-news-col">
				  <img src="images/news-03.jpg" class="news-img-col" alt=""/>
				  <div class="news-detail-col">
				    <span class="news-date">10<sup>th</sup> Jul, 2019</span>
				    <span class="fwd news-title">Seller Score and how to calculate</span>
					<span class="fwd news-desc">As a seller on Oxiinc it is important that you are aware of your Seller Score and understand the Growth Tab.</span>
					<a href="#" class="read-more-btn">Read More <i class="fa fa-arrow-right"></i></a>
				  </div>
				</div>
			  </li>
			</ul>
		  </div>  
		</section>
		<div class="clrfix"></div>

	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>