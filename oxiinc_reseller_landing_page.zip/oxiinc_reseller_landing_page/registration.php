<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oxiinc Reseller</title>
	
	<?Php include_once('head.php') ?>
  </head>
  <body>
    <div id="main-page-wrapper">
    
	  <!-- Start Header -->
	    <?Php include_once('header.php') ?>
	  <!-- End Header -->
	  
	
	  <!-- Start Container -->
	  <div class="main-wrapper">
	  

		<!-- Registration Section-01 -->
		<section class="registration-section-01 section-space fwd">
		  <div class="container">
		    <h2 class="headding-01 wow fadeInUp" data-wow-delay=".25s">Create Your Seller Account</h2>
			<div class="modal-block wow fadeInUp" data-wow-delay=".50s">
			  <form class="form-block">
			    <div class="fwd">
				  <div class="form-group">
					<label for="InputEmail">E-mail</label>
					<input type="email" class="textbox" id="InputEmail">
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Mobile No.</label>
					<input type="text" class="textbox otp-textbox" id="InputFullName" >
					<button type="submit" class="submit-btn otp-btn">Resend OTP</button>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Enter OTP</label>
					<input type="text" class="textbox otp-textbox" id="InputFullName">
					<button type="submit" class="submit-btn otp-btn">Verify OTP</button>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Full Name</label>
					<input type="text" class="textbox" id="InputFullName" >
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Password</label>
					<input type="password" class="textbox eye-textbox" id="InputFullName" >
					<button type="submit" class="submit-btn eye-btn"><i class="fa fa-eye"></i></button>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Re-enter Password</label>
					<input type="password" class="textbox eye-textbox" id="InputFullName" >
					<button type="submit" class="submit-btn eye-btn"><i class="fa fa-eye"></i></button>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Select Your Packages</label>
					<select class="textbox input-selectbox">
					  <option>1</option>
					  <option>2</option>
					  <option>3</option>
					  <option>4</option>
					  <option>5</option>
					</select>
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>		  
				  <div class="form-group">
					<label for="InputFullName">Referral Id(E-Panalist Id)</label>
					<input type="text" class="textbox" id="InputFullName" >
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
				  <div class="form-group">
					<label for="InputFullName">Referral Name</label>
					<input type="text" class="textbox" id="InputFullName" >
					<span class="bar"></span>
					<div class="input-erroemsg" style="display:none;">Please enter valid text</div>
				  </div>
			    </div>
			    <div class="form-group text-center">
				  <button type="submit" class="submit-btn">Sign Up</button>
			    </div>
		  	  </form>
			  <div class="clrfix"></div>
			</div>
		  </div>  
		</section>
		<div class="clrfix"></div>
		

	  </div>
	  <!-- End Container -->
	
	  <!-- Start Footer -->
	    <?Php include_once('footer.php') ?>
	  <!-- End Footer -->
	  
    </div>
  </body>
</html>