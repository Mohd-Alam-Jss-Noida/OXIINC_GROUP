$(document).ready(function($){
	
	
//-- Main Wrapper Height	
	var contentheight = $(window).height() - $("header").height() - $("footer").height() + "px";
	$(".main-wrapper").css("min-height", contentheight);
	
	
//-- Sticky Header Script  	
	$(window).on('scroll', function() {
		var scroll = $(window).scrollTop();
		if (scroll >= 50) {
			$("header").addClass("fixed-header");
		} else {
			$("header").removeClass("fixed-header");
		}
	});	
	
	
//-- Toggle the side navigation
	if(window.matchMedia('(max-width: 1023px)').matches)
    {
		$('.xs-search-btn').on('click', function(){
			$('.top-head').toggleClass('active-search-btn');
		});
    }
	

//-- Go to Top Scroll
	var offset = 500,
		offset_opacity = 1200,
		scroll_top_duration = 700,
		$back_to_top = $('.cd-top');

	$(window).scroll(function(){
		( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
		if( $(this).scrollTop() > offset_opacity ) { 
			$back_to_top.addClass('cd-fade-out');
		}
	});

	$back_to_top.on('click', function(event){
		event.preventDefault();
		$('body,html').animate({
			scrollTop: 0 ,
			}, scroll_top_duration
		);
	});
	
	

//-- Equal Height Col	
	equalheight = function(container){
		
		var currentTallest = 0,
		currentRowStart = 0,
		rowDivs = new Array(),
		$el,
		topPosition = 0;
		$(container).each(function() {
			
			$el = $(this);
			$($el).height('auto')
			topPostion = $el.position().top;
			
			if (currentRowStart != topPostion) {
				for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
					rowDivs[currentDiv].height(currentTallest);
				}
				rowDivs.length = 0; // empty the array
				currentRowStart = topPostion;
				currentTallest = $el.height();
				rowDivs.push($el);
				} else {
				rowDivs.push($el);
				currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
			}
			for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
				rowDivs[currentDiv].height(currentTallest);
			}
		});
	}
	
	$(window).load(function() {
		equalheight('.equal-height-col');
	});
	
	$(window).resize(function(){
		equalheight('.equal-height-col');
	});	


});


//-- Page Animation Script	
	wow = new WOW(
	  {
		animateClass: 'animated',
		offset:       100,
		callback:     function(box) {
		  console.log("WOW: animating <" + box.tagName.toLowerCase() + ">")
		}
	  }
	);
	wow.init();

