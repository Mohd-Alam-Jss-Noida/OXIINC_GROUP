  
<?php include 'head.php';
?>
<?php include 'header.php';
?>
  <div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
      <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
          <h3 class="content-header-title">Directors List Table</h3>
          <div class="row breadcrumbs-top">
            <div class="breadcrumb-wrapper col-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Directors List Table
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="content-body">
        <section id="file-export">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                    <div class="table-responsive">
                      <table class="table table-striped table-bordered file-export">
                        <thead>
                          <tr>
                            <th>Sr.No.</th>
                            <th>Director Name</th>
                            <th>Email Id</th>
                            <th>Contact No.</th>
                            <th>View Details</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            
                          </tr>
                        </tbody>
                      </table>
                    </div>      
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>

  <?php include 'footer.php';
?>