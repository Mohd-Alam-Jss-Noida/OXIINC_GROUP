  
<?php include 'head.php';
?>
<?php include 'header.php';
?>
  <div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
      <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
          <h3 class="content-header-title">View and Update Company details</h3>
          <div class="row breadcrumbs-top">
            <div class="breadcrumb-wrapper col-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">View and Update Company details
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="content-body">
        <div class="card">
          <div class="card-body">
            <form class="form">
              <div class="form-body">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput1">Company Name:</label>
                      <input type="text" id="userinput1" class="form-control border-primary" placeholder="Company Name" name="Company Name">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput2">Company Email</label>
                      <input class="form-control border-primary" type="email" placeholder="Company Email" id="userinput2">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput3">CIN No.</label>
                      <input type="text" id="userinput3" class="form-control border-primary" placeholder="CIN No." name="CIN No.">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput4">CIN Certificate</label>
                      <input type="file" id="file" class="form-control border-primary" placeholder="CIN Certificate" name="CIN Certificate">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput5">GST No.</label>
                      <input type="text" id="userinput5" class="form-control border-primary" placeholder="CIN No." name="CIN No.">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput6">GST certificate</label>
                      <input type="file" id="file" class="form-control border-primary" placeholder="GST certificate" name="GST certificate">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput7">PAN No.</label>
                      <input type="text" id="userinput7" class="form-control border-primary" placeholder="PAN No." name="PAN No.">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput8">Pan Card Copy</label>
                      <input type="file" id="file" class="form-control border-primary" placeholder="Pan Card Copy" name="Pan Card Copy">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput9">Address</label>
                      <input type="text" id="userinput9" class="form-control border-primary" placeholder="Address" name="Address">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput10">City</label>
                      <input type="text" id="userinput10" class="form-control border-primary" placeholder="Cty" name="City">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput11">District</label>
                      <input type="text" id="userinput11" class="form-control border-primary" placeholder="District" name="District">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput12">State</label>
                      <input type="text" id="userinput12" class="form-control border-primary" placeholder="State" name="State">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput13">Pincode</label>
                      <input type="number" id="userinput13" class="form-control border-primary" placeholder="Pincode" name="Pincode">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput14">Telephone Number</label>
                      <input type="number" id="userinput14" class="form-control border-primary" placeholder="Telephone Number" name="Telephone Number">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput15">Mobile Number</label>
                      <input type="number" id="userinput15" class="form-control border-primary" placeholder="Mobile Number" name="Mobile Number">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="userinput16">Company Website</label>
                      <input type="text" id="userinput16" class="form-control border-primary" placeholder="Telephone Number" name="Telephone Number">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-actions text-center">
                <button type="submit" class="btn btn-primary"></i> Update</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php include 'footer.php';
?>