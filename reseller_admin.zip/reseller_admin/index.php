  
<?php include 'head.php';
?>
<?php include 'header.php';
?>
  <div class="app-content content">
    <div class="content-overlay"></div>
    
  </div>

  <?php include 'footer.php';
?>