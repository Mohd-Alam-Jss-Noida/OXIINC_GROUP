  
<?php include 'head.php';
?>
<?php include 'header.php';
?>
  <div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
      <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
          <h3 class="content-header-title">Packing Material</h3>
          <div class="row breadcrumbs-top">
            <div class="breadcrumb-wrapper col-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Packing Material
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="content-body">
        <section id="file-export">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <!-- <h4 class="card-title">Packing Material</h4> -->
                  <div class="heading-elements">
                    <ul class="list-inline mb-0">
                      <li><div class="form-group">
                            <button type="button" class="btn btn-info btn-min-width mr-1 mb-1" data-toggle="modal" data-target="#packing_material_price">Add Material <i class="ft-settings icon-plus"></i></button>
                          </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                    <div class="table-responsive">
                      <table class="table table-striped table-bordered file-export">
                        <thead>
                          <tr>
                            <th>Sr.No.</th>
                            <th>Material Name</th>
                            <th>Material Price</th>
                            <th>Created Date</th>
                            <th>Status</th>
                            <th>Action(View)</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>Oxiinc Printed Cello Tape ( 24mm* 65mtr) SMALL 6pcs</td>
                            <td>210</td>
                            <td>2020-10-09 13:14:35</td>
                            <td>
                              <button type="button" class="btn btn-success btn-min-width box-shadow-2 mr-1 mb-1">Active</button>
                            </td>
                            <td><button type="button" class="btn btn-success btn-min-width box-shadow-2 mr-1 mb-1" data-toggle="modal" data-target="#packing_material_price">Edit</button></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>      
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>

  <?php include 'footer.php';
?>