<!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light navbar-border navbar-shadow">
      <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2020 <a class="text-bold-800 grey darken-2" href="https://www.oxiincgroup.com/" target="_blank">Oxiincgroup</a></span></p>
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->

    <script src="app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
    <script src="app-assets/vendors/js/tables/datatable/dataTables.buttons.min.js"></script>
    <script src="app-assets/vendors/js/tables/buttons.flash.min.js"></script>
    <!-- <script src="app-assets/vendors/js/tables/datatable/buttons.bootstrap4.min.js"></script> -->
    <script src="app-assets/vendors/js/tables/jszip.min.js"></script>
    <script src="app-assets/vendors/js/tables/pdfmake.min.js"></script>
    <script src="app-assets/vendors/js/tables/vfs_fonts.js"></script>
    <script src="app-assets/vendors/js/tables/buttons.html5.min.js"></script>
    <script src="app-assets/vendors/js/tables/buttons.print.min.js"></script>
    <script src="app-assets/vendors/js/tables/datatable/dataTables.responsive.min.js"></script>
    <!-- <script src="app-assets/vendors/js/tables/buttons.colVis.min.js"></script> -->
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="app-assets/js/core/app-menu.min.js"></script>
    <script src="app-assets/js/core/app.min.js"></script>
    <script src="app-assets/js/scripts/customizer.min.js"></script>
    <script src="app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="app-assets/js/scripts/tables/datatables-extensions/datatable-responsive.min.js"></script>
    <script src="app-assets/js/scripts/tables/datatables-extensions/datatable-button/datatable-html5.min.js"></script>
    <script src="app-assets/js/scripts/tables/datatables/datatable-advanced.min.js"></script>
    <!-- END: Page JS-->

    <div class="modal fade text-left" id="packing_material_price" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <form class="form">
              <div class="form-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput1">Material Name</label>
                      <input type="text" id="userinput1" class="form-control border-primary" placeholder="Enter Material Name" name="Enter Material Name">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Material Price</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Enter Material Price" name="Enter Material Price">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-actions text-right">
                <button type="submit" class="btn btn-outline-primary">
                  <i class="la la-check-square-o"></i> Submit
                </button>
                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                  <i class="ft-x"></i> Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade text-left" id="rejected_material_packges" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">User Name</h4>
          </div>
          <div class="modal-body">
            <form class="form">
              <div class="form-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Approval Status</label>
                      <select id="projectinput5" name="interested" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Approval Status</option>
                        <option value="Pending">Pending</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Admin Remark</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Admin Remark" name="Admin Remark">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-actions text-right">
                <button type="submit" class="btn btn-outline-primary">
                  <i class="la la-check-square-o"></i> Submit
                </button>
                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                  <i class="ft-x"></i> Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade text-left" id="reseller_packges" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">User Name</h4>
          </div>
          <div class="modal-body">
            <form class="form">
              <div class="form-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Packages</label>
                      <select id="projectinput5" name="Packages" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Packages</option>
                        <option value="Silver">Silver</option>
                        <option value="Gold">Gold</option>
                        <option value="Platinum">Platinum</option>
                        <option value="Reseller Club">Reseller Club</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Approval Status</label>
                      <select id="projectinput5" name="interested" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Approval Status</option>
                        <option value="Pending">Pending</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Admin Remark</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Admin Remark" name="Admin Remark">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-actions text-right">
                <button type="submit" class="btn btn-outline-primary">
                  <i class="la la-check-square-o"></i> Submit
                </button>
                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                  <i class="ft-x"></i> Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade text-left" id="reseller_product" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">Product Information</h4>
          </div>
          <div class="modal-body">
            <form class="form">
              <div class="form-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Category List</label>
                      <select id="projectinput5" name="Category List" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Category List</option>
                        <option value="baby & Kids">baby & Kids</option>
                        <option value="Electronics">Electronics</option>
                        <option value="Womens">Womens</option>
                        <option value="Mens">Mens</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Sub Category</label>
                      <select id="projectinput5" name="Sub Category" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Sub Category</option>
                        <option value="Toys">Toys</option>
                        <option value="Clothing">Clothing</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Sub Product Category</label>
                      <select id="projectinput5" name="Sub Product Category" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Sub Product Category</option>
                        <option value="Dresses">Dresses</option>
                        <option value="Sandals">Sandals</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Product Name</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Product Name" name="Admin Remark">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">MRP Price</label>
                      <input type="number" id="userinput2" class="form-control border-primary" placeholder="MRP Price" name="Admin Remark">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Offer Price</label>
                      <input type="number" id="userinput2" class="form-control border-primary" placeholder="Offer Price" name="Admin Remark">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <img src="https://www.oxiinc.in/uploads/Multiple_Picture/614456768.png" class="media-object rounded-circle" width="100" height="100">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Approval Status</label>
                      <select id="projectinput5" name="interested" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Approval Status</option>
                        <option value="Pending">Pending</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-actions text-right">
                <button type="submit" class="btn btn-outline-primary">
                  <i class="la la-check-square-o"></i> Save
                </button>
                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                  <i class="ft-x"></i> Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade text-left" id="reseller_accounts" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title">User Name</h4>
          </div>
          <div class="modal-body">
            <form class="form">
              <div class="form-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Bank Holder Name</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Bank Holder Name" name="Bank Holder Name">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Bank Account Number</label>
                      <input type="number" id="userinput2" class="form-control border-primary" placeholder="Bank Account Number" name="Bank Account Number">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Bank IFSC Code</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Bank IFSC Code" name="Bank IFSC Code">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Remark</label>
                      <input type="text" id="userinput2" class="form-control border-primary" placeholder="Remark" name="Remark">
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="projectinput5">Approval Status</label>
                      <select id="projectinput5" name="interested" class="form-control border-primary">
                        <option value="none" selected="" disabled="">Approval Status</option>
                        <option value="Pending">Pending</option>
                        <option value="Approved">Approved</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="userinput2">Cancel Check Copy</label>
                      <input type="file" id="userinput2" class="form-control border-primary" placeholder="Cancel Check Copy" name="Cancel Check Copy">
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-actions text-right">
                <button type="submit" class="btn btn-outline-primary">
                  <i class="la la-check-square-o"></i> Submit
                </button>
                <button type="button" class="btn btn-outline-secondary mr-1" data-dismiss="modal">
                  <i class="ft-x"></i> Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

   </body>
</html>