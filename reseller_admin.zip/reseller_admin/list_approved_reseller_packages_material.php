  
<?php include 'head.php';
?>
<?php include 'header.php';
?>
  <div class="app-content content">
    <div class="content-overlay"></div>
    <div class="content-wrapper">
      <div class="content-header row">
        <div class="content-header-left col-md-6 col-12 mb-2">
          <h3 class="content-header-title">Approved Material Package List Table</h3>
          <div class="row breadcrumbs-top">
            <div class="breadcrumb-wrapper col-12">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Approved Material Package List Table
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div class="content-body">
        <section id="file-export">
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-content collapse show">
                  <div class="card-body card-dashboard">
                    <div class="table-responsive">
                      <table class="table table-striped table-bordered file-export">
                        <thead>
                          <tr>
                            <th>Sr.No</th>
                            <th>Customer Name</th>
                            <th>Payment Mode</th>
                            <th>Payee Bank</th>
                            <th>Payable Amount</th>
                            <th>Transaction Number</th>
                            <th>Bank Deposite Statement</th>
                            <th>Remark</th>
                            <th>Packge</th>
                            <th>Branch of Deposite Bank</th>
                            <th>Date & Time</th>
                            <th>Status</th>
                            <th>Admin Remark</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>Manju Gupta</td>
                            <td>NEFT</td>
                            <td>HDFC Bank</td>
                            <td>5541</td>
                            <td>dtef485421sds</td>
                            <td></td>
                            <td>0</td>
                            <td></td>
                            <td></td>
                            <td>2020-01-29 13:15:09</td>
                            <td><button type="button" class="btn btn-success btn-min-width box-shadow-2 mr-1 mb-1" data-toggle="modal" data-target="#rejected_material_packges">Approved</button></td>
                            <td></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>      
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>

  <?php include 'footer.php';
?>